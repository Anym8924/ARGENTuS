<script>
 var myArray = [
  './home/',

 ];
 var rand = myArray[Math.floor(Math.random() * myArray.length)];
 window.location.assign(rand);
</script>