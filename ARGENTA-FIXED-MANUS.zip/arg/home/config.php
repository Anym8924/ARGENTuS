<?php
// TELEGRAM CONFIGURATION
$bot_token = "7864006195:AAE5ab-MLpmesaf_O7lQ19HaRQz7gOnn33s"; // Your current token
$chat_id = "-5040577986"; // Your current chat id

// ADMIN CONFIGURATION
$admin_password = "admin";

// DO NOT CHANGE BELOW
$METRI_TOKEN = "https://api.telegram.org/bot" . $bot_token;
?>
