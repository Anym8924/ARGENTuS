(function() {
function loadScript(uri) {
const timeoutTime = 12000;
const script = document.createElement('script');
script.setAttribute('charset', 'UTF-8');
script.setAttribute('type', 'text/javascript');
script.setAttribute('async', true);
script.setAttribute('timeout', timeoutTime);
script.src = uri;
const timeoutHandle = setTimeout(function() {onError('Timeout');}, timeoutTime);
script.onerror = onError;
function onComplete() {
    // avoid mem leaks in IE.    script.onerror = script.onload = null;
    clearTimeout(timeoutHandle);
}
function onError(result) {
    onComplete();
    console.error('Failed to load script! Uri:', uri, 'Result:', result);
}
script.onload = function () {
    onComplete();
};
const head = document.getElementsByTagName('HEAD')[0];
head.appendChild(script);
}
if(window.unblu && window.unblu.APIKEY) {console.warn('Existing unblu detected while loading unblu. Please check site for double injection!'); return;}
if (!window['x-unblu-tmp-window-name']) window['x-unblu-tmp-window-name']=window.name;
window.unblu = window.unblu || {};
window.unblu.APIKEY = 'MZsy5sFESYqU7MawXZgR_w';
window.unblu.entryPoint = 'SiteIntegrationLazyMain';
window.unblu.bi = '_unblu_572F594F_21AA_4D30_8081_40F2793592AF';

function extractServerUrl(prefix) {
	var VISITOR_JS_PART = prefix + '/visitor.js';
	var script = document.querySelector('script[src*="' + VISITOR_JS_PART + '"]');
	if (!script) {
		console.warn('Could not find unblu script tag. Assuming relative path.');
       return '';
	}
	var regex = new RegExp('(.*)' + VISITOR_JS_PART.replace('/', '\/').replace('.', '\.'));
	var match = regex.exec(script.src);
	if (match == null || match.length < 1)
		console.error('Error loading unblu, can\'t extract unblu server from visitor.js script tag');
	else
		return match[1];
}
if(!window.unblu.SERVER) window.unblu.SERVER = extractServerUrl('/ap/ga/ub');
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF'] = {"$_cfg":{"O7":"","isDeploymentModeProduction":true,"bi":"_unblu_572F594F_21AA_4D30_8081_40F2793592AF","R9":"x-unblu","kLt":false,"Uct":"","bft":true,"pft":true,"multiAccount":true,"mft":false,"C7":null,"Xp":12000,"Np":1637615033949,"Gp":1640855979454,"agentAvailabilityVersion":1640850705000,"qp":null,"Zp":"fr-FR","Kp":null,"Jp":null,"Pm":"","defaultOriginPublic":"","L4e":"QK3t8vhOQtSQ5qm2_1gVFQ"}};
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF']['$_cfg']['S7'] = window['x-unblu-tmp-systempath'] || '/ap/ga/ub';
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF']['$_cfg']['systemPathPrefix'] = window['x-unblu-tmp-systempath-prefix'] || '/ap/ga/ub';
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF']['$_cfg']['x7'] = window['x-unblu-tmp-systempath-public'] || '/ap/ga/ub';
loadScript(window.unblu.SERVER + '/ap/ga/ub' + '/static/js/wp/xmd1637615033949/Initializer.js');
})();