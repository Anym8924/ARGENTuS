<?php
$ip = $_GET['ip'] ?? '';
$path = "heartbeat/$ip.txt";

if (!$ip) {
    echo "<span class='badge badge-secondary'>❓ Aucune donnée</span>";
    exit;
}

if (file_exists($path)) {
    $lastPing = file_get_contents($path);
    $now = time();
    $diff = $now - $lastPing;

    if ($diff < 20) {
        echo "<span class='badge badge-success'>🟢 En ligne</span>";
    } else {
        echo "<span class='badge badge-danger'>🔴 Hors ligne</span>";
    }
} else {
    echo "<span class='badge badge-secondary'>❓ Aucune donnée</span>";
}
?>
