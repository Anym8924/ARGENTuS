﻿// File Javascript per la gestione della visualizzazione di un layer che evita ulteriori operazioni da parte dell'utente
// Creato da Cristoforo Cataldo il 05/12/2007

//boolean per gestire la compatibilità con jquery
//per evitare di eseguire la ShowPostbackWait anche quando
//il validation plugin di jquery ha annullato onSubmit
var abortPostbackWait;

//funzione per l'abort preventivo o posticipato del panel di attesa
function PostbackWaitAbort() {
    //gestione IE del PostbackManager
    abortPostbackWait = true;

    //gestione Mozilla del PostbackManager
    if (typeof PostBackWait_EndRequestHandler == 'function') {
        PostBackWait_EndRequestHandler(null, null);
    }
}

// Funzione per la visualizzazione del layer di attesa su tutta la pagina
function ShowPostbackWait(idDivPostbackWait, idDivImgPostbackWait, idFrmPostbackWait, opacity, showImgPostbackWait) {
    //se si richiede l'abort del postbackwait si esce
    if (typeof abortPostbackWait == 'undefined')
        abortPostbackWait = false;

    if (abortPostbackWait) {
        abortPostbackWait = false;
        return;
    }

    // Acquisizione del layer di attesa
    var divPostbackWait = document.getElementById(idDivPostbackWait);
    var divImgPostbackWait = document.getElementById(idDivImgPostbackWait);

    // Eventuale acquisizione dell'iframe per la disabilitazione dell'uso delle combo durante le postback
    var frmPostbackWait = null;
    if (idFrmPostbackWait != null && idFrmPostbackWait != "")
        frmPostbackWait = document.getElementById(idFrmPostbackWait);

    // Se il layer è valido si procede alla sua visualizzazione
    if (divPostbackWait != null) {
        // Acquisizione delle dimensioni della pagina
        var pageSize = GetPageSize();

        // Impostazione delle dimensioni del layer
        divPostbackWait.style.width = pageSize[0] + "px";
        divPostbackWait.style.height = pageSize[1] + "px";
        if (showImgPostbackWait) {
            divImgPostbackWait.style.width = pageSize[0] + "px";
            divImgPostbackWait.style.height = pageSize[1] + "px";
        }

        // Impostazione della trasparenza sul layer
        SetOpacity(divPostbackWait, opacity);

        // Visualizzazione del layer
        divPostbackWait.style.display = "block";
        if (showImgPostbackWait) divImgPostbackWait.style.display = "block";

        // Se è necessario usare anche l'iframe, allora viene impostato e visualizzato
        if (frmPostbackWait != null) {
            // Impostazione delle dimensioni del frame
            frmPostbackWait.style.width = pageSize[0] + "px";
            frmPostbackWait.style.height = pageSize[1] + "px";

            // Impostazione della trasparenza sul frame
            SetOpacity(frmPostbackWait, opacity);

            // Visualizzazione del frame
            frmPostbackWait.style.display = "block";
        }

        // Visualizzazione del pulsante di attesa
        if (document.body)
            document.body.style.cursor = "wait";
    }
}

// Funzione il nascondimento del layer di attesa
function HidePostbackWait(idDivPostbackWait, idDivImgPostbackWait, idFrmPostbackWait) {
    // Acquisizione del layer di attesa
    var divPostbackWait = document.getElementById(idDivPostbackWait);
    var divImgPostbackWait = document.getElementById(idDivImgPostbackWait);

    // Eventuale acquisizione dell'iframe per la disabilitazione dell'uso delle combo durante le postback
    var frmPostbackWait = null;
    if (idFrmPostbackWait != null && idFrmPostbackWait != "")
        frmPostbackWait = document.getElementById(idFrmPostbackWait);

    // Se il layer è valido si procede al suo nascondimento
    if (divPostbackWait != null) {
        divPostbackWait.style.display = "none";
        divImgPostbackWait.style.display = "none";

        // Se è stato usato anche l'iframe, allora viene nascosto
        if (frmPostbackWait != null)
            frmPostbackWait.style.display = "none";

        // Visualizzazione del pulsante di default
        if (document.body)
            document.body.style.cursor = "auto";
    }
}

// Procedura per l'impostazione dell'opacità (in percentuale) ad un oggetto
function SetOpacity(obj, percentage) {
    // Se i parametri passati non sono validi la procedura termina
    if (obj == null || obj.style == null || percentage == null || isNaN(percentage))
        return;

    // Controlli sulla percentuale per l'appartenenza al range [0 .. 100]
    if (percentage < 0)
        percentage = 0;
    if (percentage > 100)
        percentage = 100;

    // Impostazione dell'opacità per le nuove versioni dei browser Mozilla, Safari e Opera
    if (obj.style.opacity != null)
        obj.style.opacity = percentage / 100;
    // Impostazione dell'opacità per le vecchie versioni dei browser Mozilla
    else if (obj.style.MozOpacity != null)
        obj.style.MozOpacity = percentage / 100;
    // Impostazione dell'opacità per le vecchie versioni dei browser Konqueror e Safari
    else if (obj.style.KhtmlOpacity != null)
        obj.style.KhtmlOpacity = percentage / 100;
    // Impostazione dell'opacità per le il browser Internet Explorer
    else
        obj.style.filter = "alpha(opacity=" + percentage + ")"; ;
}

// Funzione per l'acquisizione delle dimensioni della pagina
function GetPageSize() {
    var pageWidth = 0; // Larghezza della pagina
    var pageHeight = 0; // Altezza della pagina

    // Acquisizione delle dimensioni nel caso in cui sia in uso jQuery
    if (window.jQuery && document) {
        pageWidth = $(document).width();
        pageHeight = $(document).height();
    // Acquisizione delle dimensioni per il browser Firefox
    } else if (window.innerWidth && window.innerHeight) {
        pageWidth = window.innerWidth + GetNumericSize(window.scrollMaxX);
        pageHeight = window.innerHeight + GetNumericSize(window.scrollMaxY);
    // Acquisizione delle dimensioni per i browser Internet Explorer 6 e compatibili
    } else if (document.documentElement && document.documentElement.offsetHeight && document.documentElement.offsetWidth) {
        if (document.documentElement.scrollHeight > document.documentElement.offsetHeight) {
            pageWidth = document.documentElement.scrollWidth;
            pageHeight = document.documentElement.scrollHeight;
        } else {
            pageWidth = document.documentElement.offsetWidth + document.documentElement.offsetLeft - 24;
            pageHeight = document.documentElement.offsetHeight + document.documentElement.offsetTop - 5;
        }
    // Acquisizione delle dimensioni per i browser Internet Explorer 4 e compatibili
    } else if (document.body && document.body.offsetHeight && document.body.offsetWidth) {
        if (document.body.scrollHeight > document.body.offsetHeight) {
            pageWidth = document.body.scrollWidth;
            pageHeight = document.body.scrollHeight;
        } else {
            pageWidth = document.body.offsetWidth + document.body.offsetLeft - 24;
            pageHeight = document.body.offsetHeight + document.body.offsetTop - 5;
        }
    }

    // Restituzione delle dimensioni della pagina
    return [pageWidth, pageHeight];
}

// Funzione che restituisce il valore della dimensione passata o zero se non numerico
function GetNumericSize(value) {
    if (!isNaN(value - parseFloat(value))) {
        return value;
    } else {
        return 0;
    }
}
