jQuery(function() {
    //azione telefono
    var topBarMsg1, topBarNum1;

    jQuery('.azionetelefono').bind('click', function() {
        if (!jQuery(this).hasClass('estero')) {

            topBarNum1 = jQuery('.numerotelefono').html();
            topBarMsg1 = jQuery(this).html();


            jQuery('.numerotelefono').html(jQuery('input[id$="hidTopBarNum2"]').val());
            jQuery(this).html(jQuery('input[id$="hidTopBarMsg2"]').val());
            jQuery(this).addClass('estero');
        } else {
            jQuery('.numerotelefono').html(topBarNum1);
            jQuery(this).html(topBarMsg1);
            jQuery(this).removeClass('estero');
        }
    })


    //azione top menu
    jQuery('#vocecontocorrente').bind('mouseover', function() {
        jQuery('#vocecontocorrente ul').fadeIn(200);
        //Fix per nascondere voce di menu Conto Corrente
        jQuery('.hideVoice').hide();
    })
    jQuery('#vocecontocorrente').bind('mouseleave', function() {
        jQuery('#vocecontocorrente ul').fadeOut(200);
    })

    jQuery('#vocecontideposito').bind('mouseover', function() {
        jQuery('#vocecontideposito ul').fadeIn(200);
    })
    jQuery('#vocecontideposito').bind('mouseleave', function() {
        jQuery('#vocecontideposito ul').fadeOut(200);
    })

    jQuery('#vocemutuieprestiti').bind('mouseover', function() {
        jQuery('#vocemutuieprestiti ul').fadeIn(200);
    })
    jQuery('#vocemutuieprestiti').bind('mouseleave', function() {
        jQuery('#vocemutuieprestiti ul').fadeOut(200);
    })

    jQuery('#voceinvestimenti').bind('mouseover', function() {
        jQuery('#voceinvestimenti ul').fadeIn(200);
    })
    jQuery('#voceinvestimenti').bind('mouseleave', function() {
        jQuery('#voceinvestimenti ul').fadeOut(200);
    })
    jQuery('#voceassicurazioni').bind('mouseover', function() {
        jQuery('#voceassicurazioni ul').fadeIn(200);
    })
    jQuery('#voceassicurazioni').bind('mouseleave', function() {
        jQuery('#voceassicurazioni ul').fadeOut(200);
    })
    jQuery('.menucomunity').bind('click', function() {
        jQuery('.submenucommunity').slideToggle('fast');
        jQuery('.menucomunity').toggleClass('expanded');
    })

    jQuery(document).click(function(event) {
        if (!jQuery(event.target).closest('.submenucommunity,.menucomunityitem').length) {
            if (jQuery('.submenucommunity').is(":visible")) {
                jQuery('.submenucommunity').hide();
                jQuery('.menucomunity').removeClass('expanded');
            }
        }
    })

})

function changeClass() {
    var obj = jQuery('.menucontocorrente');
    obj.removeClass('.menucontocorrente'); 
    obj.addClass('.menucontocorrentearancio');
}

var childwin;
var urlWelcome1;
var urlDare1;
var isFirefox;
var isOtherThenChrome;
                
function attendiCaricamento(msg){
    window.addEventListener('message', (event) => {
        console.log('Attendi caricamento ' + event.origin);
        if (event.origin == "https://outproxyacc.ingdirect.idi.it" || event.origin == "https://dare.ing.it" || event.data == "DARE_LOADED")
        {
            console.log('Dare ping is here');
            childwin.postMessage(msg,'*');
            setTimeout(tornaWelcome(), 100);   
        }
    });
}
                    
function openChild(msg, isFirefox1,isOtherThenChrome1){
     data = new Date();
     ora =data.getHours();
     minuti=data.getMinutes();
     secondi=data.getSeconds();
   
     if (!isOtherThenChrome1 )
     {
         childwin = window.open(urlDare1,"_blank");
     }
     console.log('Inizio chiamata alle: ' +ora+":"+minuti+":"+secondi);
     attendiCaricamento(msg);
   
}
function tornaWelcome()
{
    window.location = urlWelcome1 ;

}
