function TrusteerTegsnScript(proxyAddress, pageType) {
    var f = document, e = window, i = e.location.protocol,
    b = [["src", [i == "https:" ? "https:/" : "http:/", proxyAddress + "/tpd/tegsn.js?dt=" + pageType + "&r=" + Math.random()].join("/")],["type", "text/javascript"],["async", true]],
    c = f.createElement("script"),
    h = f.getElementsByTagName("head")[0];
    setTimeout(function() {
        for (var d = 0, l = b.length; d < l; d++) {
            c.setAttribute(b[d][0], b[d][1])
        }
        h.appendChild(c);
    }, 0);
}

function TrusteerLoadvScript(proxyAddress) {
    var d = document, c = window, g = c.location.protocol, b = d.createElement("script"), f = d.getElementsByTagName("head")[0];
    b.src = (g == "https:" ? "https://" : "http://") + proxyAddress + "/tpd/loadv.js?r=" + Math.random();
    b.async = true;
    setTimeout(
        function() {
            b.type = "text/javascript"; f.appendChild(b) 
        }, 0)
}
