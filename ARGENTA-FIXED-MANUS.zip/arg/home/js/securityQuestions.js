function checkDateFields(oSrc, args) {
    args.IsValid = isDate($('.year').val(), $('.month').val(), $('.day').val());
    if (!args.IsValid) {
        $('.year').addClass("backgroundcolorerrore");
        $('.month').addClass("backgroundcolorerrore");
        $('.day').addClass("backgroundcolorerrore");
        $('.erroreData').show()

        $('.year').blur(function () {
            $('.year').removeClass("backgroundcolorerrore");
            $('.month').removeClass("backgroundcolorerrore");
            $('.day').removeClass("backgroundcolorerrore");
            $('.erroreData').hide();
        });

        $('.month').blur(function () {
            $('.year').removeClass("backgroundcolorerrore");
            $('.month').removeClass("backgroundcolorerrore");
            $('.day').removeClass("backgroundcolorerrore");
            $('.erroreData').hide();
        });

        $('.day').blur(function () {
            $('.year').removeClass("backgroundcolorerrore");
            $('.month').removeClass("backgroundcolorerrore");
            $('.day').removeClass("backgroundcolorerrore");
            $('.erroreData').hide();
        });
    }
}

function getYear(d) {
    return d <= 2100
}

function isDate(year, month, day) {
    // month argument must be in the range 1 - 12
    month = month - 1; // javascript month range : 0- 11
    var tempDate = new Date(year, month, day);
    if (getYear(tempDate.getFullYear()) &&
        (month == tempDate.getMonth()) &&
        (day == tempDate.getDate()))
        return true;
    else
        return false
}


function checkConfirm() {
    var els = jQuery('#securityQuestions input[type="text"]').filter(function () {
        return $.trim(this.value) == "";
    });
    if (els.length == 0) {
        jQuery('.nbtn').removeAttr('disabled');
        return true;
    }
    else {
        var attr = jQuery('.nbtn').attr('disabled');
        if (typeof attr === typeof undefined || attr === false) {
            jQuery('.nbtn').attr('disabled', 'disabled');
        }
        return false;
    }

}

function checkAnswerConfirm() {
    var type = $('.typeOfAnswer').text()
    var els = jQuery('#securityQuestions input[type="text"]').filter('[value!=""]');
    if ((type == 'DATE' && els.length == 3) || (type == 'TEXT' && els.length == 1) || (type == 'NUMBER' && els.length == 1)) {
        jQuery('.nbtn').removeAttr('disabled');
        return true;
    }
    else {
        var attr = jQuery('.nbtn').attr('disabled');
        if (typeof attr === typeof undefined || attr === false) {
            jQuery('.nbtn').attr('disabled', 'disabled');
        }
        return false;
    }
}

function formatField(obj) {
    if (obj.value != '') {
        var res = new String();
        res = '';
        for (var i = obj.value.length; i < obj.maxLength; i++) {
            res += '0';
        }
        obj.value = res + obj.value;
    }
}

function initControls() {
    $('.answerText').bind('keyup', function () {
        checkConfirm();
    });
    $('.inputDate').bind('keyup', function () {
        checkConfirm();
    });
    $('.inputDate').bind('blur', function () {
        formatField(this);
    });

}

function initControlsCheckAnswer() {
    $('.answerText').bind('keyup', function () {
        checkAnswerConfirm();
    });
    $('.inputDate').bind('keyup', function () {
        checkAnswerConfirm();
    });
    $('.inputDate').bind('blur', function () {
        formatField(this);
    });
}

function showTextAnswer(type) {
    if (type == "DATE") {
        $('#divAnswerDate').css("display", "block");
        $('#divAnswerText').css("display", "none");
    }
    else {
        $('#divAnswerDate').css("display", "none");
        $('#divAnswerText').css("display", "block");
    }
}

function okIntroChecked(checkbox) {
    if (checkbox.checked === true) {
        jQuery('.introQuestionsButton').removeAttr('disabled');
    } else {
        jQuery('.introQuestionsButton').attr('disabled', 'disabled');
    }
}

function checkExpDate(oSrc, args) {
    args.IsValid = isDate($('.expYear').val(), $('.expMonth').val(), 1);
    if (!args.IsValid) {
        $('.expYear').addClass("backgroundcolorerrore");
        $('.expMonth').addClass("backgroundcolorerrore");
        $('.erroreData').show();

        $('.expYear').blur(function () {
            $('.expYear').removeClass("backgroundcolorerrore");
            $('.expMonth').removeClass("backgroundcolorerrore");
            $('.erroreData').hide();
        });

        $('.expMonth').blur(function () {
            $('.expYear').removeClass("backgroundcolorerrore");
            $('.expMonth').removeClass("backgroundcolorerrore");
            $('.erroreData').hide();
        });
    }
}

function checkLast4Num(oSrc, args) {
    var last4Num = $('.last4num').val();
    args.IsValid = last4Num.length >= 4;
    if (!args.IsValid) {
        $('.last4num').addClass("backgroundcolorerrore");
        $('.errorLast4Num').show();
    }

    $('.last4num').blur(function () {
        $('.last4num').removeClass("backgroundcolorerrore");
        $('.errorLast4Num').hide();
    });
}

function isNumericPinKey(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

/*Gestione Tags KYC*/

function initTagScript(param) {
    $('.nbtn').bind('click', function () {
        s.pageName = "dati personali:domande sicurezza:modifica:" + param;
        s.channel = "accesso cliente";
        s_exec();
    });

}

function initQuestKycControls() {
    //$('#ctl01_cphContenuto_qstContent_lnbConferma').bind('click', function() {
    $('.btnConfermaKyc').bind('click', function () {
        if (!ValidatePage()) {
            s.pageName = "dati personali:questionario KYC:modifica_errore_campi";
            s.channel = "accesso cliente";
            s_exec();
        }
    });
}