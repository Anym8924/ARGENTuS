"use strict";
var _stopAutoTab = false;
var _invalid = true;

function _completeField(event) {
  var storedEvent = _storeKeyCode(event);
  var name = storedEvent.inputName;
  var target = $("input[id*=".concat(storedEvent.inputName))[0];
  var targetFunction = "_validate".concat(name);

  if (name !== 'txtaa' && target.value !== '' && name !== 'txtcc') {
    var Input = target.value;
    var inputLength = Input.length;

    if (inputLength < 2 && Input !== '0') {
      target.value = 0 + Input;
    }
  }

  this[targetFunction](event);
}

function _storeKeyCode(event) {
  var birthDay = document.querySelector('input[id*="txtgg"]').id;
  var birthMonth = document.querySelector('input[id*="txtmm"]').id;
  var birthYear = document.querySelector('input[id*="txtaa"]').id;

  var input = event.target ? event.target : event.srcElement;
  return {
    inputId: input.id,
    inputName: input.id.slice(-5),
    inputValue: input.value,
    inputLength: input.value.length,
    code: event.keyCode ? event.keyCode : event.which,
    position: input.selectionStart,
    cursor: input.selectionEnd,
    selection: input.selectionEnd - input.selectionStart !== 0
  };
}
/** Erase and delete events management */


function _backspaceManager(event) {
  var storedEvent = _storeKeyCode(event);

  var previous;
  var next;

  switch (storedEvent.inputName) {
    case 'txtgg':
      previous = storedEvent.inputId.slice(0, -2) + 'gg';
      next = storedEvent.inputId.slice(0, -2) + 'mm';
      break;

    case 'txtmm':
      previous = storedEvent.inputId.slice(0, -2) + 'gg';
      next = storedEvent.inputId.slice(0, -2) + 'aa';
      break;

    case 'txtaa':
      previous = storedEvent.inputId.slice(0, -2) + 'mm';
      next = storedEvent.inputId.slice(0, -2) + 'aa';
      break;

    default:
      previous = storedEvent.inputId.slice(0, -2) + 'gg';
      next = storedEvent.inputId.slice(0, -2) + 'aa';
      break;
  }

  if (!storedEvent.selection && storedEvent.code === 8 && (storedEvent.inputLength === 0 || storedEvent.position === 0)) {
    _focusField(document.getElementById(previous));
  } else if (!storedEvent.selection && storedEvent.code === 46
    && storedEvent.position >= storedEvent.inputLength) {
    _focusField(document.getElementById(next));
  }
}

/** Tab and arrows events management */


function _tabToField(storedEvent, expectedLenght, next, previous) {
  var previousField = previous || document.getElementById(storedEvent.inputId);
  var nextField = next || document.getElementById(storedEvent.inputId);
  _stopAutoTab = !_invalid;

  if (!_stopAutoTab && !document.getElementById(storedEvent.inputId).hasAttribute('invalid')
    && (storedEvent.code >= 48 && storedEvent.code <= 57 || storedEvent.code >= 96 && storedEvent.code <= 105)
    && storedEvent.inputLength === expectedLenght) {
    _focusField(nextField);

  } else if (!storedEvent.selection
    && storedEvent.position === 0
    && storedEvent.code === 37) {
    _focusField(previousField);
  } else if (!storedEvent.selection
    && (storedEvent.position === expectedLenght
      || storedEvent.position === 0
      || storedEvent.cursor === storedEvent.inputLength)
    && storedEvent.code === 39) {
    _focusField(nextField);
  }
}

function _focusField(field) {
  field.focus();
}

/** Day validator */


function _validatetxtgg(event) {
  var storedEvent = _storeKeyCode(event);

  var validator = storedEvent.inputValue > 0 && storedEvent.inputValue <= 31;

  this._setInvalidState(storedEvent.inputId, validator);

  this._tabToField(storedEvent, 2, $("input[id*='txtmm']")[0], document.getElementById(storedEvent.inputId));
}
/** Month validator */


function _validatetxtmm(event) {
  var storedEvent = this._storeKeyCode(event);

  var validator = storedEvent.inputValue > 0 && storedEvent.inputValue <= 12;

  _setInvalidState(storedEvent.inputId, validator);

  _tabToField(storedEvent, 2, $("input[id*='txtaa']")[0], $("input[id*='txtgg']")[0]);
}
/** Year validator */


function _validatetxtaa(event) {
  var storedEvent = _storeKeyCode(event);

  var today = new Date();
  var highRange = today.getFullYear();
  var lowRange = highRange - 150;
  var validator = storedEvent.inputLength >= 4 && storedEvent.inputValue >= lowRange && storedEvent.inputValue <= highRange;

  _setInvalidState(storedEvent.inputId, validator);

  _tabToField(storedEvent, 4, document.getElementById(storedEvent.inputId), $("input[id*='txtmm']")[0]);
}
/** CIF validator */


function _validatetxtcc(event) {
  var storedEvent = this._storeKeyCode(event);

  var validator = storedEvent.inputLength >= 10;

  _setInvalidState(storedEvent.inputId, validator);

  _tabToField(storedEvent, 10, $("input[id*='txtgg']")[0], $("input[id*='txtgg']")[0]);
}
/** Set to a given field to invalid if value is not valid */


function _setInvalidState(elementId, valid) {
  if (valid) {
    document.getElementById(elementId).removeAttribute('invalid');

    var _validtxtgg = !$("input[id*='txtgg']")[0].hasAttribute('invalid');

    var _validtxtmm = !$("input[id*='txtmm']")[0].hasAttribute('invalid');

    var _validtxtaa = !$("input[id*='txtaa']")[0].hasAttribute('invalid');

    if (_validtxtgg && _validtxtmm && _validtxtaa && _invalid) {
      _invalid = !_invalid;
    }
  } else {
    document.getElementById(elementId).setAttribute('invalid', '');
    _invalid = true;
  }
}
