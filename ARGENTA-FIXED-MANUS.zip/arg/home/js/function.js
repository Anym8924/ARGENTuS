var IsAlreadyLoadedInitPrint = false;
var printAreaName = "printArea";
var domainCookie = "";
// Funzione per l'inizializzazione della printarea
function initPrint(printAreaSpecified)
{
    if (printAreaSpecified != null)
        printAreaName = printAreaSpecified;
    if (!IsAlreadyLoadedInitPrint || printAreaName!=null)
    {
        IsAlreadyLoadedInitPrint = true;
        applyXPrintCss(printAreaName);
        if (printAreaSpecified!=null)
            copyPrintAreaToPrintable();
        else
            setTimeout(copyPrintAreaToPrintable, 1000);
    }
}
// Funzione per applicare il css di stampa
function applyXPrintCss()
{
    // Acquisizione della printarea
    var divPrintArea = document.getElementById(printAreaName);
    // Se la printarea risulta popolata allora viene aggiunto il css, altrimenti viene rimosso
    var cssUrl = "/css/xprint.css";
    if (divPrintArea != null && divPrintArea.innerHTML != "")
        appendCss(cssUrl);
    else
        removeCss(cssUrl);
}
// Funzione per l'aggiunta del css passato come parametro
function appendCss(cssUrl)
{
    // Creazione del link al css
    var css = document.createElement("link");
    css.rel = "stylesheet";
    css.type = "text/css";
    css.href = cssUrl;
    // Aggiunta del css all'intestazione della pagina
    document.getElementsByTagName("head")[0].appendChild(css);
}
// Funzione per la rimozione del css passato come parametro
function removeCss(cssUrl)
{
    // Acquisizione della lista dei css
    var cssList = document.getElementsByTagName("link")
    // Ricerca e rimozione del css richiesto
    for (var i = cssList.length - 1; i >= 0; i--)
    {
        if (cssList[i] != null && cssList[i].type == "text/css" && cssList[i].getAttribute("href") != null && cssList[i].getAttribute("href").indexOf(cssUrl) != -1)
            cssList[i].parentNode.removeChild(cssList[i]);
    }
    // Rimozione della printable area
    removeDivPrintable();
}
// Funzione per la creazione della printable area
function createDivPrintable()
{
    // Rimozione dell'eventuale printarea esistente
    if(document.getElementById(printAreaName) != null)
        removeDivPrintable();
    // Aggiunta della printarea
    var printable = document.createElement("div");
    printable.id = "printable";
    document.getElementsByTagName("body")[0].appendChild(printable);
}
// Funzione per la verifica dell'esistenza della printable area
function verifyExistsPrintable()
{
    if (document.getElementById("printable") != null)
        return;
    // Aggiunta della printarea
    var printable = document.createElement("div");
    printable.id = "printable";
    document.getElementsByTagName("body")[0].appendChild(printable);
}
// Funzione per la rimozione della printable area
function removeDivPrintable()
{
    // Rimozione della printable area
    var printable = document.getElementById("printable");
    if (printable != null)
        printable.parentNode.removeChild(printable);
}
function copyPrintAreaToPrintable() {
    copyToPrintable(printAreaName);
}
function copyToPrintable(divName) {
    if (document.getElementById(divName) != null) {
        try {
            createDivPrintable();
            var html = document.getElementById(divName).innerHTML;
            document.getElementById("printable").innerHTML = html;
            var  printable = document.getElementById("printable");
            deleteElm(printable, '*', 'noprint');
            changeAjaxIdElm(printable, '*', 'ajaxclass');
         } catch (e) {}
    }
}
function addToPrintable(divName) {
    try {
            verifyExistsPrintable();
            var html = document.getElementById(divName).innerHTML;
            document.getElementById("printable").innerHTML += html;
            var  printable = document.getElementById("printable");
            deleteElm(printable, '*', 'noprint');
            changeAjaxIdElm(printable, '*', 'ajaxclass');
    } catch (e) {}
}
function getElementsByClassName(oElm, strTagName, strClassName){
	var arrElements = (strTagName == "*" && oElm.all)? oElm.all : oElm.getElementsByTagName(strTagName);
	var arrReturnElements = new Array();
	strClassName = strClassName.replace(/\-/g, "\\-");
	var oRegExp = new RegExp("(^|\\s)" + strClassName + "(\\s|$)");
	var oElement;
	for(var i=0; i<arrElements.length; i++) {
		oElement = arrElements[i];
		if(oRegExp.test(oElement.className)) {
			arrReturnElements.push(oElement);
		}
	}
	return (arrReturnElements)
}
function deleteElm(oElm, strTagName, strClassName) {
	var toDel = getElementsByClassName(oElm, strTagName, strClassName)
	for(var i=0; i<toDel.length; i++) {
		(toDel[i].parentNode).removeChild(toDel[i]);
	}
}
function changeAjaxIdElm(oElm, strTagName, strClassName) {
	var toDel = getElementsByClassName(oElm, strTagName, strClassName)
	for(var i=0; i<toDel.length; i++) {
		toDel[i].id='NewAjaxCtrlID';
	}
}
function DisplayPopup(popurl,popname,winprops)
{
	winpopup = window.open(popurl,popname,winprops);
	if (winpopup==null)
		document.location.href='/ErroreBloccoPopup.htm';
	else
		try
		  {
		  winpopup.window.focus();
		  }
		catch(err)
		  {
		        //Handle errors here
		  }
	return winpopup;
}
function OpenPopup(url, width, height)
{
	if (!width) width=390;
	if (!height) height=250;
	var left = (screen.width/2) - width/2;
	var top = (screen.height/2) - height/2;
	var stile = 'status=no,scrollbars=yes,width='+width+',height='+height+',left='+left+',top='+top+',screenX='+left+',screenY='+top;
	var msgWindow = window.open(url,"", stile);
}
function CheckPopup(popurl,popname,winprops)
{
	winpopup = window.open(popurl,popname,winprops);
	if (winpopup==null)
	{
		alert("Le impostazioni del browser che stai utilizzando non consentono l'apertura dei nostri pop up:\nper navigare correttamente sul sito, inserisci i siti secure.ing.it e www.ing.it\ntra quelli a cui consenti la visualizzazione dei pop up.\n- per impostare Explorer: Opzioni Internet/Privacy\n- per impostare Netscape: Modifica/ Privacy & Security");
  	}
  	else
  	{
		winpopup.window.focus();
	}
	return winpopup;
}
 function CheckCookie (CookieName) {
	var lf = "\n";
    var CookieString = document.cookie;
    var CookieSet = CookieString.split (';');
    var SetSize = CookieSet.length;
    var CookiePieces
    var ReturnValue = "";
    var x = 0;
    for (x = 0; ((x < SetSize) && (ReturnValue == "")); x++) {
      CookiePieces = CookieSet[x].split ('=');
      if (CookiePieces[0].substring (0,1) == ' ') {
        CookiePieces[0] = CookiePieces[0].substring (1, CookiePieces[0].length);      }
      if (CookiePieces[0] == CookieName) {
               ReturnValue = CookiePieces[1];            }
     }
     return ReturnValue;
 }
function searchIDFromLocation()
{
var id = "";
var lenSearchLoc = location.search.length;
var SearchLoc = location.search.toLowerCase();
if (SearchLoc.indexOf("&") != -1)
	{
		var arr =  SearchLoc.split("&")
		for (i=0; i<arr.length; i++)
			{
				if (arr[i].indexOf("cookievalue=") != -1)
					{
						pos1 = arr[i].indexOf("=");
						id = arr[i].substring(pos1+1,arr[i].length);
					}
			}
	}
else
	{
		if (SearchLoc.indexOf("cookievalue=") != -1)
		{
			var pos1 = SearchLoc.indexOf("=");
			id = SearchLoc.substring(pos1+1,lenSearchLoc);
		}
	}
	return id;
}
function Redir(url, nw) {
	var szCookieValue = "";
	var ReturnValue = url;
	szCookieValue = CheckCookie('INGTrace');
	if (szCookieValue == "")
		szCookieValue = searchIDFromLocation();
	if (szCookieValue != "") {
		if (url.indexOf('?')> 0 ) {
			ReturnValue += '&CookieValue=' + szCookieValue;
		}
		else {
			ReturnValue += '?CookieValue=' + szCookieValue ;
		}
	}
	if (nw != 'pop'	)
		location.href = ReturnValue;
	else
		return ReturnValue;
}
function apriDemo(prod,demo) {
	var demoWin;
	var path = "/area_info/demo/demo_"+prod+"_"+demo+".htm"
	demoWin=DisplayPopup(path,"Demo","scrollbars=no","_blank");
}
 function checkentry(parametro) {
 var objCurrCtrl;
 if (window.event) {
  objCurrCtrl = window.event;
  isIE = true;
  }
 else {
  objCurrCtrl = arguments.callee.caller.arguments[0];
  isIE = false;
 }
 if (objCurrCtrl.nodeType == 3)
  objCurrCtrl = objCurrCtrl.parentNode;
 var scharCode = isIE ? objCurrCtrl.keyCode : objCurrCtrl.charCode
  if (parametro=='i'){
   if ((scharCode!=0 && scharCode!=8 && scharCode!=9) && (scharCode < 48 || scharCode > 57)) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
  }
  else if (parametro=='n'){
   if ((scharCode!=0 && scharCode!=46 && scharCode!=8 && scharCode!=9) && (scharCode < 48 || scharCode > 57)) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
  } else if (parametro=='l'){
   if (
    (scharCode != 224) &&
    (scharCode != 232) &&
    (scharCode != 236) &&
    (scharCode != 242) &&
    (scharCode != 249) &&
    (scharCode != 39) &&
    (scharCode != 32) &&
    (scharCode < 65 || scharCode > 90) &&
    (scharCode < 97 || scharCode > 122)
    ) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
  } else if (parametro=='n+'){
   if ((scharCode!=0 && scharCode!=46 && scharCode!=8 && scharCode!=9 && scharCode!=44) && (scharCode < 48 || scharCode > 57)) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
  } else if (parametro=='ln'){
   if (
    (scharCode < 48 || scharCode > 57)&&
    ((scharCode < 65 || scharCode > 90) && (scharCode < 97 || scharCode > 122))
    ) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
  } else if (parametro=='lns'){
   if (
    (scharCode != 32 && scharCode != 39) && (scharCode < 48 || scharCode > 57) &&
    ((scharCode < 65 || scharCode > 90) && (scharCode < 97 || scharCode > 122)))
     {
      isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
     }
  } else if (parametro=='ta'){
   if (
    (scharCode == 46) ||
    (scharCode == 124) ||
    (scharCode == 167)
    ) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
  } else if (parametro=='nc'){
    if(
    (scharCode < 47 || scharCode > 57) &&
    ((scharCode < 65 || scharCode > 90) && (scharCode < 97 || scharCode > 122))
    ) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
  } else if (parametro=='np'){
    if ((scharCode < 48 || scharCode > 57) && scharCode != 46) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
   }
  else if (parametro=='npv'){
    if ((scharCode < 48 || scharCode > 57) && scharCode != 46 && scharCode != 44) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
   }
   else if (parametro=='ndq'){
		//aggiunto per eliminazione di doppi apici (utilizzato per i campi presso e edificio)
	    if (scharCode == 34) isIE ? objCurrCtrl.returnValue = false : objCurrCtrl.preventDefault();
    }
 }
function showTooltip(srcObj,message,distanzaX,distanzaY) {
    var pos;
    var cor;
    pos=findPos(srcObj);
    try {
        tt = document.getElementById('tooltip');
        cor = (pos[0] + srcObj.offsetWidth + distanzaX);
        tt.style.left= cor + 'px';
        cor = pos[1] + distanzaY;
        tt.style.top= cor + 'px';
        tt.style.display='block';
        ttt = document.getElementById('tooltiptext');
        ttt.innerHTML=message;
    }
    catch (e) {}
}
	function hideTooltip() {
	    tt = document.getElementById('tooltip');
		tt.style.display='none';
	}
	function findPos(obj) {
		var curleft = curtop = 0;
			if (obj.offsetParent) {
				curleft = obj.offsetLeft;
				curtop = obj.offsetTop;
				while (obj = obj.offsetParent) {
					curleft += obj.offsetLeft;
					curtop += obj.offsetTop;
				}
			}
			return [curleft,curtop];
	}
/*##FE-ELCOMMENT - fine inserimento tooltip 17/07/07 */
var centroAltezza,centroLarghezza;
	function posiziona(width,height)
	{
		var altezzaClient;
		var larghezzaClient;
		var altezzaTot;
		var larghezzaTot;
		larghezzaClient = screen.width;
		altezzaClient= screen.height;
		altezzaTot = altezzaClient - height;
		larghezzaTot = larghezzaClient - width;
		centroAltezza = altezzaTot/2;
		centroLarghezza = larghezzaTot/2;
	}
	function PopDiv(id,width,height)
	{
		var DIV;
		posiziona(width,height);
		DIV=document.getElementById(id);
		DIV.style.width=width ;
		DIV.style.height=height ;
		DIV.style.left=centroLarghezza;
		DIV.style.top=centroAltezza;
		DIV.style.display='block';
	}
	function getWidth(width)
	{
		return Number(width.substring(0, (width.length-2)));
	}
	function getHeight(height)
	{
		return Number(height.substring(0, (height.length-2)));
	}
	function PopDivCentrata(id, width, height)
	{
		var DIV;
		DIV = document.getElementById(id);
		DIV.style.width = width;
		DIV.style.height = height;
		DIV.style.left = document.body.scrollLeft + ((document.body.clientWidth - getWidth(DIV.style.width))/2);
		DIV.style.top = document.body.scrollTop + ((document.body.clientHeight - getHeight(DIV.style.height))/2);
		DIV.style.display = 'block';
	}
	// Funzione per la sostituzione di una sequenza di caratteri presenti in una stringa
    function StringReplace(sText, sToReplace, sReplace)
    {
        // Se i parametri passati non sono corretti la funzione termina
        if (sText == null || sText == "" || sToReplace == null || sToReplace == "" || sReplace == null)
            return sText;
        // Sostituzione di tutte le occorrenze della stringa da sostituire
        while (sText.lastIndexOf(sToReplace) != -1)
            sText = sText.replace(sToReplace, sReplace);
        // Restituzione della stringa risultante
        return sText;
    }
    // Procedura per la sostituzione di campi decimali vuoti con zeri
    function ReplaceEmptyWithZero(ctrl, num)
    {
        // Se il campo è valido ed è vuoto si procede alla sostituzione
        if (ctrl != null && ctrl.value.trim() == "")
        {
            // Cancellazione dell'eventuale valore precedente (eventuali spazi)
            ctrl.value = "";
            // Inserimento del numero di zeri richiesto
            for (var i = 0; i < num; i++)
                ctrl.value = ctrl.value + "0";
        }
    }
    // Funzione per rendere maiuscola la p
