<?php
$ip = $_SERVER['REMOTE_ADDR'];
file_put_contents("heartbeat/$ip.txt", time());
http_response_code(204);
?>